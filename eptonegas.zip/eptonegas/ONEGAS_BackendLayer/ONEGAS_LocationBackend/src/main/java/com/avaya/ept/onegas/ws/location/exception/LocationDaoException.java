package com.avaya.ept.onegas.ws.location.exception;

/**
 * 
 * @author schmidt0
 * 
 */
public class LocationDaoException extends Exception {

	private static final long serialVersionUID = 1L;
	private int statusCode;
	
	public LocationDaoException() {
	}

	/**
	 * @param message
	 */
	public LocationDaoException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public LocationDaoException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public LocationDaoException(String message, Throwable cause) {
		super(message, cause);
	}
	/**
	 * @param message
	 */
	public LocationDaoException(String message, int statusCode) {
		super(message);
		setStatusCode(statusCode);
	}
	
	/**
	 * @param cause
	 */
	public LocationDaoException(Throwable cause, int statusCode) {
		super(cause);
		setStatusCode(statusCode);
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public LocationDaoException(String message, Throwable cause, int statusCode) {
		super(message, cause);
		setStatusCode(statusCode);
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

}
