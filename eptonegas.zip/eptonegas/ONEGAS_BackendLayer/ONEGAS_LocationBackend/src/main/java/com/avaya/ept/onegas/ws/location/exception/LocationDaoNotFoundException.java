package com.avaya.ept.onegas.ws.location.exception;

/**
 * 
 * @author schmidt0
 * 
 */
public class LocationDaoNotFoundException extends LocationDaoException {

	private static final long serialVersionUID = 1L;
	private int statusCode;
	
	public LocationDaoNotFoundException() {
	}

	/**
	 * @param message
	 */
	public LocationDaoNotFoundException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public LocationDaoNotFoundException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public LocationDaoNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}
	/**
	 * @param message
	 */
	public LocationDaoNotFoundException(String message, int statusCode) {
		super(message, statusCode);
		setStatusCode(statusCode);
	}
	
	/**
	 * @param cause
	 */
	public LocationDaoNotFoundException(Throwable cause, int statusCode) {
		super(cause, statusCode);
		setStatusCode(statusCode);
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public LocationDaoNotFoundException(String message, Throwable cause, int statusCode) {
		super(message, cause, statusCode);
		setStatusCode(statusCode);
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

}
