package com.avaya.ept.onegas.ws.location.service;

import java.util.List;

import javax.xml.bind.JAXBElement;

import com.avaya.ept.onegas.ws.location.dao.ILocationDao;
import com.avaya.ept.onegas.ws.location.exception.LocationClientServiceException;
import com.avaya.ept.onegas.ws.location.exception.LocationDaoException;
import com.avaya.ept.onegas.ws.location.model.ArrayOfLocationInfo;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCode;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCodeResponse;
import com.avaya.ept.onegas.ws.location.model.LocationInfo;
import com.avaya.ept.onegas.ws.location.model.ObjectFactory;

public class LocationServiceImpl implements ILocationService {

	/**
	 * 
	 */
	private ILocationDao locationDao;

	public List<LocationInfo> getLocationsByZipCode(String zipCode) throws LocationClientServiceException {
		GetLocationsByZipCode getLocationsByZipCode = getObjectFactory().createGetLocationsByZipCode();
		JAXBElement<String> jaxbLdcProvider = getObjectFactory().createGetLocationsByZipCodeZipCode(zipCode);
		getLocationsByZipCode.setZipCode(jaxbLdcProvider);

		try {
			GetLocationsByZipCodeResponse getLocationsByZipCodeResponse = getLocationDao().getLocationsByZipCode(getLocationsByZipCode);
			JAXBElement<ArrayOfLocationInfo> payload = getLocationsByZipCodeResponse.getGetLocationsByZipCodeResult().getValue().getPayload();
			return payload.getValue().getLocationInfo();

		} catch (LocationDaoException e) {
			throw new LocationClientServiceException(e,e.getStatusCode());
		}
	}

	public ObjectFactory getObjectFactory() {
		return new ObjectFactory();
	}

	/**
	 * @return the locationDao
	 */
	public ILocationDao getLocationDao() {
		return locationDao;
	}

	/**
	 * @param locationDao
	 *            the locationDao to set
	 */
	public void setLocationDao(ILocationDao locationDao) {
		this.locationDao = locationDao;
	}
}