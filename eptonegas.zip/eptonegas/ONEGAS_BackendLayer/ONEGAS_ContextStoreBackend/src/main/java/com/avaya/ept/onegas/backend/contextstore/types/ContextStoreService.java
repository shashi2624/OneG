package com.avaya.ept.onegas.backend.contextstore.types;

import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.http.HttpStatus;

import com.avaya.ept.onegas.backend.contextstore.ContextStoreException;
import com.avaya.ept.onegas.backend.contextstore.client.ContextStoreClient;
import com.avaya.ept.onegas.backend.contextstore.utils.ContextStoreKeys;

public class ContextStoreService {
	private ContextStoreClient csClient;

	/**
	 * Create a Context Store.
	 * 
	 * @param contextId
	 *            - Context's Id that will be use to identified each context
	 * @param contextBodyMap
	 *            - Map including KeyValues to insert inside Context's data.
	 *            Here will be stored the needed information
	 * @param leaseTime
	 *            - Time while the context will be kept alive
	 * 
	 * @return boolean - TRUE if the context's creation was success.
	 */
	public boolean createContextStore(String contextId, Map<String, String> contextBodyMap, String leaseTime) {
		boolean contextCreated;
		try {
			HttpStatus response = csClient.upsertContextStore(contextId, csClient.createJsonObject(contextBodyMap), leaseTime);

			if (response != null) {
				contextCreated = response.equals(HttpStatus.OK);
			} else {
				contextCreated = false;
			}
		} catch (Exception e) {
			contextCreated = false;
		}
		return contextCreated;
	}

	/**
	 * Create a Context Store.
	 * 
	 * @param contextId
	 *            - Context's Id that will be use to identified each context
	 * @param contextBodyMap
	 *            - Map including KeyValues to insert inside Context's data.
	 *            Here will be stored the needed information
	 * @param leaseTime
	 *            - Time while the context will be kept alive
	 * 
	 * @return boolean - TRUE if the context's creation was success.
	 */
	@SuppressWarnings("unchecked")
	public String createContextStore(Map<String, String> contextBodyMap, String leaseTime, boolean persistToEDM) {
		Map<String, String> data = null;
		try {
			JSONObject response = csClient.insertContextStore(csClient.createJsonObject(contextBodyMap, persistToEDM), leaseTime);
			if (response != null) {
				data = (Map<String, String>) response.get(ContextStoreKeys.DATA.toString());
				return (String) data.get(ContextStoreKeys.CONTEXT_ID.toString());
			} else {
				return "";
			}
		} catch (Exception e) {
			return "";
		}
	}

	@SuppressWarnings("unchecked")
	public String createContextStoreWithParams(Map<String, String> contextBodyMap, Map<String, String> params, boolean persistToEDM) {
		Map<String, String> data = null;
		try {
			JSONObject response = csClient.insertContextStoreWithParams(csClient.createJsonObject(contextBodyMap, persistToEDM), params);
			if (response != null) {
				data = (Map<String, String>) response.get(ContextStoreKeys.DATA.toString());
				return (String) data.get(ContextStoreKeys.CONTEXT_ID.toString());
			} else {
				return "";
			}
		} catch (Exception e) {
			return "";
		}
	}
	
	@SuppressWarnings("unchecked")
	public String createContextStoreWithParamsAndGroupId(Map<String, String> contextBodyMap, Map<String, String> params, boolean persistToEDM, String groupId) {
		Map<String, String> data = null;
		try {
			JSONObject response = csClient.insertContextStoreWithParams(csClient.createJsonObjectWithGroupID(contextBodyMap, persistToEDM, groupId), params);
			if (response != null) {
				data = (Map<String, String>) response.get(ContextStoreKeys.DATA.toString());
				return (String) data.get(ContextStoreKeys.CONTEXT_ID.toString());
			} else {
				return "";
			}
		} catch (Exception e) {
			return "";
		}
	}

	/**
	 * Update a Context Store.
	 * 
	 * @param contextId
	 *            - Context's Id that will be use to identified each context
	 * @param contextBodyMap
	 *            - Map including KeyValues to insert inside Context's data.
	 *            Here will be stored the needed information
	 * 
	 * @return boolean - TRUE if the context's upsert was success.
	 */
	public boolean updateContextStore(String contextId, Map<String, String> contextBodyMap, boolean persistToEDM, String groupId) {
		try {
			HttpStatus response = csClient.upsertContextStore(contextId, csClient.createJsonObjectForUpdate(contextBodyMap, persistToEDM, groupId), null);
			if (HttpStatus.OK.equals(response)) {
				return true;
			}
		} catch (Exception e) {
		}
		return false;
	}

	public boolean updateContextStore(String contextId, Map<String, String> contextBodyMap) {
		try {
			HttpStatus response = csClient.upsertContextStore(contextId, csClient.createJsonObject(contextBodyMap), null);
			if (HttpStatus.OK.equals(response)) {
				return true;
			}
		} catch (Exception e) {
		}
		return false;
	}

	public boolean updateContextStoreWithParams(String contextId, Map<String, String> contextBodyMap, Map<String, String> params, boolean persistToEDM) {
		try {
			HttpStatus response = csClient.upsertContextStoreWithParams(contextId, csClient.createJsonObject(contextBodyMap, persistToEDM), params);
			if (HttpStatus.OK.equals(response)) {
				return true;
			}
		} catch (Exception e) {
		}
		return false;
	}

	/**
	 * Get Context Store's body.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @return JSONObject - Object that contain the response's body
	 * 
	 */
	public JSONObject getContextStoreBody(String contextId) {
		return csClient.getContextStore(contextId);
	}

	/**
	 * Add a KeyValue pair.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @param key
	 *            - Key to set to new the KeyValue pair
	 * @param value
	 *            - Value to set to new the KeyValue pair
	 * @return boolean - TRUE if the KeyValue pair was added
	 * @throws Exception
	 */
	public boolean addKeyValue(String contextId, String key, String value) {
		boolean added = false;

		Map<String, String> data = getDataMap(contextId);
		if (key != null && data != null && !data.containsKey(key)) {
			data.put(key, value);
			updateContextStore(contextId, data);
			added = true;
		} else {
			if (key != null && data != null) {
				throw new ContextStoreException("DefaultContext Exception: the KeyValue pair already exits");
			}
		}
		return added;
	}

	/**
	 * Update a KeyValue pair.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @param key
	 *            - Key to identified the KeyValue pair
	 * @param value
	 *            - New value to set
	 * @return boolean - TRUE if the update was success.
	 * @throws Exception
	 */
	public boolean updateKeyValue(String contextId, String key, String value) {
		return csClient.updateKeyValue(contextId, key, value).equals(HttpStatus.OK);
	}

	/**
	 * Remove a KeyValue pair.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @param key
	 *            - Key to identify the KeyValue pair
	 * @return boolean - TRUE if the KeyValue pair was deleted
	 * @throws Exception
	 */
	public boolean removeKeyValue(String contextId, String key) {
		HttpStatus status = csClient.removeKeyValue(contextId, key);
		if(status!=null){
			return status.equals(HttpStatus.OK);
		}else{
			return false;
		}
	}

	/**
	 * Update a KeyValue pair. In case is does not exist, add it too.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @param key
	 *            - Key to set to new the KeyValue pair
	 * @param value
	 *            - Value to set to new the KeyValue pair
	 * @return boolean - TRUE if the KeyValue pair was added
	 * @throws Exception
	 */
	public boolean saveKeyValue(String contextId, String key, String value) {
		boolean saved = false;

		Map<String, String> data = getDataMap(contextId);
		if (key != null && data != null) {
			data.put(key, value);
			updateContextStore(contextId, data);
			saved = true;
		}
		return saved;
	}

	/**
	 * Get Json Object from the Context.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @return JSONObject - JSON content at the context
	 * @throws Exception
	 */
	public JSONObject getJsonObject(String contextId) {
		JSONObject jsonObject = null;
		if (contextId != null) {
			jsonObject = csClient.getContextStore(contextId);
		} else {
			throw new ContextStoreException("DefaultContext Exception: ContextId should not be null.");
		}
		return jsonObject;
	}

	/**
	 * Get a map with the data of the Context.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @return Map - Data of the Context
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> getDataMap(String contextId) {
		Map<String, String> data = null;

		JSONObject jsonObject = getJsonObject(contextId);
		if (jsonObject != null) {
			data = (Map<String, String>) jsonObject.get(ContextStoreKeys.DATA.toString());
		} else {
			throw new ContextStoreException("DefaultContext Exception: ContextId not found.");
		}
		return data;
	}

	/**
	 * @return boolean - TRUE If the Outage Context exists
	 * @throws Exception
	 */
	public boolean contextExists(String context) {
		boolean exists;
		try {
			csClient.getContextStore(context);
			exists = true;
		} catch (Exception e) {
			exists = false;
		}

		return exists;
	}

	// Getters and Setters
	public ContextStoreClient getCsClient() {
		return csClient;
	}

	public void setCsClient(ContextStoreClient csClient) {
		this.csClient = csClient;
	}
}
