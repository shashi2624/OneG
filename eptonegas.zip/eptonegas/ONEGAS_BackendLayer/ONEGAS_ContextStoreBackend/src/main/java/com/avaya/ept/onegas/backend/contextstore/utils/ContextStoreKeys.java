package com.avaya.ept.onegas.backend.contextstore.utils;

public enum ContextStoreKeys {
	CONTEXT_ID("contextId"),
	DATA("data"),
	GROUP_ID("groupId"),
	ALIAS_IDS("aliasIds"),
	ANI_MATCH("DB_3220_LookupBillingAccount_aniMatch"),
	IS_VALIDATED("3180_deCheckValidateSSN_isValidated"),
	LANGUAGE("1050_iaLanguageSelection_language"),
	ACCT_NUMBER("DB_3380_getAccountSummary_acctNumber"),
	LAST_NAME("DB_3380_getAccountSummary_lastName"),
	FIRST_NAME("DB_3380_getAccountSummary_firstName"),
	LASTS_STATE("lastState"),
	MAIN_MENU("5020_iaMainMenu_mainMenu"),
	OTHER_MENU("5100_iaOther_otherMenu"),
	BILLING_MENU("30020_iaBillingOptionsMenu_billlingOptionsMenu"),
	PAYMENT_MENU("4520_iaMakePaymentMenu_paymentMenu"),
	ACCT_INFO_MENU("7020_iaAccountInfoMenu_acctInfoMenu"),
	HIDDEN_MENU("5200_iaHiddenMenu_hiddenMenu"),
	SERVICE_MENU("18010_iaServiceOptions_serviceOptions"),
	LEASE_TIME("lease"), 
	PERSIST_EDM("persistToEDM"), 
	RID("rid"),
	SHORT_ID("shortid"),
	CALL_TIME("calltime");

	private final String name;
	
	ContextStoreKeys(String str) {
		this.name = str;
	}
	
	public String toString() {
		return this.name;
	}
}
