package com.avaya.ept.onegas.backend.contextstore.client;

import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.avaya.ept.onegas.backend.contextstore.ContextStoreException;
import com.avaya.ept.onegas.backend.contextstore.utils.ContextStoreKeys;

/**
 * Client to invoke Context Store REST services.
 * 
 * @author garridoj
 * 
 */
public class ContextStoreClient {
	private static final String CS_CONTEXTS = "/cs/contexts/";

	private static final Logger logger = Logger.getLogger(ContextStoreClient.class);
	private RestTemplate restTemplate;
	private String host;

	/**
	 * Create the jsonObject to be use as Context Store's Content.
	 * 
	 * @param jsonMap
	 *            - Map including Data to be store
	 * @param contextId
	 *            - Id to identify the context
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public JSONObject createJsonObject(Map<String, String> jsonMap, boolean persistToEDM) {
		JSONObject jsonObject = new JSONObject();

		JSONObject jsonData = new JSONObject();
		if (jsonMap != null) {
			jsonData.putAll(jsonMap);
		}
		jsonObject.put(ContextStoreKeys.PERSIST_EDM, persistToEDM);
		jsonObject.put(ContextStoreKeys.DATA, jsonData);

		logger.debug("createJsonObject METHOD. jsonObject:" + jsonObject.toJSONString());
		return jsonObject;
	}
	
	@SuppressWarnings("unchecked")
	public JSONObject createJsonObjectWithGroupID(Map<String, String> jsonMap, boolean persistToEDM, String groupId) {
		JSONObject jsonObject = new JSONObject();

		JSONObject jsonData = new JSONObject();
		if (jsonMap != null) {
			jsonData.putAll(jsonMap);
		}
		jsonObject.put(ContextStoreKeys.GROUP_ID, groupId);
		jsonObject.put(ContextStoreKeys.PERSIST_EDM, persistToEDM);
		jsonObject.put(ContextStoreKeys.DATA, jsonData);

		logger.debug("createJsonObject METHOD. jsonObject:" + jsonObject.toJSONString());
		return jsonObject;
	}

	
	/**
	 * Create the jsonObject to be use as Context Store's Content to update it.
	 * 
	 * @param jsonMap
	 *            - Map including Data to be store
	 * @param contextId
	 *            - Id to identify the context
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public JSONObject createJsonObjectForUpdate(Map<String, String> jsonMap, boolean persistToEDM, String groupId) {
		JSONObject jsonObject = new JSONObject();

		JSONObject jsonData = new JSONObject();
		if (jsonMap != null) {
			jsonData.putAll(jsonMap);
		}
		jsonObject.put(ContextStoreKeys.PERSIST_EDM, persistToEDM);
		jsonObject.put(ContextStoreKeys.GROUP_ID, groupId);
		jsonObject.put(ContextStoreKeys.DATA, jsonData);

		logger.debug("createJsonObject METHOD. jsonObject:" + jsonObject.toJSONString());
		return jsonObject;
	}
	
	
	@SuppressWarnings("unchecked")
	public JSONObject createJsonObject(Map<String, String> jsonMap) {
		JSONObject jsonObject = new JSONObject();

		JSONObject jsonData = new JSONObject();
		if (jsonMap != null) {
			jsonData.putAll(jsonMap);
		}
		jsonObject.put(ContextStoreKeys.DATA, jsonData);

		logger.debug("createJsonObject METHOD. jsonObject:" + jsonObject.toJSONString());
		return jsonObject;
	}

	/**
	 * Invoke UPSERT's service from Context Store Client. This service allow to
	 * insert or update a Context depending if the Context pre-existed or not.
	 * 
	 * @param contextId
	 *            - Context's Id that will be use to identified each context
	 * @param jsonObject
	 *            - JsonObject to insert inside Context's data. Here will be
	 *            stored the needed information
	 * @param leaseTime
	 *            - Time while the context will be kept alive
	 * 
	 * @return HttpStatus - Status Code of service called (200 - OK, 404 - Page
	 *         Not Found, etc)
	 */
	public HttpStatus upsertContextStore(String contextId, JSONObject jsonObject, String leaseTime) {

		ResponseEntity<String> response = null;

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> request = new HttpEntity<String>(jsonObject.toJSONString(), header);

		String strUrl = host + "/cs/contexts/upsert/" + contextId + "/";

		if (leaseTime != null) {
			UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(strUrl).queryParam("lease", leaseTime);
			strUrl = urlBuilder.build().encode().toUriString();
		}

		logger.debug("upsertContextStore METHOD. url:" + strUrl);
		logger.debug("upsertContextStore METHOD. request:" + request);
		try {
			response = getRestTemplate().exchange(strUrl, HttpMethod.PUT, request, String.class);
			logger.debug("upsertContextStore METHOD. response:" + response);
		} catch (RestClientException e) {
			logger.error("upsertContextStore METHOD. message:" + e.getMessage());
			logger.error("upsertContextStore METHOD. localized message:" + e.getLocalizedMessage());
			logger.error("upsertContextStore METHOD. response:" + response);
		}
		if (response != null) {
			return response.getStatusCode();
		} else {
			return null;
		}
	}

	public HttpStatus upsertContextStoreWithParams(String contextId, JSONObject jsonObject, Map<String, String> params) {

		ResponseEntity<String> response = null;

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> request = new HttpEntity<String>(jsonObject.toJSONString(), header);

		String strUrl = host + "/cs/contexts/upsert/" + contextId + "/";

		UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(strUrl);
		if (params.size() != 0) {
			for (String key : params.keySet()) {
				urlBuilder.queryParam(key, params.get(key));
			}
		}
		strUrl = urlBuilder.build().encode().toUriString();

		logger.debug("upsertContextStoreWithParams METHOD. url:" + strUrl);
		logger.debug("upsertContextStoreWithParams METHOD. request:" + request);
		try {
			response = getRestTemplate().exchange(strUrl, HttpMethod.PUT, request, String.class);
			logger.debug("upsertContextStoreWithParams METHOD. response:" + response);
		} catch (RestClientException e) {
			logger.error("upsertContextStoreWithParams METHOD. message:" + e.getMessage());
			logger.error("upsertContextStoreWithParams METHOD. localized message:" + e.getLocalizedMessage());
			logger.error("upsertContextStoreWithParams METHOD. response:" + response);
			return HttpStatus.GONE;
		}
		return response.getStatusCode();
	}

	public JSONObject insertContextStore(JSONObject jsonObject, String leaseTime) {

		ResponseEntity<JSONObject> response = null;

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> request = new HttpEntity<String>(jsonObject.toJSONString(), header);

		String strUrl = host + "/cs/contexts/";

		if (leaseTime != null) {
			UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(strUrl).queryParam(ContextStoreKeys.LEASE_TIME.toString(), leaseTime);
			strUrl = urlBuilder.build().encode().toUriString();
		}

		logger.debug("upsertContextStore METHOD. url:" + strUrl);
		logger.debug("upsertContextStore METHOD. request:" + request);
		try {
			response = getRestTemplate().exchange(strUrl, HttpMethod.POST, request, JSONObject.class);
			logger.debug("upsertContextStore METHOD. response:" + response);
		} catch (RestClientException e) {
			logger.error("upsertContextStore METHOD. message:" + e.getMessage());
			logger.error("upsertContextStore METHOD. localized message:" + e.getLocalizedMessage());
			logger.error("upsertContextStore METHOD. response:" + response);
		}

		boolean contextCreated;

		if (response != null) {
			contextCreated = response.getStatusCode().equals(HttpStatus.OK);
		} else {
			contextCreated = false;
		}
		return contextCreated ? response.getBody() : null;
	}

	public JSONObject insertContextStoreWithParams(JSONObject jsonObject, Map<String, String> params) {

		ResponseEntity<JSONObject> response = null;

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> request = new HttpEntity<String>(jsonObject.toJSONString(), header);
		String strUrl = host + "/cs/contexts/";
		UriComponentsBuilder urlBuilder = UriComponentsBuilder.fromHttpUrl(strUrl);
		if (params.size() != 0) {
			for (String key : params.keySet()) {
				urlBuilder.queryParam(key, params.get(key));
			}
		}
		strUrl = urlBuilder.build().encode().toUriString();

		logger.debug("insertContextStoreWithParams METHOD. url:" + strUrl);
		logger.debug("insertContextStoreWithParams METHOD. request:" + request);
		try {
			response = getRestTemplate().exchange(strUrl, HttpMethod.POST, request, JSONObject.class);
			logger.debug("insertContextStoreWithParams METHOD. response:" + response);
		} catch (RestClientException e) {
			logger.error("insertContextStoreWithParams METHOD. response:" + e.getMessage());
			logger.error("insertContextStoreWithParams METHOD. response:" + e.getLocalizedMessage());
			logger.error("insertContextStoreWithParams METHOD. response:" + response);
		}

		boolean contextCreated;

		if (response != null) {
			contextCreated = response.getStatusCode().equals(HttpStatus.OK);
		} else {
			contextCreated = false;
		}
		return contextCreated ? response.getBody() : null;
	}

	/**
	 * Invoke GET Context Store's service. Passing the context's id, the service
	 * return the response's body.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @return JSONObject - Object that contain the response's body @
	 */
	public JSONObject getContextStore(String contextId) {

		String strUrl = host + CS_CONTEXTS + contextId + "/";
		logger.debug("getContextStore METHOD. url:" + strUrl);

		ResponseEntity<JSONObject> response = null;
		try {
			response = getRestTemplate().exchange(strUrl, HttpMethod.GET, null, JSONObject.class);
		} catch (HttpClientErrorException e) {
			throw new ContextStoreException("ContextStoreClient Exception: ContextId does not exist", e);
		}

		logger.debug("getContextStore METHOD. response:" + response);
		return response != null ? response.getBody() : null;
	}

	/**
	 * Invoke PUT service for a KeyValue from Context Store Client. This service
	 * allow to update a value into a existing KeyValue.
	 * 
	 * @param contextId
	 *            - Context's Id that will be use to identified each context
	 * @param key
	 *            - Key Id
	 * @param value
	 *            - Value to update.
	 * 
	 * @return HttpStatus - Status Code of service called (200 - OK, 404 - Page
	 *         Not Found, etc)
	 */
	public HttpStatus updateKeyValue(String contextId, String key, String value) {

		ResponseEntity<String> response = null;

		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.TEXT_PLAIN);
		HttpEntity<String> request = new HttpEntity<String>(value, header);

		String strUrl = host + CS_CONTEXTS + contextId + "/keys/" + key + "/";
		logger.debug("updateKeyValue METHOD. url:" + strUrl);

		response = getRestTemplate().exchange(strUrl, HttpMethod.PUT, request, String.class);
		logger.debug("updateKeyValue METHOD. response:" + response);
		return response.getStatusCode();
	}

	/**
	 * Invoke GET Context/Key service. Passing the context's id and the key id,
	 * the service return the key value.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @param key
	 *            - Key id
	 * @return String - Key value @
	 */
	public String getKeyValue(String contextId, String key) {

		String strUrl = host + CS_CONTEXTS + contextId + "/keys/" + key + "/";
		logger.debug("getKeyValue METHOD. url:" + strUrl);

		ResponseEntity<String> response = null;
		try {
			response = getRestTemplate().exchange(strUrl, HttpMethod.GET, null, String.class);
		} catch (HttpClientErrorException e) {
			throw new ContextStoreException("ContextStoreClient Excepction: ContextId or Key does not exist", e);
		}

		logger.debug("getKeyValue METHOD. response:" + response);
		return response != null ? response.getBody() : null;
	}

	/**
	 * Invoke GET Context/Key service. Passing the context's id and the key id,
	 * the service return the key value.
	 * 
	 * @param contextId
	 *            - Id to identify the context
	 * @param key
	 *            - Key id
	 * @return String - Key value @
	 */
	public HttpStatus removeKeyValue(String contextId, String key) {

		String strUrl = host + CS_CONTEXTS + contextId + "/keys/" + key + "/";
		logger.debug("removeKeyValue METHOD. url:" + strUrl);

		ResponseEntity<String> response = null;
		try {
			response = getRestTemplate().exchange(strUrl, HttpMethod.DELETE, null, String.class);
			logger.debug("removeKeyValue METHOD. response:" + response);
		} catch (RestClientException e) {
			logger.error("removeKeyValue METHOD. response:" + e.getLocalizedMessage());
			logger.error("removeKeyValue METHOD. response:" + response);
		}
		if(response!=null){
			return response.getStatusCode();
		}else{
			return null;
		}
	}

	// Getters and Setters
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public RestTemplate getRestTemplate() {
		return restTemplate;
	}

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}
}
