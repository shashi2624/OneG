package com.avaya.ept.onegas.backend.contextstore.client;

import java.util.HashMap;
import java.util.Map;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.avaya.ept.onegas.backend.contextstore.types.ContextStoreService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:ContextStoreContext.xml")
public class ContextStoreTest {
	
	@Autowired
	private ContextStoreService contextStoreService;
	private static final String CONTEXT_ID = "testContextId1001";

	@Ignore
	@Test
	public void testClient() throws Exception {

		Map<String, String> jsonMap = new HashMap<String, String>();
		jsonMap.put("MPLN1","1");
		jsonMap.put("MPLN2","2");
		jsonMap.put("MPLN3","1");
		
		contextStoreService.createContextStore(CONTEXT_ID, jsonMap, "50");
		contextStoreService.addKeyValue(CONTEXT_ID, "MPLN4", "2");
		contextStoreService.removeKeyValue(CONTEXT_ID, "MPLN1");
		contextStoreService.getContextStoreBody(CONTEXT_ID);
	}
	
    @Ignore
	@Test
	public void testClientNoContext() throws Exception {
		
		Map<String, String> jsonMap = new HashMap<String, String>();
		jsonMap.put("MPLN1","1");
		jsonMap.put("MPLN2","2");
		jsonMap.put("MPLN3","1");
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("lease", "50");
		params.put("touchpoint", "Method1");
		params.put("rid", "A");
		for (int i = 0; i < 20; i++) {
			String contextID = contextStoreService.createContextStoreWithParams(jsonMap, params,false);
			System.out.println(contextID);
			
		}

//		params.put("touchpoint", "Method2");
//		contextStoreService.updateContextStoreWithParams(contextID, jsonMap, params,false);
//		Assert.assertTrue(contextID.length()==11);
	}

	public ContextStoreService getDefaultContext() {
		return contextStoreService;
	}

	public void setDefaultContext(ContextStoreService defaultContext) {
		this.contextStoreService = defaultContext;
	}
}
