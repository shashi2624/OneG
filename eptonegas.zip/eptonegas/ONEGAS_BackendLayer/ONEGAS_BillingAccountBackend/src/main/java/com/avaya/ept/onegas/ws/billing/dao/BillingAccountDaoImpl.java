package com.avaya.ept.onegas.ws.billing.dao;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoException;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraft;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrder;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlan;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlanResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPrice;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPriceResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraft;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterRead;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterReadResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummary;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummaryResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailability;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailabilityResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmount;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmountResponse;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrders;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrdersResponse;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistory;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistoryResponse;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccount;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePayment;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBill;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBillResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCredit;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCreditResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrder;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangement;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangementResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChange;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChangeResponse;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointment;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointmentResponse;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatus;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatus;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromise;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromiseResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPayment;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfo;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfoResponse;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccount;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccountResponse;

public class BillingAccountDaoImpl<T> implements IBilingAccountDao {

	private static final Logger logger = Logger.getLogger(BillingAccountDaoImpl.class);
	private WebServiceTemplate billingAccountServiceTemplate;
	private String soapAction;

	public LookupBillingAccountResponse lookupBillingAccount(LookupBillingAccount request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<LookupBillingAccount, LookupBillingAccountResponse>() {

			@Override
			public int getStatusCode(LookupBillingAccountResponse response) {
				return response.getLookupBillingAccountResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(LookupBillingAccountResponse response) {
				return response.getLookupBillingAccountResult().getValue().getStatusMessage();
			}
		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	public CancelServiceOrderResponse cancelServiceOrder(CancelServiceOrder request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<CancelServiceOrder, CancelServiceOrderResponse>() {
			
			@Override
			public int getStatusCode(CancelServiceOrderResponse response) {
				return response.getCancelServiceOrderResult().getValue().getStatusCode();
			}
			
			@Override
			public JAXBElement<String> getStatusMessage(CancelServiceOrderResponse response) {
				return response.getCancelServiceOrderResult().getValue().getStatusMessage();
			}
		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	public GetOpenServiceOrdersResponse getOpenServiceOrders(GetOpenServiceOrders request) throws BillingAccountDaoException {

		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<GetOpenServiceOrders, GetOpenServiceOrdersResponse>() {
			@Override
			public int getStatusCode(GetOpenServiceOrdersResponse response) {
				return response.getGetOpenServiceOrdersResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(GetOpenServiceOrdersResponse response) {
				return response.getGetOpenServiceOrdersResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	public WebServiceTemplate getBillingAccountServiceTemplate() {
		return billingAccountServiceTemplate;
	}

	public void setBillingAccountServiceTemplate(WebServiceTemplate billingAccountServiceTemplate) {
		this.billingAccountServiceTemplate = billingAccountServiceTemplate;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#getAccountSummary
	 * (com.avaya.ept.onegas.ws.billing.model.GetAccountSummary)
	 */
	@Override
	public GetAccountSummaryResponse getAccountSummary(GetAccountSummary request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<GetAccountSummary, GetAccountSummaryResponse>() {
			@Override
			public int getStatusCode(GetAccountSummaryResponse response) {
				return response.getGetAccountSummaryResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(GetAccountSummaryResponse response) {
				return response.getGetAccountSummaryResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * removeBankAccountInformation
	 * (com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformation)
	 */
	@Override
	public RemoveBankAccountInformationResponse removeBankAccountInformation(RemoveBankAccountInformation request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<RemoveBankAccountInformation, RemoveBankAccountInformationResponse>() {
			@Override
			public int getStatusCode(RemoveBankAccountInformationResponse response) {
				return response.getRemoveBankAccountInformationResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(RemoveBankAccountInformationResponse response) {
				return response.getRemoveBankAccountInformationResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#makeOneTimePayment
	 * (com.avaya.ept.onegas.ws.billing.model.MakeOneTimePayment)
	 */
	@Override
	public MakeOneTimePaymentResponse makeOneTimePayment(MakeOneTimePayment request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<MakeOneTimePayment, MakeOneTimePaymentResponse>() {
			@Override
			public int getStatusCode(MakeOneTimePaymentResponse response) {
				return response.getMakeOneTimePaymentResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(MakeOneTimePaymentResponse response) {
				return response.getMakeOneTimePaymentResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}
	
	/* (non-Javadoc)
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#makeOneTimePaymentWithExistingBankAccount(com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount)
	 */
	@Override
	public MakeOneTimePaymentWithExistingBankAccountResponse makeOneTimePaymentWithExistingBankAccount(
			MakeOneTimePaymentWithExistingBankAccount request)
			throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<MakeOneTimePaymentWithExistingBankAccount, MakeOneTimePaymentWithExistingBankAccountResponse>() {
			@Override
			public int getStatusCode(MakeOneTimePaymentWithExistingBankAccountResponse response) {
				return response.getMakeOneTimePaymentWithExistingBankAccountResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(MakeOneTimePaymentWithExistingBankAccountResponse response) {
				return response.getMakeOneTimePaymentWithExistingBankAccountResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * registerBankAccountInformation
	 * (com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformation)
	 */
	@Override
	public RegisterBankAccountInformationResponse registerBankAccountInformation(RegisterBankAccountInformation request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<RegisterBankAccountInformation, RegisterBankAccountInformationResponse>() {
			@Override
			public int getStatusCode(RegisterBankAccountInformationResponse response) {
				return response.getRegisterBankAccountInformationResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(RegisterBankAccountInformationResponse response) {
				return response.getRegisterBankAccountInformationResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#submitMemoPayment
	 * (com.avaya.ept.onegas.ws.billing.model.SubmitMemoPayment)
	 */
	@Override
	public SubmitMemoPaymentResponse submitMemoPayment(SubmitMemoPayment request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<SubmitMemoPayment, SubmitMemoPaymentResponse>() {
			@Override
			public int getStatusCode(SubmitMemoPaymentResponse response) {
				return response.getSubmitMemoPaymentResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(SubmitMemoPaymentResponse response) {
				return response.getSubmitMemoPaymentResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#enrollInBankDraft
	 * (com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraft)
	 */
	@Override
	public EnrollInBankDraftResponse enrollInBankDraft(EnrollInBankDraft request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<EnrollInBankDraft, EnrollInBankDraftResponse>() {
			@Override
			public int getStatusCode(EnrollInBankDraftResponse response) {
				return response.getEnrollInBankDraftResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(EnrollInBankDraftResponse response) {
				return response.getEnrollInBankDraftResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#cancelBankDraft
	 * (com.avaya.ept.onegas.ws.billing.model.CancelBankDraft)
	 */
	@Override
	public CancelBankDraftResponse cancelBankDraft(CancelBankDraft request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<CancelBankDraft, CancelBankDraftResponse>() {
			@Override
			public int getStatusCode(CancelBankDraftResponse response) {
				return response.getCancelBankDraftResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(CancelBankDraftResponse response) {
				return response.getCancelBankDraftResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#updateBankDraftInfo
	 * (com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfo)
	 */
	@Override
	public UpdateBankDraftInfoResponse updateBankDraftInfo(UpdateBankDraftInfo request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<UpdateBankDraftInfo, UpdateBankDraftInfoResponse>() {
			@Override
			public int getStatusCode(UpdateBankDraftInfoResponse response) {
				return response.getUpdateBankDraftInfoResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(UpdateBankDraftInfoResponse response) {
				return response.getUpdateBankDraftInfoResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#requestDuplicateBill
	 * (com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBill)
	 */
	@Override
	public RequestDuplicateBillResponse requestDuplicateBill(RequestDuplicateBill request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<RequestDuplicateBill, RequestDuplicateBillResponse>() {
			@Override
			public int getStatusCode(RequestDuplicateBillResponse response) {
				return response.getRequestDuplicateBillResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(RequestDuplicateBillResponse response) {
				return response.getRequestDuplicateBillResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#requestLetterOfCredit
	 * (com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCredit)
	 */
	@Override
	public RequestLetterOfCreditResponse requestLetterOfCredit(RequestLetterOfCredit request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<RequestLetterOfCredit, RequestLetterOfCreditResponse>() {

			@Override
			public int getStatusCode(RequestLetterOfCreditResponse response) {
				return response.getRequestLetterOfCreditResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(RequestLetterOfCreditResponse response) {
				return response.getRequestLetterOfCreditResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#setShareTheWarmthStatus
	 * (com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatus)
	 */
	@Override
	public SetShareTheWarmthStatusResponse setShareTheWarmthStatus(SetShareTheWarmthStatus request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<SetShareTheWarmthStatus, SetShareTheWarmthStatusResponse>() {

			@Override
			public int getStatusCode(SetShareTheWarmthStatusResponse response) {
				return response.getSetShareTheWarmthStatusResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(SetShareTheWarmthStatusResponse response) {
				return response.getSetShareTheWarmthStatusResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * setElectronicBillingStatus
	 * (com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatus)
	 */
	@Override
	public SetElectronicBillingStatusResponse setElectronicBillingStatus(SetElectronicBillingStatus request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<SetElectronicBillingStatus, SetElectronicBillingStatusResponse>() {

			@Override
			public int getStatusCode(SetElectronicBillingStatusResponse response) {
				return response.getSetElectronicBillingStatusResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(SetElectronicBillingStatusResponse response) {
				return response.getSetElectronicBillingStatusResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#reserveAppointment
	 * (com.avaya.ept.onegas.ws.billing.model.ReserveAppointment)
	 */
	@Override
	public ReserveAppointmentResponse reserveAppointment(ReserveAppointment request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<ReserveAppointment, ReserveAppointmentResponse>() {

			@Override
			public int getStatusCode(ReserveAppointmentResponse response) {
				return response.getReserveAppointmentResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(ReserveAppointmentResponse response) {
				return response.getReserveAppointmentResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * getAppointmentAvailability
	 * (com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailability)
	 */
	@Override
	public GetAppointmentAvailabilityResponse getAppointmentAvailability(GetAppointmentAvailability request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<GetAppointmentAvailability, GetAppointmentAvailabilityResponse>() {

			@Override
			public int getStatusCode(GetAppointmentAvailabilityResponse response) {
				return response.getGetAppointmentAvailabilityResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(GetAppointmentAvailabilityResponse response) {
				return response.getGetAppointmentAvailabilityResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#requestMoveOutOrder
	 * (com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrder)
	 */
	@Override
	public RequestMoveOutOrderResponse requestMoveOutOrder(RequestMoveOutOrder request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<RequestMoveOutOrder, RequestMoveOutOrderResponse>() {

			@Override
			public int getStatusCode(RequestMoveOutOrderResponse response) {
				return response.getRequestMoveOutOrderResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(RequestMoveOutOrderResponse response) {
				return response.getRequestMoveOutOrderResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * requestServiceOrderChange
	 * (com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChange)
	 */
	@Override
	public RequestServiceOrderChangeResponse requestServiceOrderChange(RequestServiceOrderChange request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<RequestServiceOrderChange, RequestServiceOrderChangeResponse>() {

			@Override
			public int getStatusCode(RequestServiceOrderChangeResponse response) {
				return response.getRequestServiceOrderChangeResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(RequestServiceOrderChangeResponse response) {
				return response.getRequestServiceOrderChangeResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#enterMeterRead(
	 * com.avaya.ept.onegas.ws.billing.model.EnterMeterRead)
	 */
	@Override
	public EnterMeterReadResponse enterMeterRead(EnterMeterRead request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<EnterMeterRead, EnterMeterReadResponse>() {

			@Override
			public int getStatusCode(EnterMeterReadResponse response) {
				return response.getEnterMeterReadResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(EnterMeterReadResponse response) {
				return response.getEnterMeterReadResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * enrollForVoluntaryFixedPrice
	 * (com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPrice)
	 */
	@Override
	public EnrollForVoluntaryFixedPriceResponse enrollForVoluntaryFixedPrice(EnrollForVoluntaryFixedPrice request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<EnrollForVoluntaryFixedPrice, EnrollForVoluntaryFixedPriceResponse>() {

			@Override
			public int getStatusCode(EnrollForVoluntaryFixedPriceResponse response) {
				return response.getEnrollForVoluntaryFixedPriceResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(EnrollForVoluntaryFixedPriceResponse response) {
				return response.getEnrollForVoluntaryFixedPriceResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#getPaymentHistory
	 * (com.avaya.ept.onegas.ws.billing.model.GetPaymentHistory)
	 */
	@Override
	public GetPaymentHistoryResponse getPaymentHistory(GetPaymentHistory request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<GetPaymentHistory, GetPaymentHistoryResponse>() {

			@Override
			public int getStatusCode(GetPaymentHistoryResponse response) {
				return response.getGetPaymentHistoryResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(GetPaymentHistoryResponse response) {
				return response.getGetPaymentHistoryResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#validateAccount
	 * (com.avaya.ept.onegas.ws.billing.model.ValidateAccount)
	 */
	@Override
	public ValidateAccountResponse validateAccount(ValidateAccount request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<ValidateAccount, ValidateAccountResponse>() {

			@Override
			public int getStatusCode(ValidateAccountResponse response) {
				return response.getValidateAccountResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(ValidateAccountResponse response) {
				return response.getValidateAccountResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * requestPaymentArrangement
	 * (com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangement)
	 */
	@Override
	public RequestPaymentArrangementResponse requestPaymentArrangement(RequestPaymentArrangement request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<RequestPaymentArrangement, RequestPaymentArrangementResponse>() {

			@Override
			public int getStatusCode(RequestPaymentArrangementResponse response) {
				return response.getRequestPaymentArrangementResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(RequestPaymentArrangementResponse response) {
				return response.getRequestPaymentArrangementResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * getAveragePaymentPlanAmount
	 * (com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmount)
	 */
	@Override
	public GetAveragePaymentPlanAmountResponse getAveragePaymentPlanAmount(GetAveragePaymentPlanAmount request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<GetAveragePaymentPlanAmount, GetAveragePaymentPlanAmountResponse>() {

			@Override
			public int getStatusCode(GetAveragePaymentPlanAmountResponse response) {
				return response.getGetAveragePaymentPlanAmountResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(GetAveragePaymentPlanAmountResponse response) {
				return response.getGetAveragePaymentPlanAmountResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * enrollForAveragePaymentPlan
	 * (com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlan)
	 */
	@Override
	public EnrollForAveragePaymentPlanResponse enrollForAveragePaymentPlan(EnrollForAveragePaymentPlan request) throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<EnrollForAveragePaymentPlan, EnrollForAveragePaymentPlanResponse>() {

			@Override
			public int getStatusCode(EnrollForAveragePaymentPlanResponse response) {
				return response.getEnrollForAveragePaymentPlanResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(EnrollForAveragePaymentPlanResponse response) {
				return response.getEnrollForAveragePaymentPlanResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	/* (non-Javadoc)
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#submitEnergyAssistancePromise(com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromise)
	 */
	@Override
	public SubmitEnergyAssistancePromiseResponse submitEnergyAssistancePromise(
			SubmitEnergyAssistancePromise request)
			throws BillingAccountDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new BillingAccountCallBack<SubmitEnergyAssistancePromise, SubmitEnergyAssistancePromiseResponse>() {

			@Override
			public int getStatusCode(SubmitEnergyAssistancePromiseResponse response) {
				return response.getSubmitEnergyAssistancePromiseResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(SubmitEnergyAssistancePromiseResponse response) {
				return response.getSubmitEnergyAssistancePromiseResult().getValue().getStatusMessage();
			}

		}.call(logger, billingAccountServiceTemplate, request, soapActionCallback);
	}

	public String getSoapAction() {
		return soapAction;
	}

	public void setSoapAction(String soapAction) {
		this.soapAction = soapAction;
	}


}