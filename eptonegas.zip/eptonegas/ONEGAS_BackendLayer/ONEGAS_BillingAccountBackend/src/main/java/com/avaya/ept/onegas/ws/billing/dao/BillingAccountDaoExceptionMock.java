/*
 * BillingAccountDaoMock.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */
package com.avaya.ept.onegas.ws.billing.dao;

import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.test.client.MockWebServiceServer;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoException;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoNotFoundException;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraft;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrder;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlan;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlanResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPrice;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPriceResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraft;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterRead;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterReadResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummary;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummaryResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailability;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailabilityResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmount;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmountResponse;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrders;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrdersResponse;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistory;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistoryResponse;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccount;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePayment;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBill;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBillResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCredit;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCreditResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrder;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangement;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangementResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChange;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChangeResponse;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointment;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointmentResponse;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatus;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatus;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromise;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromiseResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPayment;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfo;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfoResponse;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccount;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccountResponse;

/**
 * @author schmidt0
 * 
 */
public class BillingAccountDaoExceptionMock implements IBilingAccountDao {

	private MockWebServiceServer mockServer;
	private WebServiceTemplate billingAccountServiceTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#lookupBillingAccount
	 * (com.avaya.ept.onegas.ws.billing.model.LookupBillingAccount)
	 */
	@Override
	public LookupBillingAccountResponse lookupBillingAccount(LookupBillingAccount request) throws BillingAccountDaoException {
		throw new BillingAccountDaoNotFoundException("test");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#getAccountSummary
	 * (com.avaya.ept.onegas.ws.billing.model.GetAccountSummary)
	 */
	@Override
	public GetAccountSummaryResponse getAccountSummary(GetAccountSummary request) throws BillingAccountDaoException {
		throw new BillingAccountDaoNotFoundException("test");
	}

	public MockWebServiceServer getMockServer() {
		return mockServer;
	}

	public void setMockServer(MockWebServiceServer mockServer) {
		this.mockServer = mockServer;
	}

	public WebServiceTemplate getBillingAccountServiceTemplate() {
		return billingAccountServiceTemplate;
	}

	public void setBillingAccountServiceTemplate(WebServiceTemplate billingAccountServiceTemplate) {
		this.billingAccountServiceTemplate = billingAccountServiceTemplate;
	}

	@Override
	public GetOpenServiceOrdersResponse getOpenServiceOrders(GetOpenServiceOrders request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RemoveBankAccountInformationResponse removeBankAccountInformation(RemoveBankAccountInformation request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MakeOneTimePaymentResponse makeOneTimePayment(MakeOneTimePayment request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#makeOneTimePaymentWithExistingBankAccount(com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount)
	 */
	@Override
	public MakeOneTimePaymentWithExistingBankAccountResponse makeOneTimePaymentWithExistingBankAccount(
			MakeOneTimePaymentWithExistingBankAccount request)
			throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public RegisterBankAccountInformationResponse registerBankAccountInformation(RegisterBankAccountInformation request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubmitMemoPaymentResponse submitMemoPayment(SubmitMemoPayment request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EnrollInBankDraftResponse enrollInBankDraft(EnrollInBankDraft request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CancelBankDraftResponse cancelBankDraft(CancelBankDraft request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UpdateBankDraftInfoResponse updateBankDraftInfo(UpdateBankDraftInfo request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RequestDuplicateBillResponse requestDuplicateBill(RequestDuplicateBill request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RequestLetterOfCreditResponse requestLetterOfCredit(RequestLetterOfCredit request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SetShareTheWarmthStatusResponse setShareTheWarmthStatus(SetShareTheWarmthStatus request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SetElectronicBillingStatusResponse setElectronicBillingStatus(SetElectronicBillingStatus request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReserveAppointmentResponse reserveAppointment(ReserveAppointment request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GetAppointmentAvailabilityResponse getAppointmentAvailability(GetAppointmentAvailability request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RequestMoveOutOrderResponse requestMoveOutOrder(RequestMoveOutOrder request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RequestServiceOrderChangeResponse requestServiceOrderChange(RequestServiceOrderChange request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EnterMeterReadResponse enterMeterRead(EnterMeterRead request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EnrollForVoluntaryFixedPriceResponse enrollForVoluntaryFixedPrice(EnrollForVoluntaryFixedPrice request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GetPaymentHistoryResponse getPaymentHistory(GetPaymentHistory request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ValidateAccountResponse validateAccount(ValidateAccount request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RequestPaymentArrangementResponse requestPaymentArrangement(RequestPaymentArrangement request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GetAveragePaymentPlanAmountResponse getAveragePaymentPlanAmount(GetAveragePaymentPlanAmount request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EnrollForAveragePaymentPlanResponse enrollForAveragePaymentPlan(EnrollForAveragePaymentPlan request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubmitEnergyAssistancePromiseResponse submitEnergyAssistancePromise(SubmitEnergyAssistancePromise request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CancelServiceOrderResponse cancelServiceOrder(CancelServiceOrder request) throws BillingAccountDaoException {
		// TODO Auto-generated method stub
		return null;
	}


}