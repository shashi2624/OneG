package com.avaya.ept.onegas.ws.billing.dao;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoException;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraft;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrder;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlan;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlanResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPrice;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPriceResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraft;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterRead;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterReadResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummary;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummaryResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailability;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailabilityResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmount;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmountResponse;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrders;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrdersResponse;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistory;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistoryResponse;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccount;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePayment;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBill;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBillResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCredit;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCreditResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrder;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangement;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangementResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChange;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChangeResponse;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointment;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointmentResponse;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatus;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatus;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromise;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromiseResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPayment;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfo;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfoResponse;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccount;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccountResponse;

public interface IBilingAccountDao {
	
	LookupBillingAccountResponse lookupBillingAccount(LookupBillingAccount request)	throws BillingAccountDaoException;

	GetOpenServiceOrdersResponse getOpenServiceOrders(GetOpenServiceOrders request) throws BillingAccountDaoException;
	
	GetAccountSummaryResponse getAccountSummary(GetAccountSummary request) throws BillingAccountDaoException;
	
	RemoveBankAccountInformationResponse removeBankAccountInformation(RemoveBankAccountInformation request)  throws BillingAccountDaoException;
	
	MakeOneTimePaymentResponse makeOneTimePayment(MakeOneTimePayment request) throws BillingAccountDaoException;
	
	MakeOneTimePaymentWithExistingBankAccountResponse makeOneTimePaymentWithExistingBankAccount (MakeOneTimePaymentWithExistingBankAccount request) throws BillingAccountDaoException;
	
	RegisterBankAccountInformationResponse registerBankAccountInformation (RegisterBankAccountInformation request) throws BillingAccountDaoException;
	
	SubmitMemoPaymentResponse submitMemoPayment(SubmitMemoPayment request) throws BillingAccountDaoException;
	
	EnrollInBankDraftResponse enrollInBankDraft(EnrollInBankDraft request) throws BillingAccountDaoException;
	
	CancelBankDraftResponse cancelBankDraft (CancelBankDraft request) throws BillingAccountDaoException;
	
	UpdateBankDraftInfoResponse updateBankDraftInfo(UpdateBankDraftInfo request) throws BillingAccountDaoException;
	
	RequestDuplicateBillResponse requestDuplicateBill(RequestDuplicateBill request) throws BillingAccountDaoException;

	RequestLetterOfCreditResponse requestLetterOfCredit(RequestLetterOfCredit request) throws BillingAccountDaoException;
	
	SetShareTheWarmthStatusResponse setShareTheWarmthStatus(SetShareTheWarmthStatus request) throws BillingAccountDaoException;

	SetElectronicBillingStatusResponse setElectronicBillingStatus(SetElectronicBillingStatus request) throws BillingAccountDaoException;
	
	ReserveAppointmentResponse reserveAppointment(ReserveAppointment request) throws BillingAccountDaoException;
	
	GetAppointmentAvailabilityResponse getAppointmentAvailability(GetAppointmentAvailability request) throws BillingAccountDaoException;
	
	RequestMoveOutOrderResponse requestMoveOutOrder(RequestMoveOutOrder request) throws BillingAccountDaoException;
	
	RequestServiceOrderChangeResponse requestServiceOrderChange(RequestServiceOrderChange request) throws BillingAccountDaoException;
	
	EnterMeterReadResponse enterMeterRead(EnterMeterRead request) throws BillingAccountDaoException;
	
	EnrollForVoluntaryFixedPriceResponse enrollForVoluntaryFixedPrice(EnrollForVoluntaryFixedPrice request) throws BillingAccountDaoException;
	
	GetPaymentHistoryResponse getPaymentHistory(GetPaymentHistory request) throws BillingAccountDaoException;
	
	ValidateAccountResponse validateAccount(ValidateAccount request) throws BillingAccountDaoException;
	
	RequestPaymentArrangementResponse requestPaymentArrangement(RequestPaymentArrangement request) throws BillingAccountDaoException;
	
	GetAveragePaymentPlanAmountResponse getAveragePaymentPlanAmount(GetAveragePaymentPlanAmount request) throws BillingAccountDaoException;
	
	EnrollForAveragePaymentPlanResponse enrollForAveragePaymentPlan(EnrollForAveragePaymentPlan request) throws BillingAccountDaoException;

	SubmitEnergyAssistancePromiseResponse  submitEnergyAssistancePromise (SubmitEnergyAssistancePromise request) throws BillingAccountDaoException;

	CancelServiceOrderResponse cancelServiceOrder(CancelServiceOrder request) throws BillingAccountDaoException;

}
