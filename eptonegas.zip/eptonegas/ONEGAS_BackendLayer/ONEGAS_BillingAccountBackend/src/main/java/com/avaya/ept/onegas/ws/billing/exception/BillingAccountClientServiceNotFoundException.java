
/*
* BillingAccountClientServiceNotFoundException.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/
package com.avaya.ept.onegas.ws.billing.exception;

/**
 * @author schmidt0
 *
 */
public class BillingAccountClientServiceNotFoundException extends
		BillingAccountClientServiceException {

	/**
	 * 
	 */
	public BillingAccountClientServiceNotFoundException() {
		super();
	}

	/**
	 * @param message
	 * @param statusCode
	 */
	public BillingAccountClientServiceNotFoundException(String message,
			int statusCode) {
		super(message, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * @param message
	 * @param cause
	 * @param statusCode
	 */
	public BillingAccountClientServiceNotFoundException(String message,
			Throwable cause, int statusCode) {
		super(message, cause, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * @param cause
	 * @param statusCode
	 */
	public BillingAccountClientServiceNotFoundException(Throwable cause,
			int statusCode) {
		super(cause, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BillingAccountClientServiceNotFoundException(String message,
			Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public BillingAccountClientServiceNotFoundException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public BillingAccountClientServiceNotFoundException(Throwable cause) {
		super(cause);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -6346065747284357000L;

}
