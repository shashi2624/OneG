/*
 * BillingAccountCallBack.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */

package com.avaya.ept.onegas.ws.billing.dao;



import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoException;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoNotFoundException;

/**
 * Class that simplifies WebService Handling
 * 
 * @author javantario
 * 
 */
public abstract class BillingAccountCallBack<T, R> {

	/**
	 * calls a web-service specific method and makes the error handling
	 * 
	 * @param logger
	 * @param client
	 * @param request
	 * @return web-service response
	 * @throws BillingAccountDaoException
	 */
	@SuppressWarnings("unchecked")
	public R call(Logger logger, WebServiceTemplate client, T request, SoapActionCallback soapActionCallback) throws BillingAccountDaoException {
		try {
			R response = (R) client.marshalSendAndReceive(request, soapActionCallback);
			Integer statusCode = getStatusCode(response);
			JAXBElement<String> statusMessage = getStatusMessage(response);
			if (statusCode != 0) {
				throw new BillingAccountDaoNotFoundException(statusMessage == null ? "Empty Status Message" : statusMessage.getValue(), statusCode);
			}
			return response;
		} catch (ClassCastException cce) {
			throw new BillingAccountDaoException("Service response is null or invalid instance", cce);
		} catch (WebServiceIOException wsioe) {
			logger.error("There was an error invoking the webservice", wsioe);
			throw new BillingAccountDaoException("Web Service Exception", wsioe);
		} catch (WebServiceClientException wsce) {
			logger.error("There was an error invoking the webservice", wsce);
			throw new BillingAccountDaoException("Web Service Client Exception", wsce);
		}
	}

	/**
	 * Get the Response Status Code
	 * 
	 * @param response
	 * @return statusCode
	 */
	public abstract int getStatusCode(R response);

	/**
	 * Get the Response Status Message
	 * 
	 * @param response
	 * @return statusMessage
	 */
	public abstract JAXBElement<String> getStatusMessage(R response);
}
