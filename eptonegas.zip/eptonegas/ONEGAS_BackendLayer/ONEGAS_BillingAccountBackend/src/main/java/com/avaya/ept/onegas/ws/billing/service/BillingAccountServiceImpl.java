package com.avaya.ept.onegas.ws.billing.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountClientServiceException;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountClientServiceNotFoundException;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoException;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoNotFoundException;
import com.avaya.ept.onegas.ws.billing.model.AccountLookupResult;
import com.avaya.ept.onegas.ws.billing.model.AppointmentAvailabilityInfo;
import com.avaya.ept.onegas.ws.billing.model.AppointmentChangeType;
import com.avaya.ept.onegas.ws.billing.model.AppointmentLength;
import com.avaya.ept.onegas.ws.billing.model.AppointmentReservationResponse;
import com.avaya.ept.onegas.ws.billing.model.AppointmentType;
import com.avaya.ept.onegas.ws.billing.model.ArrayOfAccountLookupResult;
import com.avaya.ept.onegas.ws.billing.model.BankAccountInfo;
import com.avaya.ept.onegas.ws.billing.model.BankAccountType;
import com.avaya.ept.onegas.ws.billing.model.BillingAccountInfo;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraft;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrder;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.CustomerInfo;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlan;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlanResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPrice;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPriceResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraft;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollmentActionType;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterRead;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterReadResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummary;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummaryResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailability;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailabilityResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmount;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmountResponse;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrders;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrdersResponse;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistory;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistoryResponse;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccount;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePayment;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.MeterEntryResponse;
import com.avaya.ept.onegas.ws.billing.model.MoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.ObjectFactory;
import com.avaya.ept.onegas.ws.billing.model.OpenServiceOrderDetail;
import com.avaya.ept.onegas.ws.billing.model.PaymentArrangementDetail;
import com.avaya.ept.onegas.ws.billing.model.PaymentHistoryInfo;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBill;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBillResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCredit;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCreditResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrder;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangement;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangementResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChange;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChangeResponse;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointment;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointmentResponse;
import com.avaya.ept.onegas.ws.billing.model.ServiceOrderChangeResponse;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatus;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatus;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromise;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromiseResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPayment;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfo;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfoResponse;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccount;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccountResponse;

public class BillingAccountServiceImpl implements IBillingAccountService {

	private static final String THE_RESPONSE_WAS_NULL = "The response was NULL";
	private static final String NULL = "NULL";
	/**
	 * 
	 */
	private IBilingAccountDao billingAccountDao;

	public List<AccountLookupResult> lookupBillingAcount(String ani, String ldcProvider) throws BillingAccountClientServiceException {
		LookupBillingAccount lookupBillingAccount = getObjectFactory().createLookupBillingAccount();
		JAXBElement<String> jaxbLdcProvider = getObjectFactory().createLookupBillingAccountLdcProvider(ldcProvider);
		lookupBillingAccount.setLdcProvider(jaxbLdcProvider);
		JAXBElement<String> jaxbPhone = getObjectFactory().createLookupBillingAccountPhoneNumber(ani);
		lookupBillingAccount.setPhoneNumber(jaxbPhone);

		try {
			LookupBillingAccountResponse lookupBillingAccountResponse = getBillingAccountDao().lookupBillingAccount(lookupBillingAccount);
			JAXBElement<ArrayOfAccountLookupResult> payload = lookupBillingAccountResponse.getLookupBillingAccountResult().getValue().getPayload();
			return payload.getValue().getAccountLookupResult();

		} catch (BillingAccountDaoNotFoundException e) {
			throw new BillingAccountClientServiceNotFoundException(e, e.getStatusCode());
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	public List<OpenServiceOrderDetail> getOpenServiceOrders(String accountNumber) throws BillingAccountClientServiceException {
		GetOpenServiceOrders getOpenServiceOrders = getObjectFactory().createGetOpenServiceOrders();
		JAXBElement<String> jaxbAccountNumber = getObjectFactory().createGetOpenServiceOrdersBillingAccountNumber(accountNumber);
		getOpenServiceOrders.setBillingAccountNumber(jaxbAccountNumber);

		try {
			GetOpenServiceOrdersResponse getOpenServiceOrdersResponse = getBillingAccountDao().getOpenServiceOrders(getOpenServiceOrders);
			
			if(getOpenServiceOrdersResponse!=null){
				return getOpenServiceOrdersResponse.getGetOpenServiceOrdersResult().getValue().getPayload().getValue().getServiceOrders().getValue().getOpenServiceOrderDetail();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			

		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	public BillingAccountInfo getAccountSummary(String accountNumber) throws BillingAccountClientServiceException {
		GetAccountSummary request = getObjectFactory().createGetAccountSummary();
		JAXBElement<String> jaxbAccountNum = getObjectFactory().createGetAccountSummaryBillingAccountNumber(accountNumber);
		request.setBillingAccountNumber(jaxbAccountNum);
		try {
			GetAccountSummaryResponse accountSummary = getBillingAccountDao().getAccountSummary(request);
			return accountSummary.getGetAccountSummaryResult().getValue().getPayload().getValue();
		} catch (BillingAccountDaoNotFoundException e) {
			throw new BillingAccountClientServiceNotFoundException(e, e.getStatusCode());
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * removeBankAccountInformation(java.lang.String)
	 */
	@Override
	public boolean removeBankAccountInformation(String accountNumber) throws BillingAccountClientServiceException {
		RemoveBankAccountInformation request = getObjectFactory().createRemoveBankAccountInformation();
		JAXBElement<String> jaxbAcctNum = getObjectFactory().createRemoveBankAccountInformationBillingAccountNumber(accountNumber);
		request.setBillingAccountNumber(jaxbAcctNum);
		try {
			RemoveBankAccountInformationResponse accountSummary = getBillingAccountDao().removeBankAccountInformation(request);
			
			if(accountSummary!=null){
				Boolean isPayload = accountSummary.getRemoveBankAccountInformationResult().getValue().isPayload();
				return isPayload.booleanValue();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * makeOneTimePayment(java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public String makeOneTimePayment(String accountNumber, Double paymentAmmount, String bankNumber, String bankAccType, String routingNumber, Date paymentDate) throws BillingAccountClientServiceException {

		MakeOneTimePayment request = getObjectFactory().createMakeOneTimePayment();
		BankAccountInfo accountInfo = getObjectFactory().createBankAccountInfo();

		accountInfo.setAccountNumber(getObjectFactory().createBankAccountInfoAccountNumber(bankNumber));
		accountInfo.setAccountType(BankAccountType.fromValue(bankAccType));
		accountInfo.setRoutingNumber(getObjectFactory().createBankAccountInfoRoutingNumber(routingNumber));

		request.setBankAccount(getObjectFactory().createMakeOneTimePaymentBankAccount(accountInfo));
		request.setBillingAccountNumber(getObjectFactory().createMakeOneTimePaymentBillingAccountNumber(accountNumber));

		request.setAmount(BigDecimal.valueOf(paymentAmmount));

		GregorianCalendar gregCal = new GregorianCalendar();
		gregCal.setTime(paymentDate);
		XMLGregorianCalendar xmlGregCal;
		try {
			xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCal);
			xmlGregCal.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		request.setPaymentDate(xmlGregCal);

		try {
			MakeOneTimePaymentResponse response = getBillingAccountDao().makeOneTimePayment(request);
			return response.getMakeOneTimePaymentResult().getValue().getPayload().getValue();

		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/* (non-Javadoc)
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#makeOneTimePaymentWithExistingBankAccount(java.lang.String, java.lang.Double, java.util.Date)
	 */
	@Override
	public String makeOneTimePaymentWithExistingBankAccount(
			String accountNumber, Double paymentAmmount, Date paymentDate)
			throws BillingAccountClientServiceException {
		
		MakeOneTimePaymentWithExistingBankAccount request = getObjectFactory().createMakeOneTimePaymentWithExistingBankAccount();
		request.setAmount(BigDecimal.valueOf(paymentAmmount));
		request.setBillingAccountNumber(getObjectFactory().createMakeOneTimePaymentBillingAccountNumber(accountNumber));
		GregorianCalendar gregCal = new GregorianCalendar();
		gregCal.setTime(paymentDate);
		XMLGregorianCalendar xmlGregCal;
		try {
			xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCal);
			xmlGregCal.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		request.setPaymentDate(xmlGregCal);
		try {
			MakeOneTimePaymentWithExistingBankAccountResponse response = getBillingAccountDao().makeOneTimePaymentWithExistingBankAccount(request);
			return response.getMakeOneTimePaymentWithExistingBankAccountResult().getValue().getPayload().getValue();
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * registerBankAccountInformation(java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public boolean registerBankAccountInformation(String accountNumber, String bankNumber, String bankAccType, String routingNumber) throws BillingAccountClientServiceException {

		RegisterBankAccountInformation request = getObjectFactory().createRegisterBankAccountInformation();
		BankAccountInfo accountInfo = getObjectFactory().createBankAccountInfo();
		accountInfo.setAccountNumber(getObjectFactory().createBankAccountInfoAccountNumber(bankNumber));
		accountInfo.setAccountType(BankAccountType.fromValue(bankAccType));
		accountInfo.setRoutingNumber(getObjectFactory().createBankAccountInfoRoutingNumber(routingNumber));
		request.setBankAccount(getObjectFactory().createRegisterBankAccountInformationBankAccount(accountInfo));
		request.setBillingAccountNumber(getObjectFactory().createRegisterBankAccountInformationBillingAccountNumber(accountNumber));

		try {
			RegisterBankAccountInformationResponse response = getBillingAccountDao().registerBankAccountInformation(request);

			if(response!=null){
				return response.getRegisterBankAccountInformationResult().getValue().isPayload().booleanValue();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}

		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * submitMemoPayment(java.lang.String, java.lang.String, java.lang.String,
	 * java.util.Date)
	 */
	@Override
	public String submitMemoPayment(String accountNumber, Double paymentAmt, String receiptNum, Date paymentDate) throws BillingAccountClientServiceException {

		SubmitMemoPayment request = getObjectFactory().createSubmitMemoPayment();

		GregorianCalendar gregCal = new GregorianCalendar();
		gregCal.setTime(paymentDate);
		XMLGregorianCalendar xmlGregCal;

		try {
			xmlGregCal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCal);
			xmlGregCal.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		request.setReceiptDate(xmlGregCal);

		request.setBillingAccountNumber(getObjectFactory().createSubmitMemoPaymentBillingAccountNumber(accountNumber));
		request.setReceiptNumber(getObjectFactory().createSubmitMemoPaymentReceiptNumber(receiptNum));
		request.setAmount(BigDecimal.valueOf(paymentAmt));

		try {
			SubmitMemoPaymentResponse response = getBillingAccountDao().submitMemoPayment(request);
			return response.getSubmitMemoPaymentResult().getValue().getPayload().getValue();
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	public IBilingAccountDao getBillingAccountDao() {
		return billingAccountDao;
	}

	public void setBillingAccountDao(IBilingAccountDao billingAccountDao) {
		this.billingAccountDao = billingAccountDao;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * enrollInBankDraft(java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public boolean enrollInBankDraft(String accountNumber, String bankNumber, String bankAccType, String routingNumber) throws BillingAccountClientServiceException {
		EnrollInBankDraft enrollInBankDraft = getObjectFactory().createEnrollInBankDraft();
		BankAccountInfo bankAccountInfo = getObjectFactory().createBankAccountInfo();
		bankAccountInfo.setAccountNumber(getObjectFactory().createBankAccountInfoAccountNumber(bankNumber));
		bankAccountInfo.setRoutingNumber(getObjectFactory().createBankAccountInfoRoutingNumber(routingNumber));
		bankAccountInfo.setAccountType(BankAccountType.fromValue(bankAccType));
		enrollInBankDraft.setBankAccount(getObjectFactory().createEnrollInBankDraftBankAccount(bankAccountInfo));
		enrollInBankDraft.setBillingAccountNumber(getObjectFactory().createEnrollInBankDraftBillingAccountNumber(accountNumber));
		try {
			EnrollInBankDraftResponse response = getBillingAccountDao().enrollInBankDraft(enrollInBankDraft);
			
			if(response!=null){
				return response.getEnrollInBankDraftResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	@Override
	public boolean cancelServiceOrder(String billingAccountNumber, String serviceOrderNumber, String cancelReasonCode, String cancelNotes) throws BillingAccountClientServiceException {
		CancelServiceOrder cancelServiceOrder = getObjectFactory().createCancelServiceOrder();
		cancelServiceOrder.setBillingAccountNumber(getObjectFactory().createCancelServiceOrderBillingAccountNumber(billingAccountNumber));
		cancelServiceOrder.setServiceOrderNumber(getObjectFactory().createCancelServiceOrderServiceOrderNumber(serviceOrderNumber));
		cancelServiceOrder.setCancelReasonCode(getObjectFactory().createCancelServiceOrderCancelReasonCode(cancelReasonCode));
		cancelServiceOrder.setCancelNotes(getObjectFactory().createCancelServiceOrderCancelNotes(cancelNotes));
		
		try {
			CancelServiceOrderResponse response = getBillingAccountDao().cancelServiceOrder(cancelServiceOrder);
			
			if(response!=null){
				return response.getCancelServiceOrderResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	public ObjectFactory getObjectFactory() {

		return new ObjectFactory();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * cancelBankDraft(java.lang.String)
	 */
	@Override
	public boolean cancelBankDraft(String accountNumber) throws BillingAccountClientServiceException {
		CancelBankDraft cancelBankDraft = getObjectFactory().createCancelBankDraft();
		cancelBankDraft.setBillingAccountNumber(getObjectFactory().createCancelBankDraftBillingAccountNumber(accountNumber));
		try {
			CancelBankDraftResponse response = getBillingAccountDao().cancelBankDraft(cancelBankDraft);
			
			if(response!=null){
				return response.getCancelBankDraftResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * updateBankDraftInfo(java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public boolean updateBankDraftInfo(String accountNumber, String bankNumber, String bankAccType, String routingNumber) throws BillingAccountClientServiceException {

		UpdateBankDraftInfo request = getObjectFactory().createUpdateBankDraftInfo();
		request.setBillingAccountNumber(getObjectFactory().createUpdateBankDraftInfoBillingAccountNumber(accountNumber));
		BankAccountInfo bankAccountInfo = getObjectFactory().createBankAccountInfo();
		bankAccountInfo.setAccountNumber(getObjectFactory().createBankAccountInfoAccountNumber(bankNumber));
		bankAccountInfo.setAccountType(BankAccountType.fromValue(bankAccType));
		bankAccountInfo.setRoutingNumber(getObjectFactory().createBankAccountInfoRoutingNumber(routingNumber));
		request.setBankAccount(getObjectFactory().createUpdateBankDraftInfoBankAccount(bankAccountInfo));
		try {
			UpdateBankDraftInfoResponse response = getBillingAccountDao().updateBankDraftInfo(request);
			
			if(response!=null){
				return response.getUpdateBankDraftInfoResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * requestDuplicateBill(java.lang.String)
	 */
	@Override
	public boolean requestDuplicateBill(String accountNumber, Date billDate) throws BillingAccountClientServiceException {
		RequestDuplicateBill request = getObjectFactory().createRequestDuplicateBill();
		request.setBillingAccountNumber(getObjectFactory().createRequestDuplicateBillBillingAccountNumber(accountNumber));
		XMLGregorianCalendar xmlGregCalNow;
		try {
			GregorianCalendar gregCalNow = new GregorianCalendar();
			gregCalNow.setTime(billDate);
			xmlGregCalNow = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCalNow);
			xmlGregCalNow.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		request.setBillDate(xmlGregCalNow);

		try {
			RequestDuplicateBillResponse response = getBillingAccountDao().requestDuplicateBill(request);
			return response.getRequestDuplicateBillResult().getValue().isPayload();
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * requestLetterOfCredit(java.lang.String)
	 */
	@Override
	public boolean requestLetterOfCredit(String accountNumber) throws BillingAccountClientServiceException {
		RequestLetterOfCredit request = getObjectFactory().createRequestLetterOfCredit();
		request.setBillingAccountNumber(getObjectFactory().createRequestDuplicateBillBillingAccountNumber(accountNumber));
		try {
			RequestLetterOfCreditResponse response = getBillingAccountDao().requestLetterOfCredit(request);
			
			if(response!=null){
				return response.getRequestLetterOfCreditResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * setShareTheWarmthStatus(java.lang.String, java.lang.Double,
	 * java.lang.String, java.util.Date, java.util.Date)
	 */
	@Override
	public boolean setShareTheWarmthStatus(String accountNumber, Double paymentAmt, String acction, Date startDate, Date endDate) throws BillingAccountClientServiceException {
		SetShareTheWarmthStatus request = getObjectFactory().createSetShareTheWarmthStatus();
		request.setAction(EnrollmentActionType.fromValue(acction));
		request.setAmount(BigDecimal.valueOf(paymentAmt));
		request.setBillingAccountNumber(getObjectFactory().createSetShareTheWarmthStatusBillingAccountNumber(accountNumber));
		XMLGregorianCalendar xmlGregCalStart;
		XMLGregorianCalendar xmlGregCalEnd;
		try {
			if (startDate!=null) {
				GregorianCalendar gregCalStart = new GregorianCalendar();
				gregCalStart.setTime(startDate);
				xmlGregCalStart = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCalStart);
				xmlGregCalStart.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
				request.setStartDate(getObjectFactory().createSetShareTheWarmthStatusStartDate(xmlGregCalStart));
			}
			if (endDate != null) {
				GregorianCalendar gregCalEnd = new GregorianCalendar();
				gregCalEnd.setTime(endDate);
				xmlGregCalEnd = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCalEnd);
				xmlGregCalEnd.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
				request.setEndDate(getObjectFactory().createSetShareTheWarmthStatusEndDate(xmlGregCalEnd));
			}
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		try {
			SetShareTheWarmthStatusResponse response = getBillingAccountDao().setShareTheWarmthStatus(request);

			if(response!=null){
				return response.getSetShareTheWarmthStatusResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL);
			}
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * setElectronicBillingStatus(java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public boolean setElectronicBillingStatus(String accountNumber, String email, String acction) throws BillingAccountClientServiceException {
		SetElectronicBillingStatus request = getObjectFactory().createSetElectronicBillingStatus();
		request.setBillingAccountNumber(getObjectFactory().createSetElectronicBillingStatusBillingAccountNumber(accountNumber));
		request.setEmailAddress(getObjectFactory().createSetElectronicBillingStatusEmailAddress(email));
		request.setEnrollmentIndicator(EnrollmentActionType.fromValue(acction));

		try {
			SetElectronicBillingStatusResponse response = getBillingAccountDao().setElectronicBillingStatus(request);
			
			if(response!=null){
				return response.getSetElectronicBillingStatusResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * reserveAppointment(java.lang.String, java.lang.String, java.util.Date,
	 * java.lang.String)
	 */
	@Override
	public AppointmentReservationResponse callReserveAppointment(String accountNumber, AppointmentType appType, Date apptDate, String duration, String eventCode) throws BillingAccountClientServiceException {

		ReserveAppointment request = getObjectFactory().createReserveAppointment();
		request.setBillingAccountNumber(getObjectFactory().createReserveAppointmentBillingAccountNumber(accountNumber));
		request.setAppointmentWindow(getObjectFactory().createReserveAppointmentAppointmentWindow(duration));
		XMLGregorianCalendar xmlReqDate;
		GregorianCalendar reqDate = new GregorianCalendar();
		reqDate.setTime(apptDate);
		try {
			xmlReqDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(reqDate);
			xmlReqDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		request.setRequestedDate(xmlReqDate);
		request.setServiceOrderType(appType);
		request.setEventCode(getObjectFactory().createReserveAppointmentEventCode(eventCode));
		try {
			ReserveAppointmentResponse response = getBillingAccountDao().reserveAppointment(request);
			return response.getReserveAppointmentResult().getValue().getPayload().getValue();

		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * getAppointmentAvailability(java.lang.String, java.lang.String,
	 * java.util.Date, java.lang.String)
	 */
	@Override
	public AppointmentAvailabilityInfo getAppointmentAvailability(String accountNumber, String appointment, Date apptDate, String duration) throws BillingAccountClientServiceException {
		GetAppointmentAvailability request = getObjectFactory().createGetAppointmentAvailability();
		request.setBillingAccountNumber(getObjectFactory().createGetAppointmentAvailabilityBillingAccountNumber(accountNumber));
		request.setAppointment(AppointmentType.fromValue(appointment));
		XMLGregorianCalendar xmlGregCalDate;
		GregorianCalendar gregCalDate = new GregorianCalendar();
		gregCalDate.setTime(apptDate);
		try {
			xmlGregCalDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCalDate);
			xmlGregCalDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		request.setAppointmentDate(xmlGregCalDate);

		request.setDuration(AppointmentLength.fromValue(duration));

		try {
			GetAppointmentAvailabilityResponse response = getBillingAccountDao().getAppointmentAvailability(request);
			return response.getGetAppointmentAvailabilityResult().getValue().getPayload().getValue();
		} catch (BillingAccountDaoNotFoundException e) {
			throw new BillingAccountClientServiceNotFoundException(e, e.getStatusCode());
			} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * requestMoveOutOrder(java.lang.String, java.util.Date, java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public MoveOutOrderResponse requestMoveOutOrder(String accountNumber, Date apptDate, String phoneNum, String confNumb, String apptWindow, String firstName, String midName, String lastName) throws BillingAccountClientServiceException {
		RequestMoveOutOrder request = getObjectFactory().createRequestMoveOutOrder();
		request.setBillingAccountNumber(getObjectFactory().createRequestMoveOutOrderBillingAccountNumber(accountNumber));
		request.setAppointmentConfirmationNumber(getObjectFactory().createRequestMoveOutOrderAppointmentConfirmationNumber(confNumb));
		request.setAppointmentWindow(getObjectFactory().createRequestMoveOutOrderAppointmentWindow(apptWindow));
		request.setPhoneNumber(getObjectFactory().createRequestMoveOutOrderPhoneNumber(phoneNum));

		GregorianCalendar gregCalDate = new GregorianCalendar();
		gregCalDate.setTime(apptDate);
		XMLGregorianCalendar xmlGregCallApptDate;
		try {
			xmlGregCallApptDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCalDate);
			xmlGregCallApptDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		} catch (DatatypeConfigurationException e) {
			throw new BillingAccountClientServiceException(e);
		}
		request.setRequestedDate(xmlGregCallApptDate);
		CustomerInfo custInfo = getObjectFactory().createCustomerInfo();
		custInfo.setFirstName(getObjectFactory().createCustomerInfoFirstName(firstName));
		custInfo.setMiddleName(getObjectFactory().createCustomerInfoMiddleName(midName));
		custInfo.setLastName(getObjectFactory().createCustomerInfoLastName(lastName));
		request.setCustomer(getObjectFactory().createRequestMoveOutOrderCustomer(custInfo));

		try {
			RequestMoveOutOrderResponse response = getBillingAccountDao().requestMoveOutOrder(request);
			return response.getRequestMoveOutOrderResult().getValue().getPayload().getValue();
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * RequestServiceOrderChange(java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String, java.util.Date, java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public ServiceOrderChangeResponse requestServiceOrderChange(String accountNumber, String svcOrderNum, String changeType, String svcOrderType, Date reqDate, String duration, String apptWindow, String confNumber) throws BillingAccountClientServiceException {
		RequestServiceOrderChange request = getObjectFactory().createRequestServiceOrderChange();
		request.setBillingAccountNumber(getObjectFactory().createRequestServiceOrderChangeBillingAccountNumber(accountNumber));
		request.setServiceOrderNumber(getObjectFactory().createRequestServiceOrderChangeServiceOrderNumber(svcOrderNum));
		request.setChangeType(AppointmentChangeType.fromValue(changeType));
		if (!NULL.equalsIgnoreCase(svcOrderType)) {
			request.setServiceOrderType(getObjectFactory().createRequestServiceOrderChangeServiceOrderType(svcOrderType));

		}
		if (reqDate != null) {
			GregorianCalendar gregCalDate = new GregorianCalendar();
			gregCalDate.setTime(reqDate);
			XMLGregorianCalendar xmlGregCalReqDate;
			try {
				xmlGregCalReqDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregCalDate);
				xmlGregCalReqDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
			} catch (DatatypeConfigurationException e) {
				throw new BillingAccountClientServiceException(e);
			}
			request.setRequestedDate(getObjectFactory().createRequestServiceOrderChangeRequestedDate(xmlGregCalReqDate));
		}
		if (!NULL.equalsIgnoreCase(duration)) {
			request.setDuration(AppointmentLength.fromValue(duration));
		}

		if (!NULL.equalsIgnoreCase(apptWindow)) {
			request.setAppointmentWindow(getObjectFactory().createRequestServiceOrderChangeAppointmentWindow(apptWindow));
		}

		request.setAppointmentConfirmationNumber(getObjectFactory().createRequestServiceOrderChangeAppointmentConfirmationNumber(confNumber));

		try {
			RequestServiceOrderChangeResponse response = getBillingAccountDao().requestServiceOrderChange(request);
			if(response!=null){
				return response.getRequestServiceOrderChangeResult().getValue().getPayload().getValue();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#enterMeterRead
	 * (java.lang.String, java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public MeterEntryResponse enterMeterRead(String accountNumber, Integer serviceID, Integer meterReading, boolean forceEntry) throws BillingAccountClientServiceException {
		EnterMeterRead request = getObjectFactory().createEnterMeterRead();
		request.setBillingAccountNumber(getObjectFactory().createEnterMeterReadBillingAccountNumber(accountNumber));
		request.setServiceNumber(serviceID);
		request.setForceEntry(getObjectFactory().createEnterMeterReadForceEntry(forceEntry));
		request.setReading(meterReading);

		try {
			EnterMeterReadResponse response = getBillingAccountDao().enterMeterRead(request);
			
			if(response!=null){
				return response.getEnterMeterReadResult().getValue().getPayload().getValue();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * enrollForVoluntaryFixedPrice(java.lang.String)
	 */
	@Override
	public boolean enrollForVoluntaryFixedPrice(String accountNumber, Integer serviceNumber) throws BillingAccountClientServiceException {
		EnrollForVoluntaryFixedPrice request = getObjectFactory().createEnrollForVoluntaryFixedPrice();
		request.setBillingAccountNumber(getObjectFactory().createEnrollForVoluntaryFixedPriceBillingAccountNumber(accountNumber));
		request.setServiceNumber(serviceNumber);

		try {
			EnrollForVoluntaryFixedPriceResponse response = getBillingAccountDao().enrollForVoluntaryFixedPrice(request);
			
			if(response!=null){
				return response.getEnrollForVoluntaryFixedPriceResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * getPaymentHistory(java.lang.String)
	 */
	@Override
	public PaymentHistoryInfo getPaymentHistory(String accountNumber) throws BillingAccountClientServiceException {
		GetPaymentHistory request = getObjectFactory().createGetPaymentHistory();
		request.setBillingAccountNumber(getObjectFactory().createGetPaymentHistoryBillingAccountNumber(accountNumber));
		try {
			GetPaymentHistoryResponse response = getBillingAccountDao().getPaymentHistory(request);
			
			if(response!=null){
				return response.getGetPaymentHistoryResult().getValue().getPayload().getValue();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * submitEnergyAssistancePromise(java.lang.String, java.lang.String,
	 * java.lang.Double)
	 */
	@Override
	public boolean submitEnergyAssistancePromise(String accountNumber, String agencyCode, Double paymentAmt) throws BillingAccountClientServiceException {
		SubmitEnergyAssistancePromise request = getObjectFactory().createSubmitEnergyAssistancePromise();
		request.setBillingAccountNumber(getObjectFactory().createSubmitEnergyAssistancePromiseBillingAccountNumber(accountNumber));
		request.setEnergyAssistanceCode(getObjectFactory().createSubmitEnergyAssistancePromiseEnergyAssistanceCode(agencyCode));
		request.setPromiseAmount(BigDecimal.valueOf(paymentAmt));

		try {
			SubmitEnergyAssistancePromiseResponse response = getBillingAccountDao().submitEnergyAssistancePromise(request);
			
			if(response!=null){
				return response.getSubmitEnergyAssistancePromiseResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * validateAccount(java.lang.String, java.lang.String)
	 */
	@Override
	public boolean validateAccount(String accountNumber, String lastSSN) throws BillingAccountClientServiceException {
		ValidateAccount request = getObjectFactory().createValidateAccount();
		request.setBillingAccountNumber(getObjectFactory().createValidateAccountBillingAccountNumber(accountNumber));
		request.setLast4OfSsn(getObjectFactory().createValidateAccountLast4OfSsn(lastSSN));
		try {
			ValidateAccountResponse response = getBillingAccountDao().validateAccount(request);
			
			if(response!=null){
				return response.getValidateAccountResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * requestPaymentArrangement(java.lang.String, boolean, java.lang.Double,
	 * java.lang.Double, java.lang.Double)
	 */
	@Override
	public PaymentArrangementDetail requestPaymentArrangement(String accountNumber, boolean createArrangement, Double installmentAmount, Integer numberOfPayments, Double downPaymentAmount) throws BillingAccountClientServiceException {
		RequestPaymentArrangement request = getObjectFactory().createRequestPaymentArrangement();
		request.setBillingAccountNumber(getObjectFactory().createRequestPaymentArrangementBillingAccountNumber(accountNumber));
		request.setCreateArrangement(createArrangement);
		request.setInstallmentAmount(BigDecimal.valueOf(installmentAmount));
		request.setNumberOfInstallments(numberOfPayments);
		request.setDownPaymentAmount(BigDecimal.valueOf(downPaymentAmount));

		try {
			RequestPaymentArrangementResponse response = getBillingAccountDao().requestPaymentArrangement(request);

			if(response!=null){
				return response.getRequestPaymentArrangementResult().getValue().getPayload().getValue();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * getAveragePaymentPlanAmount(java.lang.String, boolean)
	 */
	@Override
	public Double getAveragePaymentPlanAmount(String accountNumber, Integer serviceNumber) throws BillingAccountClientServiceException {
		GetAveragePaymentPlanAmount request = getObjectFactory().createGetAveragePaymentPlanAmount();
		request.setBillingAccountNumber(getObjectFactory().createGetAveragePaymentPlanAmountBillingAccountNumber(accountNumber));
		request.setServiceNumber(serviceNumber);

		try {
			GetAveragePaymentPlanAmountResponse response = getBillingAccountDao().getAveragePaymentPlanAmount(request);
			
			if(response!=null){
				return response.getGetAveragePaymentPlanAmountResult().getValue().getPayload().getValue().doubleValue();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			

		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.service.IBillingAccountService#
	 * enrollForAveragePaymentPlan(java.lang.String, java.lang.Integer)
	 */
	@Override
	public boolean enrollForAveragePaymentPlan(String accountNumber, Integer serviceNumber) throws BillingAccountClientServiceException {
		EnrollForAveragePaymentPlan request = getObjectFactory().createEnrollForAveragePaymentPlan();
		request.setBillingAccountNumber(getObjectFactory().createEnrollForAveragePaymentPlanBillingAccountNumber(accountNumber));
		request.setServiceNumber(serviceNumber);
		try {
			EnrollForAveragePaymentPlanResponse response = getBillingAccountDao().enrollForAveragePaymentPlan(request);
			
			if(response!=null){
				return response.getEnrollForAveragePaymentPlanResult().getValue().isPayload();
			}else{
				throw new BillingAccountClientServiceException(THE_RESPONSE_WAS_NULL); 
			}
			
		} catch (BillingAccountDaoException e) {
			throw new BillingAccountClientServiceException(e,e.getStatusCode());
		}
	}


}