package com.avaya.ept.onegas.ws.billing.exception;

/**
 * 
 * @author schmidt0
 * 
 */
public class BillingAccountDaoNotFoundException extends BillingAccountDaoException {

	/**
	 * @param message
	 * @param statusCode
	 */
	public BillingAccountDaoNotFoundException(String message, int statusCode) {
		super(message, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * @param message
	 * @param cause
	 * @param statusCode
	 */
	public BillingAccountDaoNotFoundException(String message, Throwable cause,
			int statusCode) {
		super(message, cause, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * @param cause
	 * @param statusCode
	 */
	public BillingAccountDaoNotFoundException(Throwable cause, int statusCode) {
		super(cause, statusCode);
		setStatusCode(statusCode);
	}

	private static final long serialVersionUID = 1L;
	
	public BillingAccountDaoNotFoundException() {
	}

	/**
	 * @param message
	 */
	public BillingAccountDaoNotFoundException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public BillingAccountDaoNotFoundException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BillingAccountDaoNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

}
