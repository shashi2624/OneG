package com.avaya.ept.onegas.ws.billing.service;

import java.util.Calendar;
import java.util.Date;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountClientServiceException;
import com.avaya.ept.onegas.ws.billing.model.AppointmentType;
import com.avaya.ept.onegas.ws.billing.model.BillingAccountInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:billingBackendContextTest.xml")
public class BillingAccountServiceTest {
	
    /**
	 * 
	 */
	private static final String ACC_NUM = "1111111111111111";
	@Autowired
    @Qualifier(value = "billingAccountService")
    private IBillingAccountService billingAccountService;
    
   
	@Test
	public void cancelTest(){
		try {
			billingAccountService.cancelBankDraft("2111516401834343");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	@Test
	public void cancelServiceOrderTest(){
		try {
			billingAccountService.cancelServiceOrder("2100035471012250", "5580420", "", "");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	@Test
	public void getAccSummTest(){
		try {
			BillingAccountInfo accountSummary = billingAccountService.getAccountSummary(ACC_NUM);
			accountSummary.getAccountNumber();
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void getAptAvailTest(){
		try {
			Calendar instance = Calendar.getInstance();
			instance.set(2016, 0, 9, 14, 28);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date time = instance.getTime();
			billingAccountService.getAppointmentAvailability(ACC_NUM, "MoveOut", time, "AllDay");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void getOpenServiceOrdersTest(){
		try {
			billingAccountService.getOpenServiceOrders(ACC_NUM);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void enrollBankDraftTest(){
		try {
			billingAccountService.enrollInBankDraft(ACC_NUM, "12345678", "Checking", "301179892");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void enrollForAverageTest(){
		try {
			billingAccountService.enrollForAveragePaymentPlan(ACC_NUM, 1);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void enrollForVoluntaryTest(){
		try {
			billingAccountService.enrollForVoluntaryFixedPrice(ACC_NUM,1);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void getAveragePaymentTest(){
		try {
			billingAccountService.getAveragePaymentPlanAmount(ACC_NUM,1);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void enterMeterReadTest(){
		try {
			billingAccountService.enterMeterRead(ACC_NUM,1, 6681, false);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void lookupBillingAccountTest(){
		try {
			billingAccountService.lookupBillingAcount("9181239876", "ONG");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void removeBankAccountInfoTest(){
		try {
			billingAccountService.removeBankAccountInformation(ACC_NUM);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void makeOneTimePayuTest(){
		try {
			//2016-01-07T12:57:00
			Calendar instance = Calendar.getInstance();
			instance.set(2016, 0, 7, 12, 57);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date paymentDate = instance.getTime();
			billingAccountService.makeOneTimePayment(ACC_NUM, 5.01d, "12345678", "Checking", "301179892", paymentDate);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void makeOneTimePayExistingAccTest(){
		try {
			//2016-01-07T12:57:00
			Calendar instance = Calendar.getInstance();
			instance.set(2016, 0, 7, 12, 57);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date paymentDate = instance.getTime();
			billingAccountService.makeOneTimePaymentWithExistingBankAccount(ACC_NUM, 5.01d, paymentDate);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Test
	public void registerBnkAcctInfoTest(){
		try {
			billingAccountService.registerBankAccountInformation(ACC_NUM, "12345678", "Savings", "301179892");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Test
	public void submitMecomomoPayTest(){
		try {
			Calendar instance = Calendar.getInstance();
			instance.set(2016, 0, 7, 13, 40);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date paymentDate = instance.getTime();
			billingAccountService.submitMemoPayment(ACC_NUM, 2.05d,"546585", paymentDate);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void updBankDraftInfoTest(){
		try {
			billingAccountService.updateBankDraftInfo(ACC_NUM, "12345678", "Checking", "301179892");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void requestDuplicateBillTest(){
		try {
			Calendar instance = Calendar.getInstance();
			instance.set(2016, 0, 7, 13, 3);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date billDate = instance.getTime();
			billingAccountService.requestDuplicateBill(ACC_NUM,billDate);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Test
	public void requestLeterOfCreditTest(){
		try {
			billingAccountService.requestLetterOfCredit(ACC_NUM);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Test
	public void setShareTheWarmthStatusTest(){
		try {
			Calendar instance = Calendar.getInstance();
			instance.set(2016, Calendar.JANUARY, 7, 13, 36);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date startDate = instance.getTime();
			
			instance.set(2016, Calendar.DECEMBER, 7, 13, 36);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date endDate = instance.getTime();
			
			billingAccountService.setShareTheWarmthStatus(ACC_NUM, 0d, "Enroll", startDate, endDate);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void callReserveAppointmentTest(){
		try {
			Calendar instance = Calendar.getInstance();
			instance.set(2016, Calendar.JANUARY, 13, 0, 0);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date apptDate = instance.getTime();
			billingAccountService.callReserveAppointment(ACC_NUM, AppointmentType.MOVE_OUT, apptDate, "ALL DAY", "505");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void requestMoveOutOrderTest(){
		try {
			Calendar instance = Calendar.getInstance();
			instance.set(2016, Calendar.JANUARY, 10, 16, 21);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date apptDate = instance.getTime();
			billingAccountService.requestMoveOutOrder(ACC_NUM, apptDate, "9181239876", "AVAIL-0005539889", "ALL DAY", "John", "", "Smith");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void requestServiceOrderChangeTest(){
		try {
			Calendar instance = Calendar.getInstance();
			instance.set(2016, Calendar.JANUARY, 17,0,0);
			instance.set(Calendar.SECOND, 0);
			instance.set(Calendar.MILLISECOND, 0);
			Date reqDate = instance.getTime();
			billingAccountService.requestServiceOrderChange(ACC_NUM, "7102621", "Reschedule", "505", reqDate, "AllDay", "ALL DAY", "AVAIL-0005539869");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void setElectronicBillingStatusResponseTest(){
		try {
			billingAccountService.setElectronicBillingStatus(ACC_NUM, "james.coone@onegas.com", "Enroll");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void getPaymentHistoryTest(){
		try {
			billingAccountService.getPaymentHistory(ACC_NUM);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void validateAccountTest(){
		try {
			billingAccountService.validateAccount(ACC_NUM, "1234");
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void requestPaymentArrangement(){
		try {
			billingAccountService.requestPaymentArrangement(ACC_NUM, false, 0d, 0, 0d);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}
	@Test
	public void submitEnergyAssistancePromiseTest(){
		try {
			billingAccountService.submitEnergyAssistancePromise(ACC_NUM, "1234", 0d);
		} catch (BillingAccountClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	public IBillingAccountService getBillingAccountService() {
		return billingAccountService;
	}

	public void setBillingAccountService(IBillingAccountService billingAccountService) {
		this.billingAccountService = billingAccountService;
	}


}
