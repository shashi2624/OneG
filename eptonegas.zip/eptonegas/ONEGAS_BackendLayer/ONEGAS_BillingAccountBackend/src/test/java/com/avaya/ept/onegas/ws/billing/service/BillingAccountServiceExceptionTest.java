package com.avaya.ept.onegas.ws.billing.service;

import java.util.Calendar;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountClientServiceException;
import com.avaya.ept.onegas.ws.billing.model.AppointmentType;
import com.avaya.ept.onegas.ws.billing.model.BillingAccountInfo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:billingBackendExceptionContextTest.xml")
public class BillingAccountServiceExceptionTest {

	/**
	 * 
	 */
	private static final String ACC_NUM = "1111111111111111";
	@Autowired
	@Qualifier(value = "billingAccountService")
	private IBillingAccountService billingAccountService;

	@Test(expected = BillingAccountClientServiceException.class)
	public void cancelTest() throws BillingAccountClientServiceException {

		billingAccountService.cancelBankDraft("2111516401834343");

	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void getAccSummTest() throws BillingAccountClientServiceException {

		BillingAccountInfo accountSummary = billingAccountService.getAccountSummary(ACC_NUM);
		accountSummary.getAccountNumber();

	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void getAptAvailTest() throws BillingAccountClientServiceException {

		Calendar instance = Calendar.getInstance();
		instance.set(2016, 0, 9, 14, 28);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date time = instance.getTime();
		billingAccountService.getAppointmentAvailability(ACC_NUM, "MoveOut", time, "AllDay");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void getOpenServiceOrdersTest() throws BillingAccountClientServiceException {

		billingAccountService.getOpenServiceOrders(ACC_NUM);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void enrollBankDraftTest() throws BillingAccountClientServiceException {

		billingAccountService.enrollInBankDraft(ACC_NUM, "12345678", "Checking", "301179892");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void enrollForAverageTest() throws BillingAccountClientServiceException {

		billingAccountService.enrollForAveragePaymentPlan(ACC_NUM, 1);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void enrollForVoluntaryTest() throws BillingAccountClientServiceException {

		billingAccountService.enrollForVoluntaryFixedPrice(ACC_NUM, 1);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void getAveragePaymentTest() throws BillingAccountClientServiceException {

		billingAccountService.getAveragePaymentPlanAmount(ACC_NUM, 1);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void enterMeterReadTest() throws BillingAccountClientServiceException {

		billingAccountService.enterMeterRead(ACC_NUM, 1, 6681, false);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void lookupBillingAccountTest() throws BillingAccountClientServiceException {

		billingAccountService.lookupBillingAcount("9181239876", "ONG");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void removeBankAccountInfoTest() throws BillingAccountClientServiceException {

		billingAccountService.removeBankAccountInformation(ACC_NUM);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void makeOneTimePayuTest() throws BillingAccountClientServiceException {

		// 2016-01-07T12:57:00
		Calendar instance = Calendar.getInstance();
		instance.set(2016, 0, 7, 12, 57);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date paymentDate = instance.getTime();
		billingAccountService.makeOneTimePayment(ACC_NUM, 5.01d, "12345678", "Checking", "301179892", paymentDate);
	}
	@Test(expected = BillingAccountClientServiceException.class)
	public void makeOneTimePayExistingAccTest() throws BillingAccountClientServiceException {
		
		// 2016-01-07T12:57:00
		Calendar instance = Calendar.getInstance();
		instance.set(2016, 0, 7, 12, 57);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date paymentDate = instance.getTime();
		billingAccountService.makeOneTimePaymentWithExistingBankAccount(ACC_NUM, 5.01d, paymentDate);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void registerBnkAcctInfoTest() throws BillingAccountClientServiceException {

		billingAccountService.registerBankAccountInformation(ACC_NUM, "12345678", "Savings", "301179892");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void submitMecomomoPayTest() throws BillingAccountClientServiceException {

		Calendar instance = Calendar.getInstance();
		instance.set(2016, 0, 7, 13, 40);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date paymentDate = instance.getTime();
		billingAccountService.submitMemoPayment(ACC_NUM, 2.05d, "546585", paymentDate);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void updBankDraftInfoTest() throws BillingAccountClientServiceException {

		billingAccountService.updateBankDraftInfo(ACC_NUM, "12345678", "Checking", "301179892");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void requestDuplicateBillTest() throws BillingAccountClientServiceException {

		Calendar instance = Calendar.getInstance();
		instance.set(2016, 0, 7, 13, 3);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date billDate = instance.getTime();
		billingAccountService.requestDuplicateBill(ACC_NUM, billDate);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void requestLeterOfCreditTest() throws BillingAccountClientServiceException {

		billingAccountService.requestLetterOfCredit(ACC_NUM);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void setShareTheWarmthStatusTest() throws BillingAccountClientServiceException {

		Calendar instance = Calendar.getInstance();
		instance.set(2016, Calendar.JANUARY, 7, 13, 36);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date startDate = instance.getTime();

		instance.set(2016, Calendar.DECEMBER, 7, 13, 36);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date endDate = instance.getTime();

		billingAccountService.setShareTheWarmthStatus(ACC_NUM, 0d, "Enroll", startDate, endDate);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void callReserveAppointmentTest() throws BillingAccountClientServiceException {

		Calendar instance = Calendar.getInstance();
		instance.set(2016, Calendar.JANUARY, 13, 0, 0);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date apptDate = instance.getTime();
		billingAccountService.callReserveAppointment(ACC_NUM, AppointmentType.MOVE_OUT, apptDate, "ALL DAY", "505");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void requestMoveOutOrderTest() throws BillingAccountClientServiceException {

		Calendar instance = Calendar.getInstance();
		instance.set(2016, Calendar.JANUARY, 10, 16, 21);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date apptDate = instance.getTime();
		billingAccountService.requestMoveOutOrder(ACC_NUM, apptDate, "9181239876", "AVAIL-0005539889", "ALL DAY", "John", "", "Smith");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void requestServiceOrderChangeTest() throws BillingAccountClientServiceException {

		Calendar instance = Calendar.getInstance();
		instance.set(2016, Calendar.JANUARY, 17, 0, 0);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		Date reqDate = instance.getTime();

		billingAccountService.requestServiceOrderChange(ACC_NUM, "7102621", "Reschedule", "505", reqDate, "AllDay", "ALL DAY", "AVAIL-0005539869");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void setElectronicBillingStatusResponseTest() throws BillingAccountClientServiceException {

		billingAccountService.setElectronicBillingStatus(ACC_NUM, "james.coone@onegas.com", "Enroll");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void getPaymentHistoryTest() throws BillingAccountClientServiceException {

		billingAccountService.getPaymentHistory(ACC_NUM);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void validateAccountTest() throws BillingAccountClientServiceException {

		billingAccountService.validateAccount(ACC_NUM, "1234");
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void requestPaymentArrangement() throws BillingAccountClientServiceException {

		billingAccountService.requestPaymentArrangement(ACC_NUM, false, 0d, 0, 0d);
	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void submitEnergyAssistancePromiseTest() throws BillingAccountClientServiceException {

		billingAccountService.submitEnergyAssistancePromise(ACC_NUM, "1234", 0d);

	}

	@Test(expected = BillingAccountClientServiceException.class)
	public void cancelServiceOrderTest() throws BillingAccountClientServiceException {
		
		billingAccountService.cancelServiceOrder(ACC_NUM, "1234", "", "");
		
	}
	
	public IBillingAccountService getBillingAccountService() {
		return billingAccountService;
	}

	public void setBillingAccountService(IBillingAccountService billingAccountService) {
		this.billingAccountService = billingAccountService;
	}

}
