/*
 * ONEGASCommonServiceTest.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */
package com.avaya.ept.onegas.bl.service;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.avaya.ept.onegas.bl.model.AnnounceValueSSMode;
import com.avaya.ept.onegas.bl.model.AnnounceValueTTSMode;

public class AnnounceBuilderTest {

	@Test
	public void buildAnnouncementTest() {

		String announcement = "onlyAnnounce.wav*announce1.wav*SS:value1:time*onlyAnnounce2.wav*announce3.wav*SS:value2:currency*announce4.wav*TTS:value3:address";
		String announcement1 = "value1*value2*value3";
		String announcement2 = "SS:value1:time*SS:value2:currency*TTS:value3:address";
		String announcement3 = "SS:value1:time*SS:20150808:date*value2*SS:20150808:date*TTS:value3:address";

		AnnounceBuilder announceBuilder = new AnnounceBuilder();
		announceBuilder.add("onlyAnnounce.wav");
		announceBuilder.add("announce1.wav", "value1", AnnounceValueSSMode.TIME);
		announceBuilder.add("onlyAnnounce2.wav");
		announceBuilder.add("announce3.wav", "value2", AnnounceValueSSMode.CURRENCY);
		announceBuilder.add("announce4.wav", "value3", AnnounceValueTTSMode.ADDRESS);

		AnnounceBuilder announceBuilder1 = new AnnounceBuilder();
		announceBuilder1.add("value1");
		announceBuilder1.add("value2");
		announceBuilder1.add("value3");

		AnnounceBuilder announceBuilder2 = new AnnounceBuilder();
		announceBuilder2.addValue("value1", AnnounceValueSSMode.TIME);
		announceBuilder2.addValue("value2", AnnounceValueSSMode.CURRENCY);
		announceBuilder2.addValue("value3", AnnounceValueTTSMode.ADDRESS);

		AnnounceBuilder announceBuilder3 = new AnnounceBuilder();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date date = sdf.parse("20150808");
			announceBuilder3.addValue("value1", AnnounceValueSSMode.TIME);
			announceBuilder3.addValue(date, AnnounceValueSSMode.DATE);
			announceBuilder3.add("value2", date, AnnounceValueSSMode.DATE);
			announceBuilder3.addValue("value3", AnnounceValueTTSMode.ADDRESS);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		assertEquals(announcement, announceBuilder.getAnnouncement());
		assertEquals(announcement1, announceBuilder1.getAnnouncement());
		assertEquals(announcement2, announceBuilder2.getAnnouncement());
		assertEquals(announcement3, announceBuilder3.getAnnouncement());
	}
}