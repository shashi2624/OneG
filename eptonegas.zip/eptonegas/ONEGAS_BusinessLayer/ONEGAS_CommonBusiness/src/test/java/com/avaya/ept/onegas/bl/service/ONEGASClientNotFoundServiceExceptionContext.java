
/*
* ONEGASContext.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/
package com.avaya.ept.onegas.bl.service;



import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.avaya.ept.onegas.bl.context.Holder;
import com.avaya.ept.onegas.bl.service.IONEGASCommonService;


/**
 * @author schmidt0
 *	This class is a singleton class to provide an stand-alone access to
 *	Spring ApplicationContainer in a hidden way.
 */
public final class ONEGASClientNotFoundServiceExceptionContext {

	  /** ContextBase's Logger */
    private static Logger log = Logger.getLogger(ONEGASClientNotFoundServiceExceptionContext.class);

    /** Spring ContextBase Configuration File */
    private static final String CONTEXTCONFIG = "classpath:onegasCommonBusinessClientNotFoundExceptionContext.xml";
    /** Singleton instance field */
    private static ONEGASClientNotFoundServiceExceptionContext instance = new ONEGASClientNotFoundServiceExceptionContext();
    /** holder of the business layer beans that we let access to */
    private Holder holder;
    /** Spring Application ctx */
    private ApplicationContext ctx;
    
    /**
	 * 
	 */
    private ONEGASClientNotFoundServiceExceptionContext() {
		log.info("Initializing Spring ContextBase");
		log.info(System.getProperty("java.class.path"));
		this.ctx = new ClassPathXmlApplicationContext(CONTEXTCONFIG);
		log.info("Spring context initializing ok");
		this.holder = (Holder) this.ctx.getBean("onegasCommonHolder");
    }


    /**
     * @param holder
     *            the holder to set
     */
    public void setHolder(Holder holder) {
    	this.holder = holder;
    }

    /**
     * @return the holder
     */
    public Holder getHolder() {
    	return holder;
    }

    /**
     * @param ctx
     *            the ctx to set
     */
    public void setCtx(ApplicationContext ctx) {
    	this.ctx = ctx;
    }

    /**
     * @return the ctx
     */
    public ApplicationContext getCtx() {
    	return ctx;
    }

    public static IONEGASCommonService getONEGASCommonService() {
    	return instance.getHolder().getONEGASCommonService();
    }
    
}
