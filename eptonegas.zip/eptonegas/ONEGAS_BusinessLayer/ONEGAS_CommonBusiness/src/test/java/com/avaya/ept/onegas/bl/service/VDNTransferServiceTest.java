/*
  ONEGASCommonServiceTest.java
 
  Avaya Inc. - Proprietary (Restricted) Solely for authorized persons having a
  need to know pursuant to Company instructions.
 
  Copyright © 2008-2016 Avaya Inc. All rights reserved.
 
  THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc. The copyright
  notice above does not evidence any actual or intended publication of such
  source code.
  */
 package com.avaya.ept.onegas.bl.service;
  
  import junit.framework.Assert;

import java.io.IOException;

import org.junit.BeforeClass; import org.junit.Test;
  
  import com.avaya.ept.onegas.bl.context.ONEGASContext; import
  com.avaya.ept.onegas.bl.model.VDNValue;
  
  public class VDNTransferServiceTest {
  
  
  private static VDNTransferService service;
  
  @BeforeClass 
  public static void onlyOnce() {
  setService(ONEGASContext.getVDNTransferService()); }
  
  @Test 
  public void transferVDNTest() throws IOException{
  VDNValue vdn = service.getVDN("TX", "ES", "LETTER");
  Assert.assertEquals("9151011142", vdn.getVdn());
  
  }
  
  public VDNTransferService getService() { return service; }
  
  public static void setService(VDNTransferService vdnService) { service =
  vdnService; }
  
  }
 