/*
 * ONEGASCommonServiceTest.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 
package com.avaya.ept.onegas.bl.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.junit.BeforeClass;
import org.junit.Test;

import com.avaya.ept.onegas.bl.context.ONEGASContext;
import com.avaya.ept.onegas.bl.model.BillingAccount;
import com.avaya.ept.onegas.bl.model.CAV;
import com.avaya.ept.onegas.bl.model.CallData;
import com.avaya.ept.onegas.bl.model.Constants;
import com.avaya.ept.onegas.bl.model.Field;
import com.avaya.ept.onegas.bl.model.InvalidDayException;
import com.avaya.ept.onegas.bl.model.InvalidMonthException;
import com.avaya.ept.onegas.bl.model.InvalidYearException;
import com.avaya.ept.onegas.bl.model.LanguageEnum;
import com.avaya.ept.onegas.bl.model.ServiceException;
import com.avaya.ept.onegas.bl.model.VDNTransferType;
import com.avaya.ept.onegas.ws.billing.model.AccountLookupResult;
import com.avaya.ept.onegas.ws.billing.model.BankAccountType;
import com.avaya.ept.onegas.ws.billing.model.ObjectFactory;
import com.avaya.ept.onegas.ws.billing.model.OpenServiceOrderDetail;
import com.avaya.ept.onegas.ws.location.model.LocationInfo;

public class ONEGASCommonServiceTest {

	private static final String YYYY_M_MDD_HH_MM = "yyyyMMdd HH:mm";
	private static IONEGASCommonService onegasCommonService;

	@BeforeClass
	public static void onlyOnce() {
		setOnegasCommonService(ONEGASContext.getONEGASCommonService());
	}

	@Test
	public void isOfficeOpenTest() throws Exception{

		SimpleDateFormat sdf = new SimpleDateFormat(YYYY_M_MDD_HH_MM);
		CallData callData = new CallData();
		callData.setCAV(CAV.location, Constants.OK);
		callData.setCAV(CAV.monfriStartHoursOK, "0900");
		callData.setCAV(CAV.monfriStopHoursOK, "1800");
		callData.setCAV(CAV.satStartHoursOK, "0900");
		callData.setCAV(CAV.satStopHoursOK, "1300");
		callData.setCAV(CAV.holiday, "20150328,20150329,20150330,20160331");

		String weekDay = "20160128 09:30";
		String weekEndDay = "20160130 09:30";
		String afterWeekDay = "20160128 18:30";
		String afterWeekEndDay = "20160130 13:30";
		String holidayDay = "20150328 13:30";
		String sunday = "20160501 13:30";

		boolean officeOpen;

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekEndDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(afterWeekDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(afterWeekEndDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(holidayDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(sunday));
		assertFalse(officeOpen);

		callData.setCAV(CAV.location, Constants.TX);
		callData.setCAV(CAV.monfriStartHoursTX, "0900");
		callData.setCAV(CAV.monfriStopHoursTX, "1800");
		callData.setCAV(CAV.satStartHoursTX, "0900");
		callData.setCAV(CAV.satStopHoursTX, "1300");
		callData.setCAV(CAV.holiday, "20150328,20150329,20150330,20160331");

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekEndDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(afterWeekDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(afterWeekEndDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(holidayDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(sunday));
		assertFalse(officeOpen);

		callData.setCAV(CAV.location, Constants.KS);
		callData.setCAV(CAV.monfriStartHoursKS, "0900");
		callData.setCAV(CAV.monfriStopHoursKS, "1800");
		callData.setCAV(CAV.satStartHoursKS, "0900");
		callData.setCAV(CAV.satStopHoursKS, "1300");
		callData.setCAV(CAV.holiday, "20150328,20150329,20150330,20160331");

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekEndDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(afterWeekDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(afterWeekEndDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(holidayDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(sunday));
		assertFalse(officeOpen);


		callData.setCAV(CAV.location, "wwww");

		try {
			officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekDay));
		} catch (Exception e) {
			assertTrue(true);
		}

		callData.setCAV(CAV.location, Constants.KS);
		callData.setCAV(CAV.monfriStartHoursKS, "0900");
		callData.setCAV(CAV.monfriStopHoursKS, "1800");
		callData.setCAV(CAV.satStartHoursKS, "");
		callData.setCAV(CAV.satStopHoursKS, "");

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekEndDay));
		assertTrue(officeOpen);


		callData.setCAV(CAV.location, Constants.KS);
		callData.setCAV(CAV.monfriStartHoursKS, "");
		callData.setCAV(CAV.monfriStopHoursKS, "");
		callData.setCAV(CAV.satStartHoursKS, "0900");
		callData.setCAV(CAV.satStopHoursKS, "1800");

		officeOpen = onegasCommonService.isOfficeOpen(callData, sdf.parse(weekDay));
		assertTrue(officeOpen);
	}

	@Test
	public void isAWeekendDayTest() throws Exception{

		SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);
		CallData callData = new CallData();

		String weekDay = "20160128";
		String weekEndDay = "20160130";

		boolean isWeekend;

		isWeekend = onegasCommonService.isAWeekendDay(callData, sdf.parse(weekDay));
		assertFalse(isWeekend);

		isWeekend = onegasCommonService.isAWeekendDay(callData, sdf.parse(weekEndDay));
		assertTrue(isWeekend);
	}

	@Test
	public void isHolidayTest() throws Exception{

		SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);

		CallData callData = new CallData();
		callData.setCAV(CAV.holiday, "20150128,20150129,20150130,20160131");

		String day = "20160128";
		String day2 = "20160129";
		String day3 = "20160130";
		String holiday = "20160131";

		boolean isHoliday;

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(day));
		assertFalse(isHoliday);

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(day2));
		assertFalse(isHoliday);

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(day3));
		assertFalse(isHoliday);

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(holiday));
		assertTrue(isHoliday);

		callData.setCAV(CAV.holiday, "");

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(day));
		assertFalse(isHoliday);

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(day2));
		assertFalse(isHoliday);

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(day3));
		assertFalse(isHoliday);

		isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(holiday));
		assertFalse(isHoliday);

		callData.setCAV(CAV.holiday, "23456787");

		try {
			isHoliday = onegasCommonService.isAHolidayDate(callData, sdf.parse(day));

		} catch (Exception e) {
			assertTrue(true);
		}
	}

	@Test
	public void testGetSeason() {

		CallData callData = new CallData();

		String season = "";
		String day = "0401";
		String day1 = "1002";
		String day2 = "0910";
		String day3 = "0202";

		season = onegasCommonService.getSeason(callData, day);
		assertEquals("Spring", season);
		season = onegasCommonService.getSeason(callData, day1);
		assertEquals("Fall", season);
		season = onegasCommonService.getSeason(callData, day2);
		assertEquals("Summer", season);
		season = onegasCommonService.getSeason(callData, day3);
		assertEquals("Winter", season);
	}

	@Test(expected = InvalidYearException.class)
	public void testDateIsNull() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
		onegasCommonService.isThisDateValid(null, "MMddyyyy", callData);
	}

	@Test(expected = InvalidYearException.class)
	public void testDateIsEmpty() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
		onegasCommonService.isThisDateValid("", "MMddyyyy", callData);
	}

	@Test(expected = InvalidYearException.class)
	public void testDateHasInvalidLength() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
		onegasCommonService.isThisDateValid("0103", "MMddyyyy", callData);
	}

	@Test(expected = InvalidYearException.class)
	public void testInvalidYear() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
		onegasCommonService.isThisDateValid("01032015", "MMddyyyy", callData);
	}

	@Test(expected = InvalidMonthException.class)
	public void testInvalidMonth() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
			onegasCommonService.isThisDateValid("1303" + Calendar.getInstance().get(Calendar.YEAR), "MMddyyyy", callData);
	}

	@Test(expected = InvalidDayException.class)
	public void testInvalidDay() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
			onegasCommonService.isThisDateValid("0230" + Calendar.getInstance().get(Calendar.YEAR), "MMddyyyy", callData);
	}

	@Test(expected = InvalidDayException.class)
	public void testInvalidDay2() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
			onegasCommonService.isThisDateValid("0232" + Calendar.getInstance().get(Calendar.YEAR), "MMddyyyy", callData);
	}

	@Test
	public void testIsThisDateValid() throws InvalidYearException, InvalidMonthException, InvalidDayException {
		CallData callData = new CallData();
		String thisDateValid = onegasCommonService.isThisDateValid("0224" + Calendar.getInstance().get(Calendar.YEAR), "MMddyyyy", callData);
		assertEquals("ok", thisDateValid);
	}

	@Test(expected = ServiceException.class)
	public void tesNoAccount() throws ServiceException {
		CallData callData = new CallData();
		List<AccountLookupResult> accountLookupList = new ArrayList<AccountLookupResult>();
		callData.setAccountLookupList(accountLookupList);
		onegasCommonService.isMultiAccounts(callData);
	}

	@Test(expected = ServiceException.class)
	public void tesNullAccount() throws ServiceException {
		CallData callData = new CallData();
		callData.setAccountLookupList(null);
		onegasCommonService.isMultiAccounts(callData);
	}

	@Test
	public void testOnlyOneAccount() throws ServiceException {
		CallData callData = new CallData();
		ObjectFactory of = new ObjectFactory();
		List<AccountLookupResult> accountLookupList = new ArrayList<AccountLookupResult>();
		AccountLookupResult oneElement = new AccountLookupResult();

		oneElement.setAccountNumber(of.createAccountLookupResultAccountNumber("123"));
		oneElement.setAccountStatus(of.createAccountLookupResultAccountStatus("ok"));
		oneElement.setFirstName(of.createAccountLookupResultFirstName("john"));
		oneElement.setLastName(of.createAccountLookupResultLastName("layer"));
		oneElement.setServiceAddress(of.createAccountLookupResultServiceAddress("1234 Jacksonville"));

		accountLookupList.add(oneElement);
		callData.setAccountLookupList(accountLookupList);

		assertFalse(onegasCommonService.isMultiAccounts(callData));
	}

	@Test
	public void testMultiAccounts() throws ServiceException {
		CallData callData = new CallData();
		List<AccountLookupResult> accountLookupList = new ArrayList<AccountLookupResult>();
		AccountLookupResult oneElement = new AccountLookupResult();

		accountLookupList.add(oneElement);
		accountLookupList.add(oneElement);

		callData.setAccountLookupList(accountLookupList);
		assertTrue(onegasCommonService.isMultiAccounts(callData));
	}

	@Test
	public void lookupBillingAccountAniTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ANI, "9181239876");
		callData.setField(Field.LDCPROVIDER, "ONG");
		boolean lookupBillingAccountAni = onegasCommonService.lookupBillingAccountAni(callData);
		Assert.assertTrue(lookupBillingAccountAni);
		Assert.assertNotNull(callData.getAccountLookupList());
		Assert.assertEquals("JORGE", callData.getAccountLookupList().get(0).getFirstName().getValue());
	}

	@Test
	public void lookupBillingAccountPhoneTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.PHONE_NUMBER, "9181239876");
		callData.setField(Field.LDCPROVIDER, "ONG");
		boolean lookupBillingAccountAni = onegasCommonService.lookupBillingAccountPhoneNumber(callData);
		Assert.assertTrue(lookupBillingAccountAni);
		Assert.assertNotNull(callData.getAccountLookupList());
	}

	@Test
	public void getAccountSummaryTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		boolean payload = onegasCommonService.getAccountSummary(callData);
		Assert.assertTrue(payload);
		Assert.assertEquals("corey.elias@onegas.com", callData.getBillingAccount().getEmailAddress());
	}

	@Test
	public void getAccountSummaryCallerInputTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ACCT_NUMBER, "1111111111111111");
		boolean payload = onegasCommonService.getAccountSummaryCallerInput(callData);
		Assert.assertTrue(payload);
		Assert.assertEquals("corey.elias@onegas.com", callData.getBillingAccount().getEmailAddress());
	}

	@Test
	public void getOpenServiceOrdersTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ACCT_NUMBER, "1111111111111111");
		boolean payload = onegasCommonService.getOpenServiceOrders(callData);
		Assert.assertTrue(payload);
		OpenServiceOrderDetail openServiceOrder = callData.getOpenServiceOrder();
		Assert.assertNotNull(openServiceOrder);
	}

	@Test
	public void removeBankAccountInformationTest() throws Exception{

		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		boolean removedBankAccountInformation = onegasCommonService.removeBankAccountInformation(callData);
		Assert.assertTrue(removedBankAccountInformation);
	}

	@Test
	public void existingTimePaymentTest() throws Exception{

		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Checking");
		callData.getBillingAccount().setBankRoutingNumber("301179892");
		callData.getBillingAccount().setBankAccountNumber("12345678");
		callData.setField(Field.PAYMENT_AMOUNT, "123.4");
		callData.setField(Field.PAYMENT_DATE, "20101125");
		
		boolean existingTimePayment = onegasCommonService.existingTimePayment(callData);
		Assert.assertTrue(existingTimePayment);
		String confirmNum = callData.getBillingAccount().getConfirmationNumber();
		Assert.assertNotNull(confirmNum);

		callData.getBillingAccount().setBankAccountType("Savings");

		boolean existingTimePayment1 = onegasCommonService.existingTimePayment(callData);
		Assert.assertTrue(existingTimePayment1);
		String confirmNum1 = callData.getBillingAccount().getConfirmationNumber();
		Assert.assertNotNull(confirmNum1);
	}
	
	@Test(expected=ServiceException.class)
	public void existingTimePaymentParseExceptionTest() throws ServiceException{
		
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Checking");
		callData.getBillingAccount().setBankRoutingNumber("301179892");
		callData.getBillingAccount().setBankAccountNumber("12345678");
		callData.setField(Field.PAYMENT_AMOUNT, "123.4");
		callData.setField(Field.PAYMENT_DATE, "0");
		
		onegasCommonService.existingTimePayment(callData);

	}

	@Test
	public void newTimePaymentTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType(BankAccountType.CHECKING.value());
		callData.getBillingAccount().setBillingAccountNumber("301179892");
		callData.setField(Field.ROUTING_NUMBER_CALLER_INPUT, "301179892");
		callData.setField(Field.CHECKING_NUMBER_CALLER_INPUT, "12345678");
		callData.setField(Field.PAYMENT_AMOUNT, "5.01");
		callData.setField(Field.PAYMENT_DATE, "20101125");

			boolean newTimePayment = onegasCommonService.newTimePayment(callData);
			Assert.assertTrue(newTimePayment);
			String confirmNum = callData.getBillingAccount().getConfirmationNumber();
			Assert.assertNotNull(confirmNum);

			callData.setField(Field.ACCOUNT_TYPE, "Savings");
			boolean newTimePayment1 = onegasCommonService.newTimePayment(callData);
			Assert.assertTrue(newTimePayment1);
			String confirmNum1 = callData.getBillingAccount().getConfirmationNumber();
			Assert.assertNotNull(confirmNum1);
	}
	
	@Test(expected=ServiceException.class)
	public void newTimePaymentDateParseExceptionTest() throws ServiceException{
		
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType(BankAccountType.CHECKING.value());
		callData.getBillingAccount().setBillingAccountNumber("301179892");
		callData.setField(Field.ROUTING_NUMBER_CALLER_INPUT, "301179892");
		callData.setField(Field.CHECKING_NUMBER_CALLER_INPUT, "12345678");
		callData.setField(Field.PAYMENT_AMOUNT, "5.01");
		callData.setField(Field.PAYMENT_DATE, "0");
		
		onegasCommonService.newTimePayment(callData);

	}

	@Test
	public void registerBankAccountInformationTest() throws Exception{
		CallData callData = new CallData();

		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Savings");
		callData.setField(Field.ROUTING_NUMBER_CALLER_INPUT, "301179892");
		callData.setField(Field.CHECKING_NUMBER_CALLER_INPUT, "12345678");
			boolean registeredAct = onegasCommonService.registerBankAccountInformation(callData);
			Assert.assertTrue(registeredAct);
			callData.getBillingAccount().setBankAccountType("Checking");

			boolean registeredAct1 = onegasCommonService.registerBankAccountInformation(callData);
			Assert.assertTrue(registeredAct1);
	}

	@Test
	public void submitMemoPaymentTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.PAYMENT_AMOUNT, "2.05");
		callData.setField(Field.RECEIPT_NUM, "546585");
		callData.setField(Field.PAYMENT_DATE, "07012016");

			onegasCommonService.submitMemoPayment(callData);
	}

	@Test(expected = ServiceException.class)
	public void submitMemoPaymentExceptionTest() throws ServiceException {
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.PAYMENT_AMOUNT, "2.05");
		callData.setField(Field.RECEIPT_NUM, "546585");
		callData.setField(Field.PAYMENT_DATE, "07012016");

		callData.setField(Field.PAYMENT_DATE, "asdfasdf");
		onegasCommonService.submitMemoPayment(callData);
	}

	@Test
	public void enrollInBankDraftTest() throws Exception{

		CallData callData = new CallData();

		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Checking");
		callData.setField(Field.ROUTING_NUMBER_CALLER_INPUT,"301179892" );
		callData.setField(Field.CHECKING_NUMBER_CALLER_INPUT, "12345678");
			boolean enrollBankDraft = onegasCommonService.enrollInBankDraft(callData);
			Assert.assertFalse(enrollBankDraft);

			callData.getBillingAccount().setBankAccountType("Savings");

			boolean enrollBankDraft1 = onegasCommonService.registerBankAccountInformation(callData);
			Assert.assertTrue(enrollBankDraft1);
	}

	@Test
	public void cancelServiceOrderTest() throws Exception{

		CallData callData = new CallData();

		callData.getBillingAccount().setAccountNumber("2100035471012250");
		callData.getBillingAccount().setServiceOrderNumber("5580420");

			boolean cancelServiceOrder = onegasCommonService.cancelServiceOrder(callData);
			Assert.assertTrue(cancelServiceOrder);
	}

	@Test
	public void cancelBankDraftTest() throws Exception{

		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("2111516401834343");

			boolean cancelBankDraft = onegasCommonService.cancelBankDraft(callData);
			Assert.assertTrue(cancelBankDraft);
	}

	@Test
	public void updateBankDraftInfoTest() throws Exception{

		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Checking");
		callData.setField(Field.ROUTING_NUMBER_CALLER_INPUT, "301179892");
		callData.setField(Field.CHECKING_NUMBER_CALLER_INPUT, "301179892");

			boolean updateBankDraft = onegasCommonService.updateBankDraftInfo(callData);
			Assert.assertTrue(updateBankDraft);

	}

	@Test
	public void requestDupilcateBillTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");

			boolean duplicateBill = onegasCommonService.requestDupilcateBill(callData);
			Assert.assertTrue(duplicateBill);
	}

	@Test
	public void requestLetterOfCreditTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");

			boolean requestLetters = onegasCommonService.requestLetterOfCredit(callData);
			Assert.assertTrue(requestLetters);
	}

	@Test
	public void setShareTheWarmthStatusEnrollTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.PAYMENT_AMOUNT, "0.0");
			boolean requestLetters = onegasCommonService.setShareTheWarmthStatusEnroll(callData);
			Assert.assertTrue(requestLetters);
	}

	@Test
	public void setShareTheWarmthStatusUpdateTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.PAYMENT_AMOUNT, "0.0");
			boolean requestLetters = onegasCommonService.setShareTheWarmthStatusUpdate(callData);
			Assert.assertTrue(requestLetters);
	}

	@Test
	public void setShareTheWarmthStatusCancelTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
			boolean requestLetters = onegasCommonService.setShareTheWarmthStatusCancel(callData);
			Assert.assertTrue(requestLetters);
	}

	@Test
	public void setElectronicBillingStatusTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setEmailAddress("corey.elias@onegas.com");
		callData.setField(Field.ACTION, "Enroll");

			boolean electronicBill = onegasCommonService.setElectronicBillingStatus(callData);
			Assert.assertTrue(electronicBill);

			callData.setField(Field.ACTION, "UnEnroll");
			boolean electronicBill1 = onegasCommonService.setElectronicBillingStatus(callData);
			Assert.assertTrue(electronicBill1);
	}
	
	@Test
	public void getAppointmentAvailabilityTest() throws Exception{

		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.APP_DATE, "09012016");

			boolean isAppointmentAvailable = onegasCommonService.getAppointmentAvailability(callData);
			Assert.assertTrue(isAppointmentAvailable);
			Assert.assertNotNull(callData.getAppointmentAvailabilityList());
	}

	@Test
	public void requestServiceOrderChangeTest() throws Exception{

		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setAppointmentConfirmationNumber("AVAIL-0005539869");
		callData.getBillingAccount().setServiceOrderNumber("7102620");

			boolean isServiceOrderCancel = onegasCommonService.requestServiceOrderChange(callData);
			Assert.assertTrue(isServiceOrderCancel);
			Assert.assertEquals("1111111111111111", callData.getBillingAccount().getAccountNumber());
			Assert.assertEquals("AVAIL-0005539869", callData.getBillingAccount().getAppointmentConfirmationNumber());
			Assert.assertEquals("7102621", callData.getBillingAccount().getServiceOrderNumber());
	}

	@Test
	public void enrollForVoluntaryFixedPriceTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");

			boolean isEnrolledForVoluntaryFixedPrice = onegasCommonService.enrollForVoluntaryFixedPrice(callData);
			Assert.assertFalse(isEnrolledForVoluntaryFixedPrice);
	}

	@Test
	public void enrollForAveragePaymentPlanNotEnrolledTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setServiceID(1);

			boolean isEnrolledForAveragePaymentPlan = onegasCommonService.enrollForAveragePaymentPlan(callData);
			Assert.assertFalse(isEnrolledForAveragePaymentPlan);
	}

	@Test
	public void getPaymentHistoryTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");

			boolean paymentHistory = onegasCommonService.getPaymentHistory(callData);
			Assert.assertTrue(paymentHistory);
			Assert.assertNotNull(callData.getPaymentInfoList());
	}

	@Test
	public void submitEAPTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.AGENCY_CODE, "1234");
		callData.setField(Field.PAYMENT_AMOUNT, "0.0");
			boolean eapSubmitted = onegasCommonService.submitEAP(callData);
			Assert.assertFalse(eapSubmitted);
	}

	@Test
	public void validateAccountTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.LAST4SSN, "1234");
			boolean accountValidated = onegasCommonService.validateAccount(callData);
			Assert.assertTrue(accountValidated);
	}

	@Test
	public void requestPaymentArrangementFalseTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
			onegasCommonService.requestPaymentArrangementFalse(callData);
			Assert.assertEquals(19.83d, callData.getBillingAccount().getInstallmentAmount());
			Assert.assertEquals(Integer.valueOf(11), callData.getBillingAccount().getInstallCount());
			Assert.assertEquals(218.16d, callData.getBillingAccount().getTotalAmountDue());
			Assert.assertEquals("2016-02-21T00:00:00", callData.getBillingAccount().getDueDate());
	}

	@Test
	public void requestPaymentArrangementTrueTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setAmountDue(0.0);
		callData.setField(Field.DOWN_PAYMENT, "0.0");
		callData.setField(Field.INSTALLMENTS, "0.0");

			onegasCommonService.requestPaymentArrangementTrue(callData);
			Assert.assertEquals(19.83d, callData.getBillingAccount().getInstallmentAmount());
			Assert.assertEquals(Integer.valueOf(11), callData.getBillingAccount().getInstallCount());
			Assert.assertEquals(218.16d, callData.getBillingAccount().getTotalAmountDue());
			Assert.assertEquals("2016-02-21T00:00:00", callData.getBillingAccount().getDueDate());
	}

	@Test
	public void enrollForAveragePaymentPlanTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setServiceID(1);

			boolean isEnrolledForAveragePaymentPlan = onegasCommonService.enrollForAveragePaymentPlan(callData);
			Assert.assertFalse(isEnrolledForAveragePaymentPlan);
	}

	@Test
	public void agencyLookupTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.AGENCY_CODE, "1234");
			String eaCode = onegasCommonService.agencyLookup(callData);
			Assert.assertEquals("TRM", eaCode);
	}

	@Test
	public void enterMeterReadTest() throws Exception{

		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setServiceID(1);
		callData.setField(Field.METER_READING, "1234");

			boolean meterEntryResponse = onegasCommonService.enterMeterRead(callData);
			Assert.assertTrue(meterEntryResponse);
	}

	@Test
	public void isAccountStatusOKAfterGasApplianceTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountStatus(Constants.ACTIVE);
		callData.getBillingAccount().setMeterInside(false);
			Assert.assertTrue(onegasCommonService.isAccountStatusOKAfterGasAppliance(callData));
	}

	@Test
	public void isAccountStatusNotOKAfterGasApplianceTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountStatus("UnActive");
		callData.getBillingAccount().setMeterInside(true);
			Assert.assertFalse(onegasCommonService.isAccountStatusOKAfterGasAppliance(callData));
	}

	@Test
	public void isAccountStatusOkTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountStatus("Active");
		callData.getBillingAccount().setHasBadDebt(false);
		callData.getBillingAccount().setMasterBill(false);
		callData.getBillingAccount().setCanUseWebAccess(true);

			Assert.assertTrue(onegasCommonService.isAccountStatusOk(callData));
	}

	@Test
	public void isAHolidayDateTest() throws Exception{
		CallData callData = new CallData();
		callData.setCAV(CAV.holiday, "20140412,20151212");

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		sdf.setLenient(false);
		Date appDate;
			appDate = sdf.parse("20140412");
			Assert.assertTrue(onegasCommonService.isAHolidayDate(callData, appDate));
	}

	@Test
	public void isNotAHolidayDateTest() throws Exception{
		CallData callData = new CallData();
		callData.setCAV(CAV.holiday, "04122014;12252015");

		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		sdf.setLenient(false);
		Date appDate;
			appDate = sdf.parse("03292014");
			Assert.assertFalse(onegasCommonService.isAHolidayDate(callData, appDate));
	}

	@Test
	public void isFieldNullOrEmptyTest() {
		String field = "";
		Assert.assertFalse(onegasCommonService.isFieldNotNullOrEmpty(field));
	}

	@Test
	public void isANINullTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ANI, "");
			Assert.assertTrue(onegasCommonService.isANINull(callData));
	}

	@Test
	public void isANINullUnknownTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ANI, "anonymous");
			Assert.assertTrue(onegasCommonService.isANINull(callData));
	}

	@Test
	public void isANINotNullTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ANI, "124324");
			Assert.assertFalse(onegasCommonService.isANINull(callData));
	}

	@Test
	public void getGrammarFolderTest() {
		CallData callData = new CallData();
		String grammarURL = onegasCommonService.getGrammarURL(callData);
		Assert.assertEquals("http://localhost:8080/ONEGAS_Data/Grammars/", grammarURL);

	}

	@Test
	public void getConfigTest() {
		CallData callData = new CallData();
		String config = onegasCommonService.getPropertiesFilesPath(callData);
		Assert.assertEquals("/usr/local/tomcat/", config);

	}
	@Test
	public void voiceRecordingPathTest() {
		CallData callData = new CallData();
		callData.setField(Field.LANGUAGE, Constants.LANGUAGE_ENGLISH);
		String config = onegasCommonService.getVoiceRecordedFilesCompletePath(callData);
		Assert.assertEquals("/usr/local/tomcat//English/Custom", config);
	}

	@Test
	public void getAudioFolderTest() {
		CallData callData = new CallData();
		String audioURL = onegasCommonService.getCustomAudioURL(callData);
		Assert.assertEquals("http://localhost:8080/ONEGAS_Data/Audios/English/Custom/", audioURL);
		audioURL = onegasCommonService.getStandardSpeechAudioURL(callData);
		Assert.assertEquals("http://localhost:8080/ONEGAS_Data/Audios/English/Standard/", audioURL);

		callData.setField(Field.LANGUAGE, LanguageEnum.SPANISH.name());
		audioURL = onegasCommonService.getCustomAudioURL(callData);
		Assert.assertEquals("http://localhost:8080/ONEGAS_Data/Audios/Spanish/Custom/", audioURL);
		audioURL = onegasCommonService.getStandardSpeechAudioURL(callData);
		Assert.assertEquals("http://localhost:8080/ONEGAS_Data/Audios/Spanish/Standard/", audioURL);

		callData.setField(Field.LANGUAGE, null);
		audioURL = onegasCommonService.getCustomAudioURL(callData);
		Assert.assertEquals("http://localhost:8080/ONEGAS_Data/Audios/English/Custom/", audioURL);
		audioURL = onegasCommonService.getStandardSpeechAudioURL(callData);
		Assert.assertEquals("http://localhost:8080/ONEGAS_Data/Audios/English/Standard/", audioURL);
	}

	@Test
	public void getVoiceRecorderPathTest() {
		CallData callData = new CallData();
		String voiceRecordedFilesPath = onegasCommonService.getVoiceRecordedFilesPath(callData);
		Assert.assertEquals("/usr/local/tomcat/", voiceRecordedFilesPath);
	}

	@Test
	public void isFirtDateGreaterThan60DaysThanTheSecondDateTest() {
		IONEGASCommonService service = ONEGASContext.getONEGASCommonService();
		Date firstDate = Calendar.getInstance().getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		sdf.format(firstDate);

		Date secondDate = Calendar.getInstance().getTime();
		secondDate.setTime(secondDate.getTime() + (61 * 1000 * 60 * 60 * 24));
		sdf.format(secondDate);

		Assert.assertTrue(service.isFirtDate60DaysGreaterThanSecondDate(secondDate, firstDate));
	}

	@Test
	public void firtDateIsNotGreaterThan60DaysThanTheSecondDateTest() {
		IONEGASCommonService service = ONEGASContext.getONEGASCommonService();
		Date firstDate = Calendar.getInstance().getTime();
		SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy");
		sdf.format(firstDate);

		Date secondDate = Calendar.getInstance().getTime();
		secondDate.setTime(secondDate.getTime() + (50 * 1000 * 60 * 60 * 24));
		sdf.format(secondDate);

		Assert.assertFalse(service.isFirtDate60DaysGreaterThanSecondDate(secondDate, firstDate));
	}

	@Test
	public void checkHouseNumbAmountTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ANI, "9181239876");
		callData.setField(Field.LDCPROVIDER, "ONG");
		callData.setField(Field.HOUSE_NUM, "123");
			onegasCommonService.lookupBillingAccountAni(callData);
			Assert.assertEquals(1, onegasCommonService.checkHouseNumbAmount(callData));
	}

	@Test
	public void getLocationsByZipCodeTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.ZIP_CODE, "74136");
			boolean payload = onegasCommonService.getLocationsByZipCode(callData);
			Assert.assertTrue(payload);
			List<LocationInfo> locationsByZipCodeList = callData.getLocationsByZipCodeList();
			Assert.assertNotNull(locationsByZipCodeList);
	}

	@Test
	public void accountsDisambiguationTest() throws Exception{
		CallData callData = new CallData();
		ObjectFactory of = new ObjectFactory();
		List<AccountLookupResult> accountLookupList = new ArrayList<AccountLookupResult>();
		AccountLookupResult firstElement = new AccountLookupResult();
		AccountLookupResult secondElement = new AccountLookupResult();

		callData.setField(Field.HOUSE_NUM, "12345");

		firstElement.setAccountNumber(of.createAccountLookupResultAccountNumber("123"));
		firstElement.setAccountStatus(of.createAccountLookupResultAccountStatus("ok"));
		firstElement.setFirstName(of.createAccountLookupResultFirstName("john"));
		firstElement.setLastName(of.createAccountLookupResultLastName("layer"));
		firstElement.setServiceAddress(of.createAccountLookupResultServiceAddress("1234 Jacksonville"));

		secondElement.setAccountNumber(of.createAccountLookupResultAccountNumber("12999"));
		secondElement.setAccountStatus(of.createAccountLookupResultAccountStatus("Active"));
		secondElement.setFirstName(of.createAccountLookupResultFirstName("brian"));
		secondElement.setLastName(of.createAccountLookupResultLastName("rupergrint"));
		secondElement.setServiceAddress(of.createAccountLookupResultServiceAddress("12345 Jacksonville"));

		accountLookupList.add(firstElement);
		accountLookupList.add(secondElement);
		callData.setAccountLookupList(accountLookupList);

			onegasCommonService.accountsDisambiguation(callData);
			Assert.assertEquals("12999", callData.getBillingAccount().getAccountNumber());
			Assert.assertEquals("Active", callData.getBillingAccount().getAccountStatus());
			Assert.assertEquals("brian", callData.getBillingAccount().getFirstName());
			Assert.assertEquals("rupergrint", callData.getBillingAccount().getLastName());
			Assert.assertEquals("12345 Jacksonville", callData.getBillingAccount().getAddress());

	}
	
	@Test(expected = ServiceException.class)
	public void accountsDisambiguationFailsTest() throws ServiceException {
		CallData callData = new CallData();
		ObjectFactory of = new ObjectFactory();
		List<AccountLookupResult> accountLookupList = new ArrayList<AccountLookupResult>();
		AccountLookupResult firstElement = new AccountLookupResult();
		AccountLookupResult secondElement = new AccountLookupResult();

		callData.setField(Field.HOUSE_NUM, "12345");

		firstElement.setAccountNumber(of.createAccountLookupResultAccountNumber("123"));
		firstElement.setAccountStatus(of.createAccountLookupResultAccountStatus("ok"));
		firstElement.setFirstName(of.createAccountLookupResultFirstName("john"));
		firstElement.setLastName(of.createAccountLookupResultLastName("layer"));
		firstElement.setServiceAddress(of.createAccountLookupResultServiceAddress("1234 Jacksonville"));

		secondElement.setAccountNumber(of.createAccountLookupResultAccountNumber("12999"));
		secondElement.setAccountStatus(of.createAccountLookupResultAccountStatus("ok"));
		secondElement.setFirstName(of.createAccountLookupResultFirstName("john"));
		secondElement.setLastName(of.createAccountLookupResultLastName("layer"));
		secondElement.setServiceAddress(of.createAccountLookupResultServiceAddress("12333 Jacksonville"));

		accountLookupList.add(firstElement);
		accountLookupList.add(secondElement);
		callData.setAccountLookupList(accountLookupList);

		onegasCommonService.accountsDisambiguation(callData);
	}

	@Test
	public void isDateValidTest() {
		CallData callData = new CallData();

		boolean dateValid = onegasCommonService.isDateValid("04132016", Constants.DATE_FORMAT, callData);
		assertTrue(dateValid);

		boolean dateNotValid = onegasCommonService.isDateValid("20132016", Constants.DATE_FORMAT, callData);
		assertFalse(dateNotValid);

		dateNotValid = onegasCommonService.isDateValid("", Constants.DATE_FORMAT, callData);
		assertFalse(dateNotValid);

		dateNotValid = onegasCommonService.isDateValid(null, Constants.DATE_FORMAT, callData);
		assertFalse(dateNotValid);
	}

	@Test
	public void getCurrencyStringFromInputTest() {
		CallData callData = new CallData();
		String stringToConvert = "12343";
		Assert.assertEquals("123.43", onegasCommonService.getCurrencyStringFromInput(callData, stringToConvert));
		stringToConvert = "";
		Assert.assertEquals("", onegasCommonService.getCurrencyStringFromInput(callData, stringToConvert));
		stringToConvert = "27";
		Assert.assertEquals("0.27", onegasCommonService.getCurrencyStringFromInput(callData, stringToConvert));
		stringToConvert = "7";
		Assert.assertEquals("0.07", onegasCommonService.getCurrencyStringFromInput(callData, stringToConvert));
	}

	@Test
	public void isOfficeOpenNCO_OK_Test() throws Exception{
		CallData callData = new CallData();
		SimpleDateFormat sdf = new SimpleDateFormat(YYYY_M_MDD_HH_MM);
		callData.setCAV(CAV.location, Constants.OK);
		callData.setCAV(CAV.monfriStartHoursOK, "0900");
		callData.setCAV(CAV.monfriStopHoursOK, "1800");
		callData.setCAV(CAV.satStartHoursOKNCO, "0900");
		callData.setCAV(CAV.satStopHoursOKNCO, "1300");
		callData.setCAV(CAV.holiday, "20150328,20150329,20150330,20160331");

		String holidayDay = "20150328 13:30";
		String weekDay = "20160128 09:30";
		String weekEndDay = "20160130 09:30";
		String afterWeekDay = "20160128 18:30";
		String afterWeekEndDay = "20160130 13:30";

		boolean officeOpen;

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(weekDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(weekEndDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(afterWeekDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(afterWeekEndDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(holidayDay));
		assertFalse(officeOpen);
	}

	@Test
	public void isOfficeOpenNCO_KS_Test() throws Exception{
		CallData callData = new CallData();
		SimpleDateFormat sdf = new SimpleDateFormat(YYYY_M_MDD_HH_MM);
		callData.setCAV(CAV.location, Constants.KS);
		callData.setCAV(CAV.monfriStartHoursKS, "0900");
		callData.setCAV(CAV.monfriStopHoursKS, "1800");
		callData.setCAV(CAV.satStartHoursKSNCO, "0900");
		callData.setCAV(CAV.satStopHoursKSNCO, "1300");
		callData.setCAV(CAV.holiday, "20150328,20150329,20150330,20160331");

		String holidayDay = "20150328 13:30";
		String weekDay = "20160128 09:30";
		String weekEndDay = "20160130 09:30";
		String afterWeekDay = "20160128 18:30";
		String afterWeekEndDay = "20160130 13:30";

		boolean officeOpen;

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(weekDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(weekEndDay));
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(afterWeekDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(afterWeekEndDay));
		assertFalse(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(holidayDay));
		assertFalse(officeOpen);

	}

	@Test
	public void isOfficeOpenNCO_TX_Test() throws Exception{
		CallData callData = new CallData();
		SimpleDateFormat sdf = new SimpleDateFormat(YYYY_M_MDD_HH_MM);
		callData.setCAV(CAV.location, Constants.TX);
		callData.setField(Field.IS_OFFICE_OPEN, Constants.TRUE);
		boolean officeOpen;
		callData.setCAV(CAV.holiday, "20150328,20150329,20150330,20160331");
		String holidayDay = "20150328 13:30";

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, new Date());
		assertTrue(officeOpen);

		officeOpen = onegasCommonService.isOfficeOpenNCO(callData, sdf.parse(holidayDay));
		assertFalse(officeOpen);
	}

	@Test
	public void dateTest() throws Exception{

		Date date = null;
		String yyyyMMdd = "20110809";
		String mmDDyyyy = "08092011";

		SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);
		date = sdf.parse(yyyyMMdd);

		String dateStr = onegasCommonService.getDateAsString(date);
		assertEquals(mmDDyyyy, dateStr);

		dateStr = onegasCommonService.getDateAsStringYYYMMDD(date);
		assertEquals(yyyyMMdd, dateStr);
	}

	@Test
	public void isFieldNotNullOrEmptyTest() {

		boolean fieldNotNullOrEmpty = onegasCommonService.isFieldNotNullOrEmpty(null);
		Assert.assertFalse(fieldNotNullOrEmpty);
		fieldNotNullOrEmpty = onegasCommonService.isFieldNotNullOrEmpty("");
		Assert.assertFalse(fieldNotNullOrEmpty);
		fieldNotNullOrEmpty = onegasCommonService.isFieldNotNullOrEmpty("FIELD");
		Assert.assertTrue(fieldNotNullOrEmpty);

	}

	@Test
	public void getAnnounceFormatTest() {

		String currency = "3.998";
		String digits = "3333";
		String date = "20110901";
		String expectedCurrency = "SS:3.998:currency";
		String expectedDigits = "SS:3333:digits";
		String expectedDate = "SS:20110901:date";

		String currencyFormat = onegasCommonService.getCurrencyFormat(currency);
		assertEquals(expectedCurrency, currencyFormat);
		String digitsFormat = onegasCommonService.getDigitsFormat(digits);
		assertEquals(expectedDigits, digitsFormat);
		String dateFormat = onegasCommonService.getDateFormat(date);
		assertEquals(expectedDate, dateFormat);
	}

	@Test
	public void isCheckArrearsTest() {

		CallData callData = new CallData();
		BillingAccount billingAccount = callData.getBillingAccount();
		billingAccount = callData.getBillingAccount();

		billingAccount.setHasOpenNonPaymentShutOffOrder(true);
		boolean checkArrears = onegasCommonService.isCheckArrears(callData);
		assertTrue(checkArrears);

		callData = new CallData();
		billingAccount = callData.getBillingAccount();
		billingAccount.setHasPendingNonPaymentShutOffOrder(true);
		checkArrears = onegasCommonService.isCheckArrears(callData);
		assertTrue(checkArrears);

		callData = new CallData();
		billingAccount = callData.getBillingAccount();
		billingAccount.setHasDisconnectLetter(true);
		checkArrears = onegasCommonService.isCheckArrears(callData);
		assertTrue(checkArrears);

		callData = new CallData();
		billingAccount = callData.getBillingAccount();
		billingAccount.setHasDisconnectLetter(false);
		billingAccount.setHasOpenNonPaymentShutOffOrder(false);
		billingAccount.setHasPendingNonPaymentShutOffOrder(false);
		checkArrears = onegasCommonService.isCheckArrears(callData);
		assertFalse(checkArrears);
	}

	@Test
	public void isCheckPaymentTest() {

		CallData callData = new CallData();
		BillingAccount billingAccount = callData.getBillingAccount();

		callData = new CallData();
		callData.setField(Field.PAYMENT_AMOUNT, "4000.3332");
		billingAccount = callData.getBillingAccount();
		billingAccount.setDisconnectOrderDispatchStatus(Constants.ON_SITE);
		String checkPayment = onegasCommonService.checkPayment(callData);
		assertEquals(Constants.ON_SITE, checkPayment);

		callData = new CallData();
		callData.setField(Field.PAYMENT_AMOUNT, "4000.3332");
		billingAccount = callData.getBillingAccount();
		billingAccount.setDisconnectOrderDispatchStatus(Constants.ENROUTE);
		checkPayment = onegasCommonService.checkPayment(callData);
		assertEquals(Constants.ENROUTE, checkPayment);

		callData = new CallData();
		billingAccount = callData.getBillingAccount();
		billingAccount.setDisconnectOrderDispatchStatus("");
		billingAccount.setAmountPastDue(9445.555D);
		callData.setField(Field.PAYMENT_AMOUNT, "4000.3332");
		checkPayment = onegasCommonService.checkPayment(callData);
		assertEquals("AccountSummary", checkPayment);

		callData = new CallData();
		billingAccount = callData.getBillingAccount();
		billingAccount.setDisconnectOrderDispatchStatus("");
		billingAccount.setAmountPastDue(1445.555D);
		callData.setField(Field.PAYMENT_AMOUNT, "4000.3332");
		checkPayment = onegasCommonService.checkPayment(callData);
		assertEquals("CancelCollections", checkPayment);

	}

	@Test
	public void checkAmountStatusTest(){
		CallData callData = new CallData();
		BillingAccount billingAccount = new BillingAccount();
		billingAccount.setTotalAmountDue(0d);
		billingAccount.setAmountDue(0d);
		billingAccount.setAmountPastDue(0d);
		billingAccount.setTotalAccountBalance(0d);
		callData.setBillingAccount(billingAccount);
		String checkAmountStatus = onegasCommonService.checkAmountStatus(callData);
		Assert.assertEquals("no_payment_due", checkAmountStatus);
		billingAccount.setTotalAmountDue(1d);
		checkAmountStatus = onegasCommonService.checkAmountStatus(callData);
		Assert.assertEquals("no_payment_due", checkAmountStatus);
		billingAccount.setAmountDue(1d);
		checkAmountStatus = onegasCommonService.checkAmountStatus(callData);
		Assert.assertEquals("no_payment_due", checkAmountStatus);
		billingAccount.setAmountPastDue(1d);
		checkAmountStatus = onegasCommonService.checkAmountStatus(callData);
		Assert.assertEquals("past_due", checkAmountStatus);
		billingAccount.setAmountPastDue(0d);
		billingAccount.setTotalAccountBalance(-1d);;
		checkAmountStatus = onegasCommonService.checkAmountStatus(callData);
		Assert.assertEquals("no_payment_due", checkAmountStatus);
	}
	
	@Test
	public void meterReadTest(){
		CallData callData = new CallData();
		BillingAccount billingAccount = new BillingAccount();
		callData.setBillingAccount(billingAccount);
		BigDecimal bd = new BigDecimal(32820);
		billingAccount.setConsToRead(bd.intValue());
		String string = billingAccount.getConsToRead().toString();
		Assert.assertEquals("32820", string);
		
	}
	
	
	@Test
	public void isFirstDateBetweenSecondAndThirdDateTest(){
		CallData callData = new CallData();
		Calendar calendar = Calendar.getInstance();
		
		calendar.set(Calendar.MONTH, 3);
		calendar.set(Calendar.YEAR, 2017);
		
		Date firstDate = calendar.getTime();
		
		calendar.set(Calendar.MONTH, 5);
		calendar.set(Calendar.YEAR, 2017);
		
		Date secondDate = calendar.getTime();
		
		calendar.set(Calendar.MONTH, 7);
		calendar.set(Calendar.YEAR, 2017);
		
		Date thirdDate = calendar.getTime();
		
		Assert.assertTrue(onegasCommonService.isFirstDateBetweenSecondAndThirdDate(callData, secondDate, firstDate, thirdDate));
		Assert.assertTrue(onegasCommonService.isFirstDateBetweenSecondAndThirdDate(callData, secondDate, secondDate, thirdDate));
		Assert.assertTrue(onegasCommonService.isFirstDateBetweenSecondAndThirdDate(callData, secondDate, firstDate, thirdDate));
		Assert.assertFalse(onegasCommonService.isFirstDateBetweenSecondAndThirdDate(callData, secondDate, secondDate, firstDate));
		Assert.assertFalse(onegasCommonService.isFirstDateBetweenSecondAndThirdDate(callData, null, secondDate, thirdDate));
		Assert.assertFalse(onegasCommonService.isFirstDateBetweenSecondAndThirdDate(callData, thirdDate, null, thirdDate));
		Assert.assertFalse(onegasCommonService.isFirstDateBetweenSecondAndThirdDate(callData, thirdDate, thirdDate, null));
	}
	
	
	@Test
	public void vdnTransferTypeEnumTest(){
		
		Assert.assertNotNull(VDNTransferType.ACCT_INFO);
		Assert.assertNotNull(VDNTransferType.EMERGENCY);
		Assert.assertNotNull(VDNTransferType.NEW_SERVICE);
		Assert.assertNotNull(VDNTransferType.IVR_DEFAULT);
		Assert.assertNotNull(VDNTransferType.LETTER);
		Assert.assertNotNull(VDNTransferType.PAYMENTS);
		Assert.assertNotNull(VDNTransferType.SERV_ORDER);
		Assert.assertNotNull(VDNTransferType.START_SERV);
		Assert.assertNotNull(VDNTransferType.STOP_SERV);
		Assert.assertNotNull(VDNTransferType.BILL_OPTIONS);
		Assert.assertNotNull(VDNTransferType.BILL_STATEMENT);
		Assert.assertNotNull(VDNTransferType.CREDIT_REF);
		Assert.assertNotNull(VDNTransferType.OTHER);
		Assert.assertNotNull(VDNTransferType.PAPERLESS);
		Assert.assertNotNull(VDNTransferType.MTRREAD);
		
	}
	
	@Test 
	public void lookupAudioPhraseTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.AUDIO_PHRASE, "2060_ppSpecialMsgTxI1");
		Assert.assertEquals("false", onegasCommonService.lookupAudioPhrase(callData));
		callData.setField(Field.AUDIO_PHRASE, "key_to_not_find");
		Assert.assertNull(onegasCommonService.lookupAudioPhrase(callData));
			
	}
	
	@Test
	public void getAveragePaymentPlanAmountTest() throws Exception{
		
		CallData callData = new CallData();
		
		callData.getBillingAccount().setServiceID(1);
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.LAST_STATE, "last_state");
		Assert.assertTrue(onegasCommonService.getAveragePaymentPlanAmount(callData));
		Assert.assertEquals(new Double(122.54) , callData.getBillingAccount().getAveragePaymentAmount());
			
	}
	
	@Test
	public void requestPaymentArrangementFalseWithDownPaymentAmountTest() throws Exception{
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setPayArrangementDownPaymentAmount(new Double(123.45));
		
		onegasCommonService.requestPaymentArrangementFalseWithDownPaymentAmount(callData);
		
		Assert.assertEquals(new Double(19.83) , callData.getBillingAccount().getInstallmentAmount());
		Assert.assertEquals(new Integer(11) , callData.getBillingAccount().getInstallCount());
		Assert.assertEquals(new Double(218.16) , callData.getBillingAccount().getTotalAmountDue());
		Assert.assertEquals("2016-02-21T00:00:00" , callData.getBillingAccount().getDueDate());
			
	}
	
	@Test
	public void requestPaymentArrangementFalseWithDownPaymentAmountAndInstallmentsTest() throws Exception{
		
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.DOWN_PAYMENT, "123.45");
		callData.setField(Field.INSTALLMENTS, "3");

		onegasCommonService.requestPaymentArrangementFalseWithDownPaymentAmountAndInstallments(callData);
		
		Assert.assertEquals(new Double(19.83) , callData.getBillingAccount().getInstallmentAmount());
		Assert.assertEquals(new Integer(11) , callData.getBillingAccount().getInstallCount());
		Assert.assertEquals(new Double(218.16) , callData.getBillingAccount().getTotalAmountDue());
		Assert.assertEquals("2016-02-21T00:00:00" , callData.getBillingAccount().getDueDate());

	}
	
	@Test
	public void requestMoveOutOrderTest() throws Exception{
		CallData callData = new CallData();

		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.APP_DATE, "11242011");
		callData.setField(Field.ANI, "1234567");
		callData.getBillingAccount().setConfirmationNumber("12345");

		callData.getBillingAccount().setFirstName("Jane");
		callData.getBillingAccount().setLastName("Doe");
		callData.getBillingAccount().setMiddleName("Karen");
		
		Assert.assertTrue(onegasCommonService.requestMoveOutOrder(callData));
	
		Assert.assertEquals("AVAIL-0005539889", callData.getBillingAccount().getAppointmentConfirmationNumber());
		Assert.assertEquals("7102620", callData.getBillingAccount().getServiceOrderNumber());
		
	}
	
	@Test
	public void callReserveAppointmentTest() throws Exception{
		CallData callData = new CallData();

		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.APP_DATE, "11242011");
			
		Assert.assertTrue(onegasCommonService.callReserveAppointment(callData));
		Assert.assertEquals( "AVAIL-0005539889" , callData.getBillingAccount().getConfirmationNumber());
	}
	
	@Test
	public void updatePropertiesForTrueTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.AUDIO_PHRASE, "2040_ppSpecialMsgOkI1");
			
		Assert.assertTrue(onegasCommonService.updatePropertiesForTrue(callData));
		Assert.assertEquals( "true" , onegasCommonService.lookupAudioPhrase(callData));
		callData.setField(Field.AUDIO_PHRASE, "key_to_not_find");
		Assert.assertNull(onegasCommonService.lookupAudioPhrase(callData));
	}
	
	@Test
	public void updatePropertiesForFalseTest() throws Exception{
		CallData callData = new CallData();
		callData.setField(Field.AUDIO_PHRASE, "2040_ppSpecialMsgOkI1");
		
		Assert.assertTrue(onegasCommonService.updatePropertiesForFalse(callData));
		Assert.assertEquals( "false" , onegasCommonService.lookupAudioPhrase(callData));
			
	}
	
	@Test (expected = ServiceException.class)
	public void updatePropertiesForFalseWithMissingKeyTest() throws ServiceException{
		
		CallData callData = new CallData();
		callData.setField(Field.AUDIO_PHRASE, "key_to_not_find");
		
		onegasCommonService.updatePropertiesForFalse(callData);
	}
	
	
	
	public static IONEGASCommonService getOnegasCommonService() {
		return onegasCommonService;
	}

	public static void setOnegasCommonService(IONEGASCommonService onegasCommonService) {
		ONEGASCommonServiceTest.onegasCommonService = onegasCommonService;
	}
}*/