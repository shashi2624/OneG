/*
* AnnounceValueType.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/

package com.avaya.ept.onegas.bl.model;

/**
 * @author javantario
 *
 */
public enum AnnounceValueSSMode implements AnnounceValueMode {
	
	NUMBER {
		@Override
		public String value() {
			return "number";
		}	
	},
	DECIMAL {
		@Override
		public String value() {
			return "decimal";
		}	
	},
	INTEGER {
		@Override
		public String value() {
			return "integer";
		}	
	},
	DIGITS {
		@Override
		public String value() {
			return "digits";
		}	
	},
	DATE {
		@Override
		public String value() {
			return "date";
		}	
	},
	TIME {
		@Override
		public String value() {
			return "time";
		}	
	},
	TIME24 {
		@Override
		public String value() {
			return "time24";
		}	
	},
	CURRENCY {
		@Override
		public String value() {
			return "currency";
		}	
	},
	DAYMONTH {
		@Override
		public String value() {
			return "daymonth";
		}	
	};
}
