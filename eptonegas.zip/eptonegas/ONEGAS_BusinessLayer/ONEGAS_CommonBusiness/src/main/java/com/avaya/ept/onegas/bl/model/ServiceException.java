
/*
* ServiceException.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/

package com.avaya.ept.onegas.bl.model;


public class ServiceException extends Exception {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 3639981763649599853L;

	public ServiceException() {		
	}

	public ServiceException(String message) {
		super(message);		
	}

	public ServiceException(Throwable cause) {
		super(cause);
	}

	public ServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	

}
