
/*
* CAV.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/

package com.avaya.ept.onegas.bl.model;

public enum CAV {
	
	specialMsgOK, specialMsgTX, specialMsgKS,
	RDM_propertiesLocation, location, aniSsn,
	convenienceFeeKS, convenienceFeeOK, convenienceFeeTX,
	enableSms, endYearVfp, gasPriceVfp, 
	maintenanceKS, maintenanceOK, maintenanceTX,
	 officeOpen,
	payArrangeHoursKS, payArrangeHoursOK, payArrangeHoursTX,
	phoneSsn, startYearVfp, wrapUP, maxError, firstPass, reenterInfo,
	satStartHoursOKNCO, satStartHoursKSNCO, satStopHoursKSNCO, satStopHoursOKNCO, CS_LeaseTime, CS_RID, audioPassword,
	
	//09-22-2021 ONEGAS Phase 2 changes.
	HOSOtther, VendorCheckingKS, VendorCheckingOK, OKCheckfee, KSCheckfee, TXCheckfee, OKPaymentArrange, TXPaymentArrange, KSPaymentArrange,
	
	//21-02-2022 added OtherCSR for Change control challenger
	OtherCSR,	

	// Update at 23-08-2022 for ONEGAS IVR Phase 2c
	startPeriodVFP, endPeriodVFP,
	
	// Phase 2D Sprint 2
	holidayOK, holidayKS, PlanAPrice, PlanBPrice, PerDthFee, WinterRuleStart,WinterRuleStop,
	 Alorica, Vend1Dec, holidayVend1, holidayVend1_phone, Emergency_SW_Vend1, MondayHoursVEND1, TuesdayHoursVEND1, WednesdayHoursVEND1, ThursdayHoursVEND1, FridayHoursVEND1, SaturdayHoursVEND1, SundayHoursVEND1,
	Vend2Dec, holidayVend2, holidayVend2_phone, Emergency_SW_Vend2, MondayHoursVEND2, TuesdayHoursVEND2, WednesdayHoursVEND2, ThursdayHoursVEND2, FridayHoursVEND2, SaturdayHoursVEND2, SundayHoursVEND2,
	Vend3Dec, holidayVend3, holidayVend3_phone, Emergency_SW_Vend3, MondayHoursVEND3, TuesdayHoursVEND3, WednesdayHoursVEND3, ThursdayHoursVEND3, FridayHoursVEND3, SaturdayHoursVEND3, SundayHoursVEND3,
	Vend4Dec, holidayVend4, holidayVend4_phone, Emergency_SW_Vend4, MondayHoursVEND4, TuesdayHoursVEND4, WednesdayHoursVEND4, ThursdayHoursVEND4, FridayHoursVEND4, SaturdayHoursVEND4, SundayHoursVEND4,
	Vend5Dec, holidayVend5, holidayVend5_phone, Emergency_SW_Vend5, MondayHoursVEND5, TuesdayHoursVEND5, WednesdayHoursVEND5, ThursdayHoursVEND5, FridayHoursVEND5, SaturdayHoursVEND5, SundayHoursVEND5,
	Vend6Dec, holidayVend6, holidayVend6_phone, Emergency_SW_Vend6, MondayHoursVEND6, TuesdayHoursVEND6, WednesdayHoursVEND6, ThursdayHoursVEND6, FridayHoursVEND6, SaturdayHoursVEND6, SundayHoursVEND6,
	Vend7Dec, holidayVend7, holidayVend7_phone, Emergency_SW_Vend7, MondayHoursVEND7, TuesdayHoursVEND7, WednesdayHoursVEND7, ThursdayHoursVEND7, FridayHoursVEND7, SaturdayHoursVEND7, SundayHoursVEND7,
	Vend8Dec, holidayVend8, holidayVend8_phone, Emergency_SW_Vend8, MondayHoursVEND8, TuesdayHoursVEND8, WednesdayHoursVEND8, ThursdayHoursVEND8, FridayHoursVEND8, SaturdayHoursVEND8, SundayHoursVEND8,
	HighVolumeMessage, maintenance_Days, PBP_CC_Vendor_Down_Message, PBP_CK_Vendor_Down_Message, PBPVendor_Down, PBPVendor_Down_Trans, PBPVendor_Down_Message,

	Holiday_Msg_OKENG, Holiday_Msg_OKSPA, FinancialMsgOKSW, FinancialMsgOK, MondayHoursOK, TuesdayHoursOK, WednesdayHoursOK, ThursdayHoursOK, FridayHoursOK, SaturdayHoursOK, SundayHoursOK,
	 gasPriceVFP, startYearVFP, endYearVFP, 
	 
	 holidayTX, Holiday_Msg_TXENG, Holiday_Msg_TXSPA, MondayHoursTX, TuesdayHoursTX, WednesdayHoursTX, ThursdayHoursTX, FridayHoursTX, SaturdayHoursTX, SundayHoursTX, TXABCStartDateCHG, TXABCStoptDateCHG, TXABCCHPRMPT, FinancialMsgTXSW, FinancialMsgTX,
	 VendorCheckingTX, 
	  
	 Holiday_Msg_KSENG, Holiday_Msg_KSSPA, MondayHoursKS, TuesdayHoursKS, WednesdayHoursKS, ThursdayHoursKS, FridayHoursKS, SaturdayHoursKS, SundayHoursKS, FinancialMsgKSSW, FinancialMsgKS,
	  
	  //AMHS_Change Phase 2D
	 AMHS_Transfer,
	 //Pay By Phone
	 I3Paybyphone,I3Call_Lang,I3authenticated,AuthI3Transfer,
	 //Stop Change Phase 5.3
	 OK_Stop_Move_Appl_Sw,
	 TX_Stop_Move_Appl_Sw,
	 KS_Stop_Move_Appl_Sw,
	 OK_Billing_Message_Sw, 
	 OK_Billing_Message,
	 TX_Billing_Message_Sw,
	 TX_Billing_Message,
	 KS_Billing_Message_Sw,
	 KS_Billing_Message,
	 Post_Stop_Sw,
}