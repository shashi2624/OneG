
/*
* LanguageEnum.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/

package com.avaya.ept.onegas.bl.model;

public enum LanguageEnum {
	
	ENGLISH("English"),
	SPANISH("Spanish");
	
	private final String languageName;
	
	private LanguageEnum(String languageName) {
		this.languageName = languageName;
	}
	
	
	public String getLanguageName() {
		return languageName;
	}
	
	
}
