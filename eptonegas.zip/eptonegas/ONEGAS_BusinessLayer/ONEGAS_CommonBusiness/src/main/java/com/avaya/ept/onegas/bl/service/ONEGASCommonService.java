/*
 * ONEGASCommonService.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */

package com.avaya.ept.onegas.bl.service;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.Interval;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;

import com.avaya.ept.onegas.backend.contextstore.types.ContextStoreService;
import com.avaya.ept.onegas.backend.contextstore.utils.ContextStoreKeys;
import com.avaya.ept.onegas.bl.model.BillingAccount;
import com.avaya.ept.onegas.bl.model.CAV;
import com.avaya.ept.onegas.bl.model.CallData;
import com.avaya.ept.onegas.bl.model.Constants;
import com.avaya.ept.onegas.bl.model.Field;
import com.avaya.ept.onegas.bl.model.InvalidDayException;
import com.avaya.ept.onegas.bl.model.InvalidMonthException;
import com.avaya.ept.onegas.bl.model.InvalidYearException;
import com.avaya.ept.onegas.bl.model.LanguageEnum;
import com.avaya.ept.onegas.bl.model.VdnLanguage;
import com.avaya.ept.onegas.bl.model.TransferVdnByDIDLookup;
import com.avaya.ept.onegas.bl.model.ServiceConfiguration;
import com.avaya.ept.onegas.bl.model.ServiceException;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountClientServiceException;
import com.avaya.ept.onegas.ws.billing.exception.BillingAccountClientServiceNotFoundException;
import com.avaya.ept.onegas.ws.billing.model.AccountLookupResult;
import com.avaya.ept.onegas.ws.billing.model.AlertInfo;
import com.avaya.ept.onegas.ws.billing.model.AppointmentAvailability;
import com.avaya.ept.onegas.ws.billing.model.AppointmentAvailabilityInfo;
import com.avaya.ept.onegas.ws.billing.model.AppointmentReservationResponse;
import com.avaya.ept.onegas.ws.billing.model.AppointmentType;
import com.avaya.ept.onegas.ws.billing.model.BankAccountType;
import com.avaya.ept.onegas.ws.billing.model.BillingAccountInfo;
import com.avaya.ept.onegas.ws.billing.model.CurrentPaymentInfo;
import com.avaya.ept.onegas.ws.billing.model.MeterEntryResponse;
import com.avaya.ept.onegas.ws.billing.model.MoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.OpenServiceOrderDetail;
import com.avaya.ept.onegas.ws.billing.model.PaymentArrangementDetail;
import com.avaya.ept.onegas.ws.billing.model.PaymentArrangmentInfo;
import com.avaya.ept.onegas.ws.billing.model.PaymentHistoryInfo;
import com.avaya.ept.onegas.ws.billing.model.PaymentInfo;
import com.avaya.ept.onegas.ws.billing.model.ServiceInfo;
import com.avaya.ept.onegas.ws.billing.model.ServiceOrderChangeResponse;
import com.avaya.ept.onegas.ws.billing.service.IBillingAccountService;
import com.avaya.ept.onegas.ws.location.exception.LocationClientServiceException;
import com.avaya.ept.onegas.ws.location.model.LocationInfo;
import com.avaya.ept.onegas.ws.location.service.ILocationService;

public class ONEGASCommonService implements IONEGASCommonService {

	/**
	 * 
	 */
	private static final String SAVING = "S";
	/**
	 * 
	 */
	private static final String CHECKING = "C";
	/**
	 * 
	 */
	private static final String STATUS = "Status";
	/**
	 * 
	 */
	private static final String STATUS_CODE_OK = "0";
	private static final int JANUARY_MONTH_NUMBER = 1;
	private static final int DECEMBER_MONTH_NUMBER = 12;
	private static final int MILLIS_60_DAYS = 60 * 1000 * 60 * 60 * 24;
	private static final int YEAR_LENGTH = 4;
	private static final int DATE_LENGTH = 8;
	private static final String ROUTING_NUMBER_LOG = "routingNumber: ";
	private static final String BANK_ACC_TYPE_LOG = "bankAccType: ";
	private static final String BANK_NUMBER_LOG = "bankNumber: ";
	private static final String ACCOUNT_NUMBER_LOG = "accountNumber: ";
	private static final String ANONYMOUS = "anonymous";
	private static final String COMMA = ",";
	private static final String UNENROLL = "UnEnroll";
	private static final String ENROLL = "Enroll";
	private static final String UPDATE = "Update";
	private static final String RESCHEDULE = "Reschedule";
	private static final String NULL = "NULL";
	private static final String CANCEL_COLLECTIONS = "CancelCollections";
	private static final String ACCOUNT_SUMMARY = "AccountSummary";

	private static final int NUMBER_630 = 630;
	private static final int NUMBER_701 = 701;
	private static final int NUMBER_331 = 331;
	private static final long LONG_930 = 930;
	private static final long LONG_1201 = 1201;
	private static final long LONG_1001 = 1001;

	private static final String FALL = "Fall";
	private static final String WINTER = "Winter";
	private static final String SUMMER = "Summer";
	private static final String SPRING = "Spring";
	private static final String EMPTY_FIELD = "";

	@Autowired
	private ServiceConfiguration serviceConfig;
	@Autowired
	private IBillingAccountService billingAccountService;
	@Autowired
	private ILocationService locationService;
	@Autowired
	private ContextStoreService contextStoreService;

	private String getLanguageFolder(CallData callData) {
		String lang = callData.getField(Field.LANGUAGE);

		if (lang != null) {
			if (Constants.SPANISH.equalsIgnoreCase(lang)) {
				return LanguageEnum.SPANISH.getLanguageName();
			} else {
				return LanguageEnum.ENGLISH.getLanguageName();
			}
		} else {
			return LanguageEnum.ENGLISH.getLanguageName();
		}
	}

	public String getGrammarURL(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting GrammarURL.");
		String dataLocation = serviceConfig.getRdmDataUrl();
		return dataLocation + "Grammars" + Constants.URL_SEPARATOR;
	}

	public String getCustomAudioURL(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting CustomAudioURL.");
		String language = getLanguageFolder(callData);
		String dataLocation = serviceConfig.getRdmDataUrl();
		return dataLocation + "Audios" + Constants.URL_SEPARATOR + language + Constants.URL_SEPARATOR + "Custom" + Constants.URL_SEPARATOR;
	}

	public String getStandardSpeechAudioURL(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting StandardAudioURL.");
		String language = getLanguageFolder(callData);
		String dataLocation = serviceConfig.getRdmDataUrl();
		return dataLocation + "Audios" + Constants.URL_SEPARATOR + language + Constants.URL_SEPARATOR + "Standard" + Constants.URL_SEPARATOR;
	}

	@Override
	public String getDateAsString(Date date) {
		DateFormat df = new SimpleDateFormat(Constants.DATE_FORMAT);
		return df.format(date);
	}

	@Override
	public String getDateAsStringYYYMMDD(Date date) {
		DateFormat df = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);
		return df.format(date);
	}

	@Override
	public boolean isFieldNotNullOrEmpty(String field) {
		return (field != null && !EMPTY_FIELD.equalsIgnoreCase(field));
	}

	/**
	 * @param callData
	 * @param today
	 * @param dateFormat
	 * @return
	 * @throws ServiceException
	 */
	private boolean isHoliday(CallData callData, Date today) throws ServiceException {
		//Updated as per Phase 2D sprint 2 requirement 
		String location=callData.getCAV(CAV.location);
		String cavHolidays=null;
		if(location.equalsIgnoreCase("OK")) {
			cavHolidays = callData.getCAV(CAV.holidayOK);}
		else if(location.equalsIgnoreCase("KS")) {
			 cavHolidays = callData.getCAV(CAV.holidayKS);}
		else if(location.equalsIgnoreCase("TX")) {
			 cavHolidays = callData.getCAV(CAV.holidayTX);}
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
		DateTime now = new DateTime();
		DateTimeFormatter formatter = DateTimeFormat.forPattern(Constants.DATE_FORMAT + " " + Constants.TIME_FORMAT);
		
		if (!StringUtils.isBlank(cavHolidays) ) {
			String todayStr = dateFormat.format(today);
			ODLogger.logDebug(callData.getSceSession(), "### Getting time to compare."+now.toString(formatter));
			try {
				String[] holidays = cavHolidays.split(Pattern.quote(COMMA));
				for (String holiday : holidays) {
					String[] dateTime=holiday.split(";");
					
					if (isDateTimeFormat(holiday) && todayStr.equals(dateTime[0])) {
						String[] time=dateTime[1].split(Constants.URL_SEPARATOR);
						String startTime = time[0];
						String endTime = time[1];
						
						return belongsToInterval(startTime, endTime, todayStr, now, formatter);
						
					}
				}
				return false;
			} catch (PatternSyntaxException e) {
				throw new ServiceException("error parsing today holiday", e);
			}
		} else {
			return false;
		}
	}

	@Override
	public boolean isAHolidayDate(CallData callData, Date aDate) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isAHolidayDate.");
		return isHoliday(callData, aDate);
	}

	@Override
	public void setLdcProvider(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Setting ldcProvider.");
		String location = callData.getCAV(CAV.location);
		if (Constants.OK.equalsIgnoreCase(location)) {
			callData.setField(Field.LDCPROVIDER, Constants.ONG);
		} else if (Constants.TX.equalsIgnoreCase(location)) {
			callData.setField(Field.LDCPROVIDER, Constants.TGS);
		} else if (Constants.KS.equalsIgnoreCase(location)) {
			callData.setField(Field.LDCPROVIDER, Constants.KGS);
		}
	}

	@Override
	public boolean isOfficeOpen(CallData callData, Date today) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isOfficeOpen.");
		setLdcProvider(callData);
		if (isHoliday(callData, today)) {
			return false;
		} else {
			return checkBusinessHours(callData, today);
		}
	}

	private boolean checkBusinessHours(CallData callData, Date today) throws ServiceException {
		//Updated as per Phase 2D sprint 2 requirement
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
		String location = callData.getCAV(CAV.location);
		String workingHours = null;
		
		String todayStr = dateFormat.format(today);
		ODLogger.logDebug(callData.getSceSession(), "today: " + todayStr);
		DateTime now = new DateTime();
		int dayOfWeek = now.getDayOfWeek();
		if (Constants.OK.equalsIgnoreCase(location)) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursOK);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursOK);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursOK);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursOK);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursOK);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursOK);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursOK);
		} else if (Constants.TX.equalsIgnoreCase(location)) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursTX);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursTX);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursTX);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursTX);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursTX);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursTX);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursTX);
		} else if (Constants.KS.equalsIgnoreCase(location)) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursKS);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursKS);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursKS);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursKS);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursKS);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursKS);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursKS);
		} else {
			throw new ServiceException("Invalid location: " + location);
		}
		
		
		DateTimeFormatter formatter = DateTimeFormat.forPattern(Constants.DATE_FORMAT + " " + Constants.TIME_FORMAT);

			if (StringUtils.isNotBlank(workingHours)) {
				String[] hours= workingHours.split(Constants.URL_SEPARATOR);
				String StartHours= hours[0];
				String StoptHours= hours[1];
				return belongsToInterval(StartHours, StoptHours, todayStr, now, formatter);
		} 
		return false;
	}

	private boolean belongsToInterval(String startHours, String stopHours, String todayStr, DateTime now, DateTimeFormatter formatter) throws ServiceException {
		DateTime from = DateTime.parse(todayStr + " " + startHours, formatter);
		DateTime to = DateTime.parse(todayStr + " " + stopHours, formatter);
		Interval interval = new Interval(from, to);
		return interval.contains(now);
		
	}

	@Override
	public boolean isANINull(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isANINull.");
		String ani = callData.getField(Field.ANI);
		return ("".equalsIgnoreCase(ani) || ANONYMOUS.equalsIgnoreCase(ani));
	}

	@Override
	public String getPropertiesFilesPath(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting Properties URL.");
		return serviceConfig.getRdmPropsPath();
	}

	@Override
	public String getVoiceRecordedFilesPath(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting VoiceRecording URL.");
		return serviceConfig.getVoiceRecPath();
	}

	@Override
	public String getVoiceRecordedFilesCompletePath(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting VoiceRecording Complete Path.");
		return serviceConfig.getVoiceRecPath() + "/" + getLanguageFolder(callData) + "/Custom";
	}

	@Override
	public String getSeason(CallData callData, String today) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getSeason.");

		String season = "";
		long dateLong = Long.parseLong(today);

		if (dateLong > NUMBER_331 && dateLong < NUMBER_701) {
			season = SPRING;
		} else if (dateLong > NUMBER_630 && dateLong < LONG_1001) {
			season = SUMMER;
		} else if (dateLong > LONG_930 && dateLong < LONG_1201) {
			season = FALL;
		} else {
			season = WINTER;
		}
// season values was swapped by CAS team in-regard to fix SR#1-12658383701 inside above else if, else block.	
		return season;
	}

	@Override
	public boolean isAccountStatusOk(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isAccountStatusOk.");

		/*String accountStatus = callData.getBillingAccount().getAccountStatus();
		boolean hasBadDebt = callData.getBillingAccount().isHasBadDebt();*/
		boolean isMasterBill = callData.getBillingAccount().isMasterBill();
		boolean canUseWebAccess = callData.getBillingAccount().isCanUseWebAccess();

		/*ODLogger.logDebug(callData.getSceSession(), "accountStatus: " + accountStatus);
		ODLogger.logDebug(callData.getSceSession(), "hasBadDebt: " + hasBadDebt);*/
		ODLogger.logDebug(callData.getSceSession(), "isMasterBill: " + isMasterBill);
		ODLogger.logDebug(callData.getSceSession(), "canUseWebAccess: " + canUseWebAccess);

		// 2019-02-06 TS-DDV : Per Project Two specs, removed "Final" as condition for isAccountStatusOk=FALSE;
		//return !("Final".equalsIgnoreCase(accountStatus) || Constants.TRUE.equalsIgnoreCase(String.valueOf(hasBadDebt)) || Constants.TRUE.equalsIgnoreCase(String.valueOf(isMasterBill)) || Constants.FALSE.equalsIgnoreCase(String.valueOf(canUseWebAccess)));
		//return !(Constants.TRUE.equalsIgnoreCase(String.valueOf(hasBadDebt)) || Constants.TRUE.equalsIgnoreCase(String.valueOf(isMasterBill)) || Constants.FALSE.equalsIgnoreCase(String.valueOf(canUseWebAccess)));
		// 2021-10-04 Removed 'hasBadDebt' as per ONEGAS phase 2 changes.
		return !(Constants.TRUE.equalsIgnoreCase(String.valueOf(isMasterBill)) || Constants.FALSE.equalsIgnoreCase(String.valueOf(canUseWebAccess)));
	}

	@Override
	public boolean isMultiAccounts(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isMultiAccounts.");

		List<AccountLookupResult> accountLookupList = callData.getAccountLookupList();

		if (accountLookupList == null) {
			throw new ServiceException("Account LookUp Result is NULL!");
		} else {
			ODLogger.logDebug(callData.getSceSession(), "### Account LookUp List Size = " + accountLookupList.size());
			if (accountLookupList.size() == 0) {
				throw new ServiceException("Account LookUp Result is EMPTY!");
			} else {
				if (accountLookupList.size() == 1) {
					AccountLookupResult accountLookupResult = accountLookupList.get(0);
					callData.getBillingAccount().setAccountNumber(accountLookupResult.getAccountNumber().getValue());
					callData.getBillingAccount().setFirstName(accountLookupResult.getFirstName().getValue());
					callData.getBillingAccount().setLastName(accountLookupResult.getLastName().getValue());
					callData.getBillingAccount().setAddress(accountLookupResult.getServiceAddress().getValue());
					callData.getBillingAccount().setAccountStatus(accountLookupResult.getAccountStatus().getValue());
					return false;
				} else {
					return true;
				}
			}
		}

	}

	@Override
	public int checkHouseNumbAmount(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting checkHouseNumbAmount.");
		List<AccountLookupResult> accountLookupList = callData.getAccountLookupList();
		String inputHouseNum = callData.getField(Field.HOUSE_NUM);
		int houseNumAmountMatches = 0;
		int numberOfAccount = 0;

		for (AccountLookupResult accountLookupResult : accountLookupList) {
			String address = accountLookupResult.getServiceAddress().getValue();
			String[] addressArray = address.split(" ");
			String houseNumber = addressArray[0];
			ODLogger.logDebug(callData.getSceSession(), "House Number of the Account [" + numberOfAccount + "] = " + houseNumber);

			if (houseNumber.equalsIgnoreCase(inputHouseNum)) {
				houseNumAmountMatches += 1;
			}
		}

		return houseNumAmountMatches;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#getCurrencyFormat()
	 */
	@Override
	public String getCurrencyFormat(String currency) {
		return "SS:" + currency + ":currency";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#getDigitsFormat(
	 * java.lang.String)
	 */
	@Override
	public String getDigitsFormat(String digits) {
		return "SS:" + digits + ":digits";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#getDateFormat(java
	 * .lang.String)
	 */
	@Override
	public String getDateFormat(String date) {
		// TODO Auto-generated method stub
		return "SS:" + date + ":date";
	}

	@Override
	public String isThisDateValid(String dateToValidate, String dateFormat, CallData callData) throws InvalidYearException, InvalidMonthException, InvalidDayException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isThisDateValid.");

		if (dateToValidate == null || dateToValidate.isEmpty()) {
			throw new InvalidYearException("The date to validate is empty or null");
		}

		ODLogger.logDebug(callData.getSceSession(), "### IsThisDateValid parameters =  " + " Date to validate: " + dateToValidate + " | Date Format:  " + dateFormat);

		if (dateToValidate.length() != DATE_LENGTH) {
			throw new InvalidYearException("The date to validate does not have 8 digits");
		}
		int monthToValidate = Integer.valueOf(dateToValidate.substring(0, 2));
		int yearToValidate = Integer.valueOf(dateToValidate.substring(YEAR_LENGTH));
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);

		if (currentYear != yearToValidate) {
			throw new InvalidYearException("The year to validate:" + yearToValidate + " and the current year:" + currentYear + "does not match");
		}

		if (monthToValidate < JANUARY_MONTH_NUMBER || monthToValidate > DECEMBER_MONTH_NUMBER) {
			throw new InvalidMonthException("The month is invalid (not 1-12)");
		}
		try {
			// if not valid, it will throw ParseException
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			sdf.setLenient(false);
			sdf.parse(dateToValidate);
		} catch (ParseException e) {
			throw new InvalidDayException(e + " --> The day is invalid");
		}
		return "ok";
	}

	@Override
	public boolean isDateValid(String dateToValidate, String dateFormat, CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isDateValid.");

		if (dateToValidate == null || dateToValidate.isEmpty()) {
			return false;
		}

		ODLogger.logDebug(callData.getSceSession(), "### IsDateValid parameters =  " + " Date to validate: " + dateToValidate + " | Date Format:  " + dateFormat);
		try {
			// if not valid, it will throw ParseException
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			sdf.setLenient(false);
			sdf.parse(dateToValidate);
		} catch (ParseException e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean isCheckArrears(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isCheckArrears.");

		BillingAccount billingAccount = callData.getBillingAccount();

		ODLogger.logDebug(callData.getSceSession(), "### billingAccount.isHasOpenNonPaymentShutOffOrder()" +billingAccount.isHasOpenNonPaymentShutOffOrder());
		ODLogger.logDebug(callData.getSceSession(), "### billingAccount.isHasOpenNonPaymentShutOffOrder()" +billingAccount.isHasPendingNonPaymentShutOffOrder());
		ODLogger.logDebug(callData.getSceSession(), "### billingAccount.isHasOpenNonPaymentShutOffOrder()" +billingAccount.isHasDisconnectLetter());
		
		if (billingAccount.isHasOpenNonPaymentShutOffOrder() || billingAccount.isHasPendingNonPaymentShutOffOrder() || billingAccount.isHasDisconnectLetter()) {
			return true;
		}

		return false;
	}

	@Override
	public String checkPayment(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting checkPayment.");

		BillingAccount billingAccount = callData.getBillingAccount();

		Double paymentAmt = Double.parseDouble(callData.getField(Field.PAYMENT_AMOUNT));
		ODLogger.logDebug(callData.getSceSession(), "paymentAmt:" + paymentAmt);

		if (Constants.ON_SITE.equalsIgnoreCase(billingAccount.getDisconnectOrderDispatchStatus()) || Constants.ENROUTE.equalsIgnoreCase(billingAccount.getDisconnectOrderDispatchStatus())) {
			return billingAccount.getDisconnectOrderDispatchStatus();
		} else if (paymentAmt < billingAccount.getAmountPastDue()) {
			return ACCOUNT_SUMMARY;
		}

		return CANCEL_COLLECTIONS;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#lookupBillingAccount
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean lookupBillingAccountAni(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting lookupBillingAccountAni.");

		String ani = callData.getField(Field.ANI);
		String ldcProvider = callData.getField(Field.LDCPROVIDER);

		try {
			List<AccountLookupResult> billingAccountList = getBillingAccountService().lookupBillingAcount(ani, ldcProvider);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			if (billingAccountList.size() != 0) {
				callData.setAccountLookupList(billingAccountList);
				callData.setField(Field.ANIMATCH, "true");
				return true;
			} else {
				return false;
			}
		} catch (BillingAccountClientServiceNotFoundException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			return false;
		} catch (BillingAccountClientServiceException e) {
			ODLogger.logError(callData.getSceSession(), e.getMessage());
			throw new ServiceException(e);
		}
	}

	/**
	 * @return the billingAccountService
	 */
	public IBillingAccountService getBillingAccountService() {
		return billingAccountService;
	}

	/**
	 * @param billingAccountService
	 *            the billingAccountService to set
	 */
	public void setBillingAccountService(IBillingAccountService billingAccountService) {
		this.billingAccountService = billingAccountService;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#getOpenServiceOrders
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean getAccountSummary(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getAccountSummary1.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		ODLogger.logDebug(callData.getSceSession(), "accountNumber:" + accountNumber);
		return getAccountSummary(callData, accountNumber);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * getAccountSummaryCallerInput(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean getAccountSummaryCallerInput(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getAccountSummaryCallerInput.");
		String accountNumber = callData.getField(Field.ACCT_NUMBER);
		ODLogger.logDebug(callData.getSceSession(), "accountNumber:" + accountNumber);
		return getAccountSummary(callData, accountNumber);

	}

	/**
	 * @param callData
	 * @param accountNumber
	 * @return
	 * @throws ServiceException
	 */
	private boolean getAccountSummary(CallData callData, String accountNumber) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getAccountSummary2.");
		try {
			BillingAccountInfo billingAccountInfo = getBillingAccountService().getAccountSummary(accountNumber);

			setBillingAccountBasicProperties(callData, billingAccountInfo);

			setBillingAccountServiceOrders(callData, billingAccountInfo);

			setBillingAccountServices(callData, billingAccountInfo);

			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			ODLogger.logDebug(callData.getSceSession(), "### Getting getAccountSummary2 true case.");
			return true;
		} catch (BillingAccountClientServiceNotFoundException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.logDebug(callData.getSceSession(), "### Getting getAccountSummary2 false case,e.getStatusCode() "+String.valueOf(e.getStatusCode()));
			callData.setField(Field.STATUSCODE, String.valueOf(e.getStatusCode()));
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			return false;
		} catch (BillingAccountClientServiceException e) {
			ODLogger.logDebug(callData.getSceSession(), "### Getting getAccountSummary2 exception case."+e);
			throw new ServiceException(e);
		}
	}

	private void setBillingAccountServices(CallData callData, BillingAccountInfo billingAccountInfo) {
		List<ServiceInfo> serviceInfoList = billingAccountInfo.getServices().getValue().getServiceInfo();
		if (!serviceInfoList.isEmpty()) {
			ServiceInfo serviceInfo = serviceInfoList.get(0);
			callData.getBillingAccount().setServiceID(serviceInfo.getId());
			boolean hasPendingVoluntaryFixedPrice = serviceInfo.isHasPendingVoluntaryFixedPrice().booleanValue();
			callData.getBillingAccount().setHasPendingVoluntaryFixedPrice(hasPendingVoluntaryFixedPrice);
			callData.getBillingAccount().setEnrolledInBudget((serviceInfo.isIsEnrolledInBudget()));
			boolean voluntaryFixedPriceEligible = serviceInfo.isIsVoluntaryFixedPriceEligible().booleanValue();
			callData.getBillingAccount().setVoluntaryFixedPriceEligible(voluntaryFixedPriceEligible);
			int servicesCount = billingAccountInfo.getServices().getValue().getServiceInfo().size();
			callData.getBillingAccount().setServiceCount(servicesCount);
			if (servicesCount == 1) {
				callData.getBillingAccount().setCanReadMeter(billingAccountInfo.getServices().getValue().getServiceInfo().get(0).isCanReadMeter());
				callData.getBillingAccount().setMeterDials(billingAccountInfo.getServices().getValue().getServiceInfo().get(0).getMeterDials().toString());
				Integer consToRead = billingAccountInfo.getServices().getValue().getServiceInfo().get(0).getConsToRead().getValue();
				callData.getBillingAccount().setConsToRead(consToRead != null ? consToRead : null);
				BigDecimal consumption = billingAccountInfo.getServices().getValue().getServiceInfo().get(0).getConsumption().getValue();
				callData.getBillingAccount().setConsumption(consumption != null ? consumption.doubleValue() : null);
				callData.getBillingAccount().setNextReadDate(billingAccountInfo.getServices().getValue().getServiceInfo().get(0).getNextReadDate().getValue());
			}
		}
	}

	private void setBillingAccountServiceOrders(CallData callData, BillingAccountInfo billingAccountInfo) {
		XMLGregorianCalendar value = billingAccountInfo.getServiceOrders().getValue().getPending502NeedDate().getValue();
		callData.getBillingAccount().setPending502NeedDate(value == null);
		value = billingAccountInfo.getServiceOrders().getValue().getPendingMoveOutNeedDate().getValue();
		callData.getBillingAccount().setPendingMoveOutNeedDate(value == null);
		callData.getBillingAccount().setDownPayment(billingAccountInfo.getPayArrangementDownPaymentAmount().getValue().doubleValue());
		callData.getBillingAccount().setPayArrangementDownPaymentAmount(billingAccountInfo.getPayArrangementDownPaymentAmount().getValue().doubleValue());
		callData.getBillingAccount().setHasOpenNonPaymentShutOffOrder(billingAccountInfo.getServiceOrders().getValue().isHasOpenNonPaymentShutoffOrder());
		callData.getBillingAccount().setHasPendingNonPaymentShutOffOrder(billingAccountInfo.getServiceOrders().getValue().isHasPendingNonPaymentShutoffOrder());
		callData.getBillingAccount().setDisconnectOrderDispatchStatus(billingAccountInfo.getServiceOrders().getValue().getDisconnectOrderDispatchStatus().getValue());
		callData.getBillingAccount().setHasDisconnectLetter(billingAccountInfo.getCollections().getValue().isHasDisconnectLetter());
	}

	private void setBillingAccountBasicProperties(CallData callData, BillingAccountInfo billingAccountInfo) {
		setBillingAccountCustomerPersonalProperties(callData, billingAccountInfo);
		
		XMLGregorianCalendar dueDateResponse = billingAccountInfo.getCurrentBill().getValue().getDueDate().getValue();
		if (dueDateResponse != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);
			Date dueDate = dueDateResponse.toGregorianCalendar().getTime();
			callData.getBillingAccount().setDueDate(sdf.format(dueDate));
		}
		
		readLatestAllowedDateForPastDuePayment(callData, billingAccountInfo);
		
		setBillingAccountBankInfoExtract(callData, billingAccountInfo);
		
		setBillingAccountBankAccountType(callData, billingAccountInfo);
		
		callData.getBillingAccount().setCanMakeMemoPayment(billingAccountInfo.getEligibilityIndicators().getValue().isCanMakeMemoPayment());
		callData.getBillingAccount().setAddress(billingAccountInfo.getServiceAddress().getValue().getStreetAddress().getValue());
		callData.getBillingAccount().setCanMakePaymentArrangement(billingAccountInfo.getEligibilityIndicators().getValue().isCanMakePaymentArrangement());

		List<AlertInfo> alertInfo = billingAccountInfo.getAlerts().getValue().getAlertInfo();
		if (alertInfo != null && !alertInfo.isEmpty()) {
			callData.setAlertInfo(alertInfo.get(0));
		}

		if (billingAccountInfo.getPayments().getValue() != null) {
			CurrentPaymentInfo payment = billingAccountInfo.getPayments().getValue();
			callData.getBillingAccount().setLastPaymentAmount(payment.getLastPaymentAmount().getValue() == null ? 0d : payment.getLastPaymentAmount().getValue().doubleValue());
			callData.getBillingAccount().setLastPaymentDate(payment.getLastPaymentDate().getValue() == null ? null : payment.getLastPaymentDate().getValue().toGregorianCalendar().getTime());
		}
	}

	/**
	 * @param callData
	 * @param billingAccountInfo
	 */
	private void setBillingAccountBankInfoExtract(CallData callData,
			BillingAccountInfo billingAccountInfo) {
		callData.getBillingAccount().setTotalAmountDue(billingAccountInfo.getCurrentBill().getValue().getTotalAmountDue().getValue() == null ? 0d : billingAccountInfo.getCurrentBill().getValue().getTotalAmountDue().getValue().doubleValue());
		callData.getBillingAccount().setHasBadDebt(billingAccountInfo.getCurrentIndicators().getValue().isHasBadDebt());
		callData.getBillingAccount().setMasterBill(billingAccountInfo.getCurrentIndicators().getValue().isIsMasterBill());
		callData.getBillingAccount().setOnEbill(billingAccountInfo.getCurrentIndicators().getValue().isIsOnEBill());
		callData.getBillingAccount().setOnBudget(billingAccountInfo.getCurrentIndicators().getValue().isIsOnBudget());
		callData.getBillingAccount().setOnPayArrangement(billingAccountInfo.getCurrentIndicators().getValue().isIsOnPayArrangement());
		callData.getBillingAccount().setTotalAccountBalance(billingAccountInfo.getCurrentBill().getValue().getTotalAccountBalance().getValue() == null ? 0d : billingAccountInfo.getCurrentBill().getValue().getTotalAccountBalance().getValue().doubleValue());
		callData.getBillingAccount().setOnBankDraft(billingAccountInfo.getCurrentIndicators().getValue().isIsOnBankDraft());
		callData.getBillingAccount().setCanEnrollBankDraft((billingAccountInfo.getEligibilityIndicators().getValue().isCanEnrollInBankDraft()));
		callData.getBillingAccount().setCanRequestMoveOut((billingAccountInfo.getEligibilityIndicators().getValue().isCanRequestMoveOut()));
		callData.getBillingAccount().setCanEnrollInBudget((billingAccountInfo.getEligibilityIndicators().getValue().isCanEnrollInBudget()));
		callData.getBillingAccount().setCanEnrollInElectronicBilling(((billingAccountInfo.getEligibilityIndicators().getValue().isCanEnrollInElectronicBilling())));
		callData.getBillingAccount().setCanPayByElectronicCheck((billingAccountInfo.getEligibilityIndicators().getValue().isCanPayByElectronicCheck()));
		callData.getBillingAccount().setMeterInside(billingAccountInfo.getCurrentIndicators().getValue().isIsMeterInside());
		callData.getBillingAccount().setBankRoutingNumber(billingAccountInfo.getPayments().getValue().getBankRoutingNumber().getValue());
		callData.getBillingAccount().setMaxPaymentAmount(billingAccountInfo.getPayments().getValue().getMaxPaymentAmount() == null ? 0d : billingAccountInfo.getPayments().getValue().getMaxPaymentAmount().doubleValue());
		callData.getBillingAccount().setBankAccountNumber(billingAccountInfo.getPayments().getValue().getBankAccountNumber().getValue());

		//Phase 2 changes 01-06-2022
		if(!billingAccountInfo.getPaymentArrangements().isNil()){
		
			List<PaymentArrangmentInfo> paymentArrangmentList = billingAccountInfo.getPaymentArrangements().getValue().getPaymentArrangmentInfo();
			if (!paymentArrangmentList.isEmpty()) {
				PaymentArrangmentInfo paymentArrangmentInfo = paymentArrangmentList.get(0);
				callData.getBillingAccount().setPaymentArrangementAmountDue(paymentArrangmentInfo.getAmountDue() == null ? 0d : paymentArrangmentInfo.getAmountDue());
				
			}else {
				callData.getBillingAccount().setPaymentArrangementAmountDue(0d);
			}
		}
		else {
			callData.getBillingAccount().setPaymentArrangementAmountDue(0d);
		}
	}

	/**
	 * @param callData
	 * @param billingAccountInfo
	 */
	private void setBillingAccountBankAccountType(CallData callData,
			BillingAccountInfo billingAccountInfo) {
		String banckAccountTypeChar = billingAccountInfo.getPayments().getValue().getBankAccountType().getValue();
		if (CHECKING.equalsIgnoreCase(banckAccountTypeChar)) {
			banckAccountTypeChar = BankAccountType.CHECKING.value();
		} else {
			if (SAVING.equalsIgnoreCase(banckAccountTypeChar)) {
				banckAccountTypeChar = BankAccountType.SAVINGS.value();
			} else {
				banckAccountTypeChar = BankAccountType.NOT_SPECIFIED.value();
			}
		}
		callData.getBillingAccount().setBankAccountType(banckAccountTypeChar);
	}

	/**
	 * @param callData
	 * @param billingAccountInfo
	 */
	private void setBillingAccountCustomerPersonalProperties(CallData callData,
			BillingAccountInfo billingAccountInfo) {
		callData.getBillingAccount().setAccountNumber(billingAccountInfo.getAccountNumber().getValue());
		callData.getBillingAccount().setFirstName(billingAccountInfo.getAccountOwner().getValue().getFirstName().getValue());
		callData.getBillingAccount().setLastName(billingAccountInfo.getAccountOwner().getValue().getLastName().getValue());
		callData.getBillingAccount().setRoundUpAmount(billingAccountInfo.getRoundUpAmount().getValue() == null ? 0d : billingAccountInfo.getRoundUpAmount().getValue().doubleValue());
		callData.getBillingAccount().setIsRoundingUp(billingAccountInfo.isIsRoundingUp());
		callData.getBillingAccount().setBudgetAmount(billingAccountInfo.getBudgetAmount().getValue() == null ? 0d : billingAccountInfo.getBudgetAmount().getValue().doubleValue());
		callData.getBillingAccount().setEmailAddress(billingAccountInfo.getEmailAddress().getValue());
		callData.getBillingAccount().setAccountStatus((billingAccountInfo.getAccountStatus().getValue()));
		callData.getBillingAccount().setCanUseWebAccess(billingAccountInfo.isCanUseWebAccess());
		callData.getBillingAccount().setAmountDue(billingAccountInfo.getCurrentBill().getValue().getAmountDue().getValue() == null ? 0d : billingAccountInfo.getCurrentBill().getValue().getAmountDue().getValue().doubleValue());
		callData.getBillingAccount().setAmountPastDue(billingAccountInfo.getCurrentBill().getValue().getAmountPastDue().getValue() == null ? 0d : billingAccountInfo.getCurrentBill().getValue().getAmountPastDue().getValue().doubleValue());
	}
	
	/**
	 * //########  Change for ONEGas 17OK2019  ########  
	 * @param callData
	 * @param billingAccountInfo
	 */
	private void readLatestAllowedDateForPastDuePayment(CallData callData,
			BillingAccountInfo billingAccountInfo) {
		
		XMLGregorianCalendar latestAllowedDateForPastDuePayment = billingAccountInfo.getPayments().getValue().getLatestAllowedDateForPastDuePayment();
		
		if (latestAllowedDateForPastDuePayment != null) {
			SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);
			Date pastDueDate = latestAllowedDateForPastDuePayment.toGregorianCalendar().getTime();
			callData.getBillingAccount().setLatestAllowedDateForPastDuePayment(sdf.format(pastDueDate));
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#getOpenServiceOrders
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean getOpenServiceOrders(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getOpenServiceOrders.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		try {
			List<OpenServiceOrderDetail> openServiceOrdersDetail = getBillingAccountService().getOpenServiceOrders(accountNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			callData.setOpenServiceOrder(openServiceOrdersDetail != null && openServiceOrdersDetail.size() > 0 ? openServiceOrdersDetail.get(0) : null);
			ODLogger.logDebug(callData.getSceSession(), "### OpenServiceOrderDetail " + callData.getOpenServiceOrder());
			return true;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * removeBankAccountInformation(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean removeBankAccountInformation(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting removeBankAccountInformation.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		try {
			boolean removeBankAccountInformation = getBillingAccountService().removeBankAccountInformation(accountNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return removeBankAccountInformation;

		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#existingTimePayment
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean existingTimePayment(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting existingTimePayment.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		
		Double paymentAmmount = Double.valueOf(callData.getField(Field.PAYMENT_AMOUNT));

		ODLogger.logDebug(callData.getSceSession(), ACCOUNT_NUMBER_LOG + accountNumber);
		ODLogger.logDebug(callData.getSceSession(), "paymentAmmount: " + paymentAmmount);

		try {
			String paymentDateAsString = callData.getField(Field.PAYMENT_DATE);
			SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);
			ODLogger.logDebug(callData.getSceSession(), " Payment Date as String: " + paymentDateAsString);
			Date paymentDate = sdf.parse(paymentDateAsString);
			ODLogger.logDebug(callData.getSceSession(), " Payment Date: " + paymentDate);
			
			String confNumber = getBillingAccountService().makeOneTimePaymentWithExistingBankAccount(accountNumber, paymentAmmount, paymentDate);
			ODLogger.logDebug(callData.getSceSession(), "confNumber: " + confNumber);
			callData.getBillingAccount().setConfirmationNumber(confNumber);
			callData.setField(Field.CONFIRMED_PAYMENT, Constants.TRUE);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}catch(ParseException pe){
			ODLogger.logError(callData.getSceSession(), " There was a problem parsing the Date ", pe);
			throw new ServiceException(pe);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#newTimePayment(com
	 * .avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean newTimePayment(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting newTimePayment.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Double paymentAmt = Double.parseDouble(callData.getField(Field.PAYMENT_AMOUNT));
		String checkingNumber = callData.getField(Field.CHECKING_NUMBER_CALLER_INPUT);
		String bankAccType = BankAccountType.CHECKING.value();
		String routingNumber = callData.getField(Field.ROUTING_NUMBER_CALLER_INPUT);
		
		ODLogger.logDebug(callData.getSceSession(), ACCOUNT_NUMBER_LOG + accountNumber);
		ODLogger.logDebug(callData.getSceSession(), "Payment Amount = "+ paymentAmt);
		ODLogger.logDebug(callData.getSceSession(), BANK_NUMBER_LOG + checkingNumber);
		ODLogger.logDebug(callData.getSceSession(), BANK_ACC_TYPE_LOG + bankAccType);
		ODLogger.logDebug(callData.getSceSession(), ROUTING_NUMBER_LOG + routingNumber);
		
		try {
			
			String paymentDateAsString = callData.getField(Field.PAYMENT_DATE);
			SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_FORMAT_YYYYMMDD);
			ODLogger.logDebug(callData.getSceSession(), " Payment Date as String: " + paymentDateAsString);
			Date paymentDate = sdf.parse(paymentDateAsString);
			ODLogger.logDebug(callData.getSceSession(), " Payment Date: " + paymentDate);
			
			String confNumber = getBillingAccountService().makeOneTimePayment(accountNumber, paymentAmt, checkingNumber, bankAccType, routingNumber, paymentDate);
			callData.getBillingAccount().setConfirmationNumber(confNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;
		} catch (BillingAccountClientServiceException billingAccountClientServiceException) {
			throw new ServiceException(billingAccountClientServiceException);
		}catch(ParseException pe){
			ODLogger.logError(callData.getSceSession(), " There was a problem parsing the Date ", pe);
			throw new ServiceException(pe);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * registerBankAccountInformation(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean registerBankAccountInformation(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting registerBankAccountInformation.");
		
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String bankNumber = callData.getField(Field.CHECKING_NUMBER_CALLER_INPUT);
		String bankAccType = BankAccountType.CHECKING.value();
		String routingNumber = callData.getField(Field.ROUTING_NUMBER_CALLER_INPUT);

		ODLogger.logDebug(callData.getSceSession(), ACCOUNT_NUMBER_LOG + accountNumber);
		ODLogger.logDebug(callData.getSceSession(), BANK_NUMBER_LOG + bankNumber);
		ODLogger.logDebug(callData.getSceSession(), BANK_ACC_TYPE_LOG + bankAccType);
		ODLogger.logDebug(callData.getSceSession(), ROUTING_NUMBER_LOG + routingNumber);

		try {
			boolean registerBankAccountInformation = getBillingAccountService().registerBankAccountInformation(accountNumber, bankNumber, bankAccType, routingNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return registerBankAccountInformation;
		} catch (BillingAccountClientServiceException billingAccountClientServiceException) {
			throw new ServiceException(billingAccountClientServiceException);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#submitMemoPayment
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public void submitMemoPayment(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting submitMemoPayment.");
		String payload = "";
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Double paymentAmount = Double.valueOf(callData.getField(Field.PAYMENT_AMOUNT));
		String receiptNumber = callData.getField(Field.RECEIPT_NUM);
		SimpleDateFormat sdformat = new SimpleDateFormat("MMddyyyy");
		sdformat.setLenient(false);
		Date paymentDate;
		try {
			paymentDate = sdformat.parse(callData.getField(Field.PAYMENT_DATE));
		} catch (ParseException e) {
			throw new ServiceException(e);
		}

		try {
			payload = getBillingAccountService().submitMemoPayment(accountNumber, paymentAmount, receiptNumber, paymentDate);
			callData.getBillingAccount().setConfirmationNumber(payload);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#enrollInBankDraft
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean enrollInBankDraft(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting enrollInBankDraft.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String bankNumber = callData.getField(Field.CHECKING_NUMBER_CALLER_INPUT);
		String bankAccType = BankAccountType.CHECKING.value();
		String routingNumber = callData.getField(Field.ROUTING_NUMBER_CALLER_INPUT);
		
		ODLogger.logDebug(callData.getSceSession(), ACCOUNT_NUMBER_LOG + accountNumber);
		ODLogger.logDebug(callData.getSceSession(), BANK_NUMBER_LOG + bankNumber);
		ODLogger.logDebug(callData.getSceSession(), BANK_ACC_TYPE_LOG + bankAccType);
		ODLogger.logDebug(callData.getSceSession(), ROUTING_NUMBER_LOG + routingNumber);

		try {
			boolean enrollInBankDraft = getBillingAccountService().enrollInBankDraft(accountNumber, bankNumber, bankAccType, routingNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return enrollInBankDraft;

		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#cancelBankDraft(
	 * com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean cancelBankDraft(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting cancelBankDraft.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();

		try {
			boolean cancelBankDraft = getBillingAccountService().cancelBankDraft(accountNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return cancelBankDraft;

		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#updateBankDraftInfo
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean updateBankDraftInfo(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting updateBankDraftInfo.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String bankNumber = callData.getField(Field.CHECKING_NUMBER_CALLER_INPUT);
		String bankAccType = BankAccountType.CHECKING.value();
		String routingNumber = callData.getField(Field.ROUTING_NUMBER_CALLER_INPUT);

		ODLogger.logDebug(callData.getSceSession(), ACCOUNT_NUMBER_LOG + accountNumber);
		ODLogger.logDebug(callData.getSceSession(), BANK_NUMBER_LOG + bankNumber);
		ODLogger.logDebug(callData.getSceSession(), BANK_ACC_TYPE_LOG + bankAccType);
		ODLogger.logDebug(callData.getSceSession(), ROUTING_NUMBER_LOG + routingNumber);

		try {
			boolean updateBankDraftInfo = getBillingAccountService().updateBankDraftInfo(accountNumber, bankNumber, bankAccType, routingNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return updateBankDraftInfo;

		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#requestDupilcateBill
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean requestDupilcateBill(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestDupilcateBill.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Date billDate = Calendar.getInstance().getTime();
		try {
			boolean requestDuplicateBill = getBillingAccountService().requestDuplicateBill(accountNumber, billDate);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return requestDuplicateBill;

		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#requestLetterOfCredit
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean requestLetterOfCredit(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestLetterOfCredit.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();

		try {
			boolean requestLetterOfCredit = getBillingAccountService().requestLetterOfCredit(accountNumber);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return requestLetterOfCredit;

		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * setShareTheWarmthStatusEnroll(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean setShareTheWarmthStatusEnroll(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting setShareTheWarmthStatusEnroll.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Double paymentAmt = Double.parseDouble(callData.getField(Field.PAYMENT_AMOUNT));
		String action = ENROLL;
		Date startDate = Calendar.getInstance().getTime();
		Date endDate = null;
		try {
			boolean setShareTheWarmthStatus = getBillingAccountService().setShareTheWarmthStatus(accountNumber, paymentAmt, action, startDate, endDate);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return setShareTheWarmthStatus;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * setShareTheWarmthStatusUpdate(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean setShareTheWarmthStatusUpdate(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting setShareTheWarmthStatusUpdate.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Double paymentAmt = Double.parseDouble(callData.getField(Field.PAYMENT_AMOUNT));
		String action = UPDATE;
		Date startDate = Calendar.getInstance().getTime();
		Date endDate = null;
		try {
			boolean setShareTheWarmthStatus = getBillingAccountService().setShareTheWarmthStatus(accountNumber, paymentAmt, action, startDate, endDate);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return setShareTheWarmthStatus;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * setShareTheWarmthStatusCancel(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean setShareTheWarmthStatusCancel(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting setShareTheWarmthStatusCancel.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		double paymentAmt = 0;
		String action = UNENROLL;
		Date startDate = null;
		Date endDate = Calendar.getInstance().getTime();
		try {
			boolean setShareTheWarmthStatus = getBillingAccountService().setShareTheWarmthStatus(accountNumber, paymentAmt, action, startDate, endDate);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return setShareTheWarmthStatus;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * setElectronicBillingStatus(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean setElectronicBillingStatus(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting setElectronicBillingStatus.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String emailAddress = callData.getBillingAccount().getEmailAddress();
		String action = callData.getField(Field.ACTION);

		try {
			boolean setElectronicBillingStatus = getBillingAccountService().setElectronicBillingStatus(accountNumber, emailAddress, action);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return setElectronicBillingStatus;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#reserveAppointment
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean reserveAppointment(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting reserveAppointment.");
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#callReserveAppointment
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean callReserveAppointment(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting callReserveAppointment.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String appointmentAvailability = callData.getField(Field.APP_DATE);
		String apptWindow = "ALL DAY";
		String eventCode = "505";

		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
		Date apptDate;

		try {
			apptDate = dateFormat.parse(appointmentAvailability);
		} catch (ParseException e) {
			throw new ServiceException("Could not parse the String date into Date format", e);
		}

		try {
			ODLogger.logDebug(callData.getSceSession(), ACCOUNT_NUMBER_LOG + accountNumber);
			ODLogger.logDebug(callData.getSceSession(), "apptDate: " + apptDate);
			ODLogger.logDebug(callData.getSceSession(), "apptWindow: " + apptWindow);
			ODLogger.logDebug(callData.getSceSession(), "eventCode: " + eventCode);
			AppointmentReservationResponse callReserveAppointment = getBillingAccountService().callReserveAppointment(accountNumber, AppointmentType.MOVE_OUT, apptDate, apptWindow, eventCode);
			callData.getBillingAccount().setConfirmationNumber(callReserveAppointment.getConfirmationNumber().getValue());
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException("Error calling callReserveAppointment", e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#requestMoveOutOrder
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean requestMoveOutOrder(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestMoveOutOrder.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String apptDate = callData.getField(Field.APP_DATE);
		String phoneNumber = callData.getField(Field.ANI);
		String confirmationNumber = callData.getBillingAccount().getConfirmationNumber();
		String window = "All Day";
		String firstName = callData.getBillingAccount().getFirstName();
		String lastName = callData.getBillingAccount().getLastName();
		String middleName = callData.getBillingAccount().getMiddleName();

		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
		Date appointmentDate;
		dateFormat.setLenient(false);
		try {
			appointmentDate = dateFormat.parse(apptDate);
		} catch (ParseException e) {
			throw new ServiceException("Could not parse the date in String into Date format", e);
		}

		try {
			MoveOutOrderResponse requestMoveOutOrder = getBillingAccountService().requestMoveOutOrder(accountNumber, appointmentDate, phoneNumber, String.valueOf(confirmationNumber), window, firstName, middleName, lastName);
			callData.getBillingAccount().setAppointmentConfirmationNumber(requestMoveOutOrder.getAppointmentConfirmationNumber().getValue());
			callData.getBillingAccount().setServiceOrderNumber(requestMoveOutOrder.getServiceOrderNumber().getValue());
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;

		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * getAppointmentAvailability(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean getAppointmentAvailability(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getAppointmentAvailability.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String appointment = AppointmentType.MOVE_OUT.value();
		String duration = "AllDay";
		SimpleDateFormat sdformat = new SimpleDateFormat(Constants.DATE_FORMAT);
		sdformat.setLenient(false);
		Date appDate;
		try {
			appDate = sdformat.parse(callData.getField(Field.APP_DATE));
		} catch (ParseException e) {
			throw new ServiceException(e);
		}

		try {
			AppointmentAvailabilityInfo appointmentAvailabilityInfo = getBillingAccountService().getAppointmentAvailability(accountNumber, appointment, appDate, duration);
			List<AppointmentAvailability> appointmentAvailability = appointmentAvailabilityInfo.getAppointmentList().getValue().getAppointmentAvailability();
			callData.setAppointmentAvailabilityList(appointmentAvailability);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
		} catch (BillingAccountClientServiceNotFoundException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * requestServiceOrderChange(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean requestServiceOrderChange(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestServiceOrderChange.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String serviceOrderNumber = callData.getBillingAccount().getServiceOrderNumber();
		String changeType = RESCHEDULE;
		String serviceOrderType = NULL;
		Date requestedDate = null;
		String duration = NULL;
		String appointmentWindow = NULL;
		String confirmationNumber = callData.getBillingAccount().getAppointmentConfirmationNumber();

		try {
			ServiceOrderChangeResponse serOrderCngRes = getBillingAccountService().requestServiceOrderChange(accountNumber, serviceOrderNumber, changeType, serviceOrderType, requestedDate, duration, appointmentWindow, confirmationNumber);

			callData.getBillingAccount().setAccountNumber(serOrderCngRes.getAccountNumber().getValue());
			callData.getBillingAccount().setAppointmentConfirmationNumber(serOrderCngRes.getAppointmentConfirmationNumber().getValue());
			callData.getBillingAccount().setServiceOrderNumber(serOrderCngRes.getServiceOrderNumber().getValue());
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#enterMeterRead(com
	 * .avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean enterMeterRead(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting enterMeterRead.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Integer serviceId = callData.getBillingAccount().getServiceID();

		Integer meterReading = Integer.valueOf(callData.getField(Field.METER_READING));

		boolean forceEntry = false;

		try {
			MeterEntryResponse meterEntryResponse = getBillingAccountService().enterMeterRead(accountNumber, serviceId, meterReading, forceEntry);
			callData.getBillingAccount().setExistingRead(meterEntryResponse.getExistingRead().getValue());
			callData.getBillingAccount().setHighRead(meterEntryResponse.isHighRead());
			callData.getBillingAccount().setLowRead(meterEntryResponse.isLowRead());
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * enrollForVoluntaryFixedPrice(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean enrollForVoluntaryFixedPrice(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting enrollForVoluntaryFixedPrice.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();

		try {
			boolean enrollForVoluntaryFixedPrice = getBillingAccountService().enrollForVoluntaryFixedPrice(accountNumber, 1);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return enrollForVoluntaryFixedPrice;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#getPaymentHistory
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean getPaymentHistory(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getPaymentHistory.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();

		try {
			PaymentHistoryInfo paymentHistoryInfo = getBillingAccountService().getPaymentHistory(accountNumber);
			List<PaymentInfo> lPaymentInfos = paymentHistoryInfo.getPayments().getValue().getPaymentInfo();

			callData.setPaymentInfoList(lPaymentInfos);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#submitEAP(com.avaya
	 * .ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean submitEAP(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting submitEAP.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String eaCode = callData.getField(Field.EA_CODE);
		Double paymentAmt = Double.parseDouble(callData.getField(Field.PAYMENT_AMOUNT));

		try {
			boolean submitEnergyAssistancePromise = getBillingAccountService().submitEnergyAssistancePromise(accountNumber, eaCode, paymentAmt);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return submitEnergyAssistancePromise;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#agencyLookup(java
	 * .lang.String)
	 */
	@Override
	public String agencyLookup(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting agencyLookup.");

		String fileName = "agencyCode.properties";
		String key = callData.getField(Field.AGENCY_CODE);

		return loadProperty(callData, fileName, key);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#agencyLookup(java
	 * .lang.String)
	 */
	@Override
	public boolean updatePropertiesForFalse(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting updatePropertiesForFalse.");

		String fileName = "messageActivation.properties";
		String key = callData.getField(Field.AUDIO_PHRASE);
		return setProperty(fileName, key, "false");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#agencyLookup(java
	 * .lang.String)
	 */
	@Override
	public boolean updatePropertiesForTrue(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting updatePropertiesForTrue.");

		String fileName = "messageActivation.properties";
		String key = callData.getField(Field.AUDIO_PHRASE);
		return setProperty(fileName, key, "true");
	}

	/**
	 * @param fileName
	 * @param key
	 * @throws ServiceException
	 */
	private String loadProperty(CallData callData, String fileName, String key) throws ServiceException {
		Properties propAgency = new Properties();
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(fileName);
		try {
			propAgency.load(in);

			if (propAgency.containsKey(key)) {
				return propAgency.getProperty(key);
			} else {
				ODLogger.logDebug(callData.getSceSession(), "Property " + key + " not found in " + fileName);
				return null;
			}
		} catch (IOException e) {
			throw new ServiceException(e);
		}finally{
			if(in!=null){
				try {
					in.close();
				} catch (IOException e) {
					throw new ServiceException(e);
				}
			}
		}
	}

	/**
	 * @param fileName
	 * @param key
	 * @throws ServiceException
	 */
	private boolean setProperty(String fileName, String key, String value) throws ServiceException {
		Properties propertiesFile = new Properties();
		try {
			URL resource = this.getClass().getClassLoader().getResource(fileName);
			if(resource!=null){
				try (FileInputStream in = new FileInputStream(resource.getPath())) {
					propertiesFile.load(in);
					in.close();
				}
				if (propertiesFile.containsKey(key)) {
					propertiesFile.setProperty(key, value);
				} else {
					throw new ServiceException("Property " + key + " not found in " + fileName);
				}
			}
			resource = this.getClass().getClassLoader().getResource(fileName);
			if(resource!=null){
				try (FileOutputStream out = new FileOutputStream(resource.getPath())) {
					propertiesFile.store(out, null);
					out.close();
				}
			}
		} catch (FileNotFoundException e1) {
			throw new ServiceException("Could not open the file " + fileName, e1);
		} catch (IOException e2) {
			throw new ServiceException("Could not read or write " + fileName, e2);
		}

		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#validateAccount(
	 * com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean validateAccount(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting validateAccount.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String last4SSN = callData.getField(Field.LAST4SSN);

		try {
			boolean validateAccount = getBillingAccountService().validateAccount(accountNumber, last4SSN);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return validateAccount;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * requestPaymentArrangement(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public void requestPaymentArrangementFalse(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestPaymentArrangementFalse.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		try {
			PaymentArrangementDetail paymentArrangementDetail = getBillingAccountService().requestPaymentArrangement(accountNumber, false, Double.valueOf(0), 0, Double.valueOf(0));
			callData.getBillingAccount().setInstallmentAmount(paymentArrangementDetail.getInstallmentAmount().doubleValue());
			callData.getBillingAccount().setInstallCount(paymentArrangementDetail.getInstallments());
			callData.getBillingAccount().setTotalAmountDue(paymentArrangementDetail.getTotalAmountDue().doubleValue());
			// update for phase2 change_control 05-04-2022
			//callData.getBillingAccount().setDueDate(paymentArrangementDetail.getInstallmentDueDate().toString());
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * requestPaymentArrangement(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public void requestPaymentArrangementFalseWithDownPaymentAmount(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestPaymentArrangementFalseWithDownPaymentAmount.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		double downPaymentAmount = callData.getBillingAccount().getPayArrangementDownPaymentAmount().doubleValue();

		try {
			PaymentArrangementDetail paymentArrangementDetail = getBillingAccountService().requestPaymentArrangement(accountNumber, false, Double.valueOf(0), 0, downPaymentAmount);
			callData.getBillingAccount().setInstallmentAmount(paymentArrangementDetail.getInstallmentAmount().doubleValue());
			callData.getBillingAccount().setInstallCount(paymentArrangementDetail.getInstallments());
			callData.getBillingAccount().setTotalAmountDue(paymentArrangementDetail.getTotalAmountDue().doubleValue());
			// update for phase2 change_control 05-04-2022
			//callData.getBillingAccount().setDueDate(paymentArrangementDetail.getInstallmentDueDate().toString());
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * requestPaymentArrangement(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public void requestPaymentArrangementFalseWithDownPaymentAmountAndInstallments(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestPaymentArrangementFalseWithDownPaymentAmount.");

		String accountNumber = callData.getBillingAccount().getAccountNumber();
		double downpayment = Double.valueOf(callData.getField(Field.DOWN_PAYMENT));
		int numberOfPayments = Integer.valueOf(callData.getField(Field.INSTALLMENTS));

		try {
			PaymentArrangementDetail paymentArrangementDetail = getBillingAccountService().requestPaymentArrangement(accountNumber, false, Double.valueOf(0), numberOfPayments, downpayment);
			callData.getBillingAccount().setInstallmentAmount(paymentArrangementDetail.getInstallmentAmount().doubleValue());
			callData.getBillingAccount().setInstallCount(paymentArrangementDetail.getInstallments());
			callData.getBillingAccount().setTotalAmountDue(paymentArrangementDetail.getTotalAmountDue().doubleValue());
			// update for phase2 change_control 05-04-2022
			//callData.getBillingAccount().setDueDate(paymentArrangementDetail.getInstallmentDueDate().toString());
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * lookupBillingAccountPhoneNumber(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean lookupBillingAccountPhoneNumber(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting lookupBillingAccountPhoneNumber.");
		String phoneNumber = callData.getField(Field.PHONE_NUMBER);
		String ldcProvider = callData.getField(Field.LDCPROVIDER);

		try {
			List<AccountLookupResult> billingAccountList = getBillingAccountService().lookupBillingAcount(phoneNumber, ldcProvider);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			if (billingAccountList.size() != 0) {
				callData.setAccountLookupList(billingAccountList);
				return true;
			} else {
				return false;
			}
		} catch (BillingAccountClientServiceNotFoundException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			callData.setField(Field.STATUSCODE, String.valueOf(e.getStatusCode()));
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			return false;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * requestPaymentArrangementTrue(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public void requestPaymentArrangementTrue(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting requestPaymentArrangementTrue.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String downPayment = callData.getField(Field.DOWN_PAYMENT);
		Integer installCount = callData.getBillingAccount().getInstallCount() != null ? callData.getBillingAccount().getInstallCount() : 0;
		Double installmentAmount = callData.getBillingAccount().getInstallmentAmount() != null ? callData.getBillingAccount().getInstallmentAmount() : 0D;
		ODLogger.logDebug(callData.getSceSession(), "### Amount Due = " + installmentAmount);

		try {
			PaymentArrangementDetail paymentArrangementDetail = getBillingAccountService().requestPaymentArrangement(accountNumber, true, installmentAmount, installCount, Double.valueOf(downPayment));
			double installmentAmountResponse = paymentArrangementDetail.getInstallmentAmount().doubleValue();
			Integer installmentsWSResponse = paymentArrangementDetail.getInstallments();
			double amountDueDateResponse = paymentArrangementDetail.getTotalAmountDue().doubleValue();
			String installmentDueDateResponse = paymentArrangementDetail.getInstallmentDueDate().toString();

			ODLogger.logDebug(callData.getSceSession(), "###Request Payment Arrangement Response ####");
			ODLogger.logDebug(callData.getSceSession(), "### installmentAmount = " + installmentAmountResponse);
			ODLogger.logDebug(callData.getSceSession(), "### installments = " + installmentsWSResponse);
			ODLogger.logDebug(callData.getSceSession(), "### amountDueDate = " + amountDueDateResponse);
			ODLogger.logDebug(callData.getSceSession(), "### installmentDueDate = " + installmentDueDateResponse);

			callData.getBillingAccount().setInstallmentAmount(installmentAmountResponse);
			callData.getBillingAccount().setInstallCount(installmentsWSResponse);
			callData.getBillingAccount().setTotalAmountDue(amountDueDateResponse);
			// update for phase2 change_control 05-04-2022
			//callData.getBillingAccount().setDueDate(installmentDueDateResponse);

			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	@Override
	public boolean enrollForAveragePaymentPlan(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting enrollForAveragePaymentPlan.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Integer serviceID = callData.getBillingAccount().getServiceID();
		ODLogger.logDebug(callData.getSceSession(), "Account Number = " + accountNumber);
		ODLogger.logDebug(callData.getSceSession(), "Service ID = " + serviceID);
		try {
			boolean enrollForAveragePaymentPlan = getBillingAccountService().enrollForAveragePaymentPlan(accountNumber, serviceID);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return enrollForAveragePaymentPlan;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	@Override
	public boolean cancelServiceOrder(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting cancelServiceOrder.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String serviceOrderNumber = callData.getBillingAccount().getServiceOrderNumber();
		ODLogger.logDebug(callData.getSceSession(), "Account Number = " + accountNumber);
		ODLogger.logDebug(callData.getSceSession(), "Service Order Number = " + serviceOrderNumber);
		try {
			boolean cancelServiceOrder = getBillingAccountService().cancelServiceOrder(accountNumber, serviceOrderNumber, "", "");
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return cancelServiceOrder;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	@Override
	public boolean getAveragePaymentPlanAmount(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getAveragePaymentPlanAmount.");
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		Integer serviceID = callData.getBillingAccount().getServiceID();

		try {
			Double averagePaymentAmount = getBillingAccountService().getAveragePaymentPlanAmount(accountNumber, serviceID);
			ODLogger.logDebug(callData.getSceSession(), "### Average Pyament Amount = " + averagePaymentAmount);
			callData.getBillingAccount().setAveragePaymentAmount(averagePaymentAmount);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			return true;
		} catch (BillingAccountClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * isAccountStatusOKAfterGasAppliance
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean isAccountStatusOKAfterGasAppliance(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isAccountStatusOKAfterGasAppliance.");

		String accountStatus = callData.getBillingAccount().getAccountStatus();
		boolean isMeterInside = callData.getBillingAccount().isMeterInside();

		ODLogger.logDebug(callData.getSceSession(), "accountStatus: " + accountStatus);
		ODLogger.logDebug(callData.getSceSession(), "isMeterInside: " + isMeterInside);

		return ((Constants.ACTIVE.equalsIgnoreCase(accountStatus)) && !isMeterInside);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * isFirtDateGreaterThan60DaysThanTheSecondDate(java.util.Date,
	 * java.util.Date)
	 */
	@Override
	public boolean isFirtDate60DaysGreaterThanSecondDate(Date firstDate, Date secondDate) {
		return ((firstDate.getTime()) > (secondDate.getTime() + MILLIS_60_DAYS));
	}

	@Override
	public boolean getLocationsByZipCode(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting getLocationsByZipCode.");

		String zipCode = callData.getField(Field.ZIP_CODE);

		try {
			List<LocationInfo> locationsByZipCode = getLocationService().getLocationsByZipCode(zipCode);
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, STATUS_CODE_OK);
			if (locationsByZipCode.size() != 0) {
				callData.setLocationsByZipCodeList(locationsByZipCode);
				return true;
			} else {
				return false;
			}
		} catch (LocationClientServiceException e) {
			String activityName = callData.getField(Field.LAST_STATE);
			ODLogger.reportProgress(callData.getSceSession(), activityName, EMPTY_FIELD, STATUS, String.valueOf(e.getStatusCode()));
			throw new ServiceException(e);
		}
	}

	/**
	 * @return the locationService
	 */
	public ILocationService getLocationService() {
		return locationService;
	}

	/**
	 * @param locationService
	 *            the locationService to set
	 */
	public void setLocationService(ILocationService locationService) {
		this.locationService = locationService;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#accountsDisambiguation
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public boolean accountsDisambiguation(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting accountsDisambiguation.");
		ODLogger.logDebug(callData.getSceSession(), "### Getting accountsDisambiguation.");
		String inputHouseNumb = callData.getField(Field.HOUSE_NUM);
		List<AccountLookupResult> accountLookupList = callData.getAccountLookupList();
		boolean onlyOneMatch = false;
		String accountNumber = "";
		String accountStatus = "";
		String firstName = "";
		String lastName = "";
		String serviceAddress = "";

		for (AccountLookupResult accountLookupResult : accountLookupList) {
			String address = accountLookupResult.getServiceAddress().getValue();
			String[] addressArray = address.split(" ");
			String houseNumber = addressArray[0];

			// account found
			if (houseNumber.equalsIgnoreCase(inputHouseNumb)) {
				accountNumber = accountLookupResult.getAccountNumber().getValue();
				accountStatus = accountLookupResult.getAccountStatus().getValue();
				firstName = accountLookupResult.getFirstName().getValue();
				lastName = accountLookupResult.getLastName().getValue();
				serviceAddress = address;
				onlyOneMatch = true;
			}
		}
		if (onlyOneMatch) {
			callData.getBillingAccount().setAccountNumber(accountNumber);
			callData.getBillingAccount().setAccountStatus(accountStatus);
			callData.getBillingAccount().setFirstName(firstName);
			callData.getBillingAccount().setLastName(lastName);
			callData.getBillingAccount().setAddress(serviceAddress);
			return true;
		} else {
			throw new ServiceException("Got more than one account matched!!");
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#isAWeekendDay(com
	 * .avaya.ept.onegas.bl.model.CallData, java.util.Date)
	 */
	@Override
	public boolean isAWeekendDay(CallData callData, Date appDate) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isAWeekendDay.");
		DateTime now = new DateTime(appDate);
		int dayOfWeek = now.getDayOfWeek();

		if (dayOfWeek == DateTimeConstants.SATURDAY || dayOfWeek == DateTimeConstants.SUNDAY) {
			ODLogger.logDebug(callData.getSceSession(), "is a Weekend Day");
			return true;
		} else {
			ODLogger.logDebug(callData.getSceSession(), "is NOT a Weekend Day");
			return false;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#
	 * getCurrencyStringFromInput(com.avaya.ept.onegas.bl.model.CallData,
	 * java.lang.String)
	 */
	@Override
	public String getCurrencyStringFromInput(CallData callData, String stringToConvert) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting CurrencyStringFromInput.");
		if (stringToConvert == null || stringToConvert.isEmpty()) {
			ODLogger.logDebug(callData.getSceSession(), "### String to convert is either empty or null ###");
			return "";
		}
		int stringLength = stringToConvert.length();
		ODLogger.logDebug(callData.getSceSession(), "### String to convert length = " + stringLength);
		if (stringLength == 1) {
			return "0.0" + stringToConvert;
		} else {
			if (stringLength == 2) {
				return "0." + stringToConvert;
			} else {
				String decimalPortion = stringToConvert.substring(stringLength - 2, stringLength);
				String integerPortion = stringToConvert.substring(0, stringLength - 2);
				ODLogger.logDebug(callData.getSceSession(), "### String converted = " + integerPortion + "." + decimalPortion);
				return integerPortion + "." + decimalPortion;
			}
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#isOfficeOpenNCO(
	 * com.avaya.ept.onegas.bl.model.CallData, java.util.Date)
	 */
	private boolean isHolidayVendor(CallData callData, Date today) throws ServiceException {
		//Updated as per Phase 2D sprint 2 requirement 
		String vendor=callData.getField(Field.TRANSFER_LOCATION);
		String cavHolidays=null;
		
		if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend1Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend1);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend2Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend2);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend3Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend3);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend4Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend4);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend5Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend5);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend6Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend6);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend7Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend7);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend8Dec))) {
			cavHolidays = callData.getCAV(CAV.holidayVend8);}
		else {
			return false;
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
		DateTime now = new DateTime();
		DateTimeFormatter formatter = DateTimeFormat.forPattern(Constants.DATE_FORMAT + " " + Constants.TIME_FORMAT);
		
		if (!StringUtils.isBlank(cavHolidays)) {
			String todayStr = dateFormat.format(today);
			ODLogger.logDebug(callData.getSceSession(), "### Getting time to compare."+now.toString(formatter));
			try {
				String[] holidays = cavHolidays.split(Pattern.quote(COMMA));
				for (String holiday : holidays) {
					String[] dateTime=holiday.split(";");
					
					if (todayStr.equals(dateTime[0])) {
						String[] time=dateTime[1].split(Constants.URL_SEPARATOR);
						String startTime = time[0];
						String endTime = time[1];
						
						return belongsToInterval(startTime, endTime, todayStr, now, formatter);
						
						
					}
				}
				return false;
			} catch (PatternSyntaxException e) {
				throw new ServiceException("error parsing today holiday", e);
			}
		} else {
			return false;
		}
	}

	@Override
	public boolean isOfficeOpenNCO(CallData callData, Date today) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isOfficeOpenNCO.");

		if (isHolidayVendor(callData, today)) { 
			return false;
		} else {

			return checkBusinessHoursNCO(callData, today);
		}
	}

	private boolean checkBusinessHoursNCO(CallData callData, Date today) throws ServiceException {
	
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
		String vendor = callData.getField(Field.TRANSFER_LOCATION);
		String workingHours = null;
		DateTime now = new DateTime();
		int dayOfWeek = now.getDayOfWeek();
		if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend1Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND1);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND1);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND1);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND1);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND1);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND1);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND1);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend2Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND2);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND2);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND2);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND2);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND2);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND2);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND2);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend3Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND3);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND3);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND3);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND3);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND3);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND3);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND3);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend4Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND4);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND4);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND4);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND4);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND4);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND4);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND4);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend5Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND5);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND5);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND5);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND5);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND5);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND5);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND5);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend6Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND6);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND6);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND6);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND6);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND6);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND6);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND6);}
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend7Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND7);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND7);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND7);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND7);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND7);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND7);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND7);}	
		else if(vendor.equalsIgnoreCase(callData.getCAV(CAV.Vend8Dec))) {
			if (dayOfWeek == DateTimeConstants.MONDAY)
				workingHours = callData.getCAV(CAV.MondayHoursVEND8);
			else if (dayOfWeek == DateTimeConstants.TUESDAY)
				workingHours = callData.getCAV(CAV.TuesdayHoursVEND8);
			else if (dayOfWeek == DateTimeConstants.WEDNESDAY)
				workingHours = callData.getCAV(CAV.WednesdayHoursVEND8);
			else if (dayOfWeek == DateTimeConstants.THURSDAY)
				workingHours = callData.getCAV(CAV.ThursdayHoursVEND8);
			else if (dayOfWeek == DateTimeConstants.FRIDAY)
				workingHours = callData.getCAV(CAV.FridayHoursVEND8);
			else if (dayOfWeek == DateTimeConstants.SATURDAY)
				workingHours = callData.getCAV(CAV.SaturdayHoursVEND8);
			else if (dayOfWeek == DateTimeConstants.SUNDAY)
				workingHours = callData.getCAV(CAV.SundayHoursVEND8);}	
		else {
			return false;
		}

		String todayStr = dateFormat.format(today);
		ODLogger.logDebug(callData.getSceSession(), "day of week: " + dayOfWeek);
		ODLogger.logDebug(callData.getSceSession(), "working hours: " + workingHours);
		ODLogger.logDebug(callData.getSceSession(), "today: " + todayStr);
		DateTimeFormatter formatter = DateTimeFormat.forPattern(Constants.DATE_FORMAT+ " " + Constants.TIME_FORMAT);

			if (!StringUtils.isBlank(workingHours)) {
				String[] hours=workingHours.split(Constants.URL_SEPARATOR);
				String startHours = hours[0];
				String stopHours = hours[1];
				return belongsToInterval(startHours, stopHours, todayStr, now, formatter);

			} else {
				return false;
			}
	}

	@Override
	public void createContextStoreEntry(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Entering createContextStoreEntry ");
		
		// Getting all the data that will be passed on the request body
		String aniMatch = callData.getField(Field.ANIMATCH);
		String isValidated = callData.getField(Field.SSN_VALIDATED);
		String language = callData.getField(Field.LANGUAGE);
		String lastState = callData.getField(Field.LAST_STATE);
		String mmOption = callData.getField(Field.MAIN_MENU_OPTION);
		String otherOpt = callData.getField(Field.OTHER_MENU_OPTION);
		String billingOpt = callData.getField(Field.BILLING_MENU_OPTION);
		String payOpt = callData.getField(Field.PAYMENT_MENU_OPTION);
		String accInfoOpt = callData.getField(Field.ACCINFO_MENU_OPTION);
		String hidenOpt = callData.getField(Field.HIDEN_MENU_OPTION);
		String serviceOpt = callData.getField(Field.SERVICE_MENU_OPTION);
		String ucid = callData.getField(Field.UCID);
		String groupId = callData.getField(Field.GROUP_ID);
		String callTime = callData.getField(Field.CALLTIME);
		String accountNumber = callData.getBillingAccount().getAccountNumber();
		String lastName = callData.getBillingAccount().getLastName();
		String firstName = callData.getBillingAccount().getFirstName();

		Map<String, String> jsonMap = getRequestBodyMap(aniMatch, isValidated, language, lastState, mmOption, otherOpt, billingOpt, payOpt,	accInfoOpt, hidenOpt, serviceOpt, ucid, callTime, accountNumber, lastName, firstName);

		Map<String, String> params = getRequestParametersMap(callData);
		
		// 'groupId' is a property, so it needs to be at the same level as 'data'
		String contextID = getContextStoreService().createContextStoreWithParamsAndGroupId(jsonMap, params, true, groupId);
		callData.setField(Field.CONTEXT_ID, contextID);
		ODLogger.reportProgress(callData.getSceSession(), "90140_dbContextStore", EMPTY_FIELD, "CONTEXT_ID", contextID);
	}

	/**
	 * It builds up a Map<String, String> with all the request parameters needed
	 * 
	 * @param callData {@link CallData} containing all the CAVs and necessary data
	 * @return a Map<String, String> with all the request parameters needed
	 */
	private Map<String, String> getRequestParametersMap(CallData callData) {
		Map<String, String> params = new HashMap<String, String>();

		//  Getting all the data that will be passed as parameter in the request
		String leaseTime = callData.getCAV(CAV.CS_LeaseTime);
		String rid = callData.getCAV(CAV.CS_RID);
		
		params.put("touchpoint", "1120_db_ContextStore");
		params.put(ContextStoreKeys.LEASE_TIME.toString(), leaseTime);
		params.put(ContextStoreKeys.RID.toString(), rid);
		
		//#######################################################################################################################################################################################################################################################
		// With the Breeze / Context Store upgrade, the Context ID generated when writing to Context Store is now defaulting to the long format. The previous version defaulted to the short format. For transfers, the Context ID is inserted into the UUI. 
		// The long format is pushing the UUI string beyond the 96 byte limit. 
		// To correct the problem the application needs to be updated to include a "shortid" parameter. When writing the Context Store data, shortid="true", will ensure the short format is used and eliminate the UUI problem. 
		//#######################################################################################################################################################################################################################################################
		params.put(ContextStoreKeys.SHORT_ID.toString(), "true");
		return params;
	}

	/**
	 * It builds up a Map<String, String> with all the request body data needed
	 * 
	 * @param aniMatch
	 * @param isValidated
	 * @param language
	 * @param lastState
	 * @param mmOption
	 * @param otherOpt
	 * @param billingOpt
	 * @param payOpt
	 * @param accInfoOpt
	 * @param hidenOpt
	 * @param serviceOpt
	 * @param ucid
	 * @param callTime
	 * @param accountNumber
	 * @param lastName
	 * @param firstName
	 * @return a Map<String, String> with all the request body data needed 
	 */
	private Map<String, String> getRequestBodyMap(String aniMatch, String isValidated, String language, String lastState, String mmOption, String otherOpt, String billingOpt, String payOpt, String accInfoOpt, String hidenOpt, String serviceOpt, String ucid, String callTime, String accountNumber, String lastName,String firstName) {
		Map<String, String> jsonMap = new HashMap<String, String>();

		// Adding all the data to the JSON body map
		jsonMap.put(ContextStoreKeys.ANI_MATCH.toString(), aniMatch);
		jsonMap.put(ContextStoreKeys.IS_VALIDATED.toString(), isValidated);
		jsonMap.put(ContextStoreKeys.LANGUAGE.toString(), language);
		jsonMap.put(ContextStoreKeys.ACCT_NUMBER.toString(), accountNumber);
		jsonMap.put(ContextStoreKeys.LAST_NAME.toString(), lastName);
		jsonMap.put(ContextStoreKeys.FIRST_NAME.toString(), firstName);
		jsonMap.put(ContextStoreKeys.LASTS_STATE.toString(), lastState);
		jsonMap.put(ContextStoreKeys.MAIN_MENU.toString(), mmOption);
		jsonMap.put(ContextStoreKeys.OTHER_MENU.toString(), otherOpt);
		jsonMap.put(ContextStoreKeys.BILLING_MENU.toString(), billingOpt);
		jsonMap.put(ContextStoreKeys.PAYMENT_MENU.toString(), payOpt);
		jsonMap.put(ContextStoreKeys.ACCT_INFO_MENU.toString(), accInfoOpt);
		jsonMap.put(ContextStoreKeys.HIDDEN_MENU.toString(), hidenOpt);
		jsonMap.put(ContextStoreKeys.SERVICE_MENU.toString(), serviceOpt);
		jsonMap.put(ContextStoreKeys.CALL_TIME.toString(), callTime);
		jsonMap.put("1120_db_ContextStore_UCID", ucid);
		return jsonMap;
	}
	

	public ContextStoreService getContextStoreService() {
		return contextStoreService;
	}

	public void setContextStoreService(ContextStoreService contextStoreService) {
		this.contextStoreService = contextStoreService;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.bl.service.IONEGASCommonService#lookupAudioPhrase
	 * (com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public String lookupAudioPhrase(CallData callData) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting lookupAudioPhrase.");
		String audioPhrase = callData.getField(Field.AUDIO_PHRASE);
		return loadProperty(callData, "messageActivation.properties", audioPhrase);
	}

	/* (non-Javadoc)
	 * @see com.avaya.ept.onegas.bl.service.IONEGASCommonService#checkAmountStatus(com.avaya.ept.onegas.bl.model.CallData)
	 */
	@Override
	public String checkAmountStatus(CallData callData){
		BillingAccount billingAccount =callData.getBillingAccount();
		Double totalAmountDue = billingAccount.getTotalAmountDue();
		Double amountDue = billingAccount.getAmountDue();
		Double amountPastDue = billingAccount.getAmountPastDue();
		Double totalAccountBalance = billingAccount.getTotalAccountBalance();
		
		ODLogger.logDebug(callData.getSceSession(), "### totalAmountDue" +totalAmountDue);
		ODLogger.logDebug(callData.getSceSession(), "### amountDue" +amountDue);
		ODLogger.logDebug(callData.getSceSession(), "### amountPastDue" +amountPastDue);
		ODLogger.logDebug(callData.getSceSession(), "### totalAccountBalance" +totalAccountBalance);
		
		if ((Double.compare(totalAmountDue,0d)>0)&&(Double.compare(amountDue,0d)>0)&&(Double.compare(amountPastDue,0d)>0)){
			return "past_due";
		}else if (!(Double.compare(totalAccountBalance, 0d)>0)) {
			return "no_payment_due";
		}else{
			return "current_due";
		}
	}
	
	@Override
	public boolean isFirstDateBetweenSecondAndThirdDate(CallData callData, Date firstDate, Date minDate, Date maxDate) {
		ODLogger.logDebug(callData.getSceSession(), "### Entering isFirstDateBetweenSecondAndThirdDate.");
		
		ODLogger.logDebug(callData.getSceSession(), " firstDate = " + firstDate);
		ODLogger.logDebug(callData.getSceSession(), " minDate = " + minDate);
		ODLogger.logDebug(callData.getSceSession(), " maxDate = " + maxDate);
		
		if(null != firstDate && null != minDate && null != maxDate){
			
			long firstDateTime = firstDate.getTime();
			long minDateTime = minDate.getTime();
			long maxDateTime = maxDate.getTime();
			
			ODLogger.logDebug(callData.getSceSession(), " firstDate in Milis= " + firstDateTime);
			ODLogger.logDebug(callData.getSceSession(), " minDate in Milis= " + minDateTime);
			ODLogger.logDebug(callData.getSceSession(), " maxDate in Milis= " + maxDateTime);	
			
			return firstDateTime >= minDateTime && firstDateTime <= maxDateTime;			
			
		}else{
			
			return false;
		}
		
	}
	
	@Override
	public boolean isANIOk(CallData callData) {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isANIOk.");
		String phoneNumber = callData.getField(Field.ANI);
		Boolean isNumeric = phoneNumber.matches("[+]?(0|[1-9]\\d*)");
		Boolean isTollFree= phoneNumber.matches("^(\\+?1)?(8(00|33|44|55|66|77|88)[0-9]\\d{6})$");
		Boolean isAuthenticated = Boolean.valueOf(callData.getField(Field.ACCOUNT_AUTHORIZED));
		String transferLocation = callData.getField(Field.TRANSFER_LOCATION);
		if(phoneNumber.length()==11 && phoneNumber.charAt(0)=='1') {
			phoneNumber=phoneNumber.substring(1, 11);
			callData.setField(Field.ANI, phoneNumber);
			}
		ODLogger.logDebug(callData.getSceSession(), "PhoneNumber :"+phoneNumber+" isNumeric: "+isNumeric+" isTollFree: "+ isTollFree+ " isAuthenticated: "+isAuthenticated+ " transferLocation: "+transferLocation);
		return isNumeric && !isTollFree && !isAuthenticated && (transferLocation.equalsIgnoreCase("OGS") || StringUtils.isBlank(transferLocation) );
	}
	
	
	@Override
	public boolean isMaintainaceDay(CallData callData, Date today) throws ServiceException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
		String maintainanceDaysHours = callData.getCAV(CAV.maintenance_Days);
		
		
		DateTime now = new DateTime();

		
		DateTimeFormatter formatter = DateTimeFormat.forPattern(Constants.DATE_FORMAT + " " + Constants.TIME_FORMAT);
		if (!StringUtils.isBlank(maintainanceDaysHours)) {
			String todayStr = dateFormat.format(today);
			ODLogger.logDebug(callData.getSceSession(), "### Getting time to compare."+now.toString(formatter));
			try {
				String[] maintainanceDays = maintainanceDaysHours.split(Pattern.quote(COMMA));
				for (String maintainanceDay : maintainanceDays) {
					String[] dateTime=maintainanceDay.split(";");
					
					if (isDateTimeFormat(maintainanceDay) && todayStr.equals(dateTime[0])) {
						String[] time=dateTime[1].split(Constants.URL_SEPARATOR);
						String startTime = time[0];
						String endTime = time[1];
							
						return belongsToInterval(startTime, endTime, todayStr, now, formatter);
						
					}
				}
				return false;
			} catch (PatternSyntaxException e) {
				throw new ServiceException("error parsing Maintainance Days", e);
			}
		} else {
		
			return false;
			
		}
		
	}
	

	@Override
	public boolean isAHolidayDateVendor(CallData callData, Date aDate) throws ServiceException {
		ODLogger.logDebug(callData.getSceSession(), "### Getting isAHolidayDateVendor.");
		return isHolidayVendor(callData, aDate);
	}
	
	private boolean isDateTimeFormat(String dateTime){
		if(dateTime.length()==18) {
			return true;
		}
		return false;
	}
	
	
	@Override
	public String fetchLanguageForVdn(CallData callData, String vdnNumber) {
	    ODLogger.logDebug(callData.getSceSession(), "### Getting Language for I3 DNIS: " + vdnNumber);

	    // Use Singleton Instance of VdnLanguage
	    VdnLanguage vdnLanguage = VdnLanguage.getInstance();
	    String language = vdnLanguage.getLanguageForVdn( callData,vdnNumber);

	    if (language == null || language.isEmpty()) {
	        ODLogger.logError(callData.getSceSession(), "### No Language Found for I3 DNIS: " + vdnNumber);
	    } else {
	        ODLogger.logDebug(callData.getSceSession(), "### Language Found: " + language);
	    }

	    return language;
	}

	@Override
	public String fetchVDNForDID(CallData callData, String did) {
	    ODLogger.logDebug(callData.getSceSession(), "### Getting VDN for I3 DID: " + did);

	    // Use Singleton Instance of VdnLanguage
	    String transferVdn = TransferVdnByDIDLookup.getInstance().getTransferVdnByDid(callData, did);

	    if (transferVdn == null || transferVdn.isEmpty()) {
	        ODLogger.logError(callData.getSceSession(), "### No VDN Found for I3 DID: " + did);
	    } else {
	        ODLogger.logDebug(callData.getSceSession(), "### VDN Found: " + transferVdn);
	    }

	    return transferVdn;
	}
	
	@Override
	public void setI3Urls(CallData callData) {
	    ODLogger.logDebug(callData.getSceSession(), "### START Setting I3 Urls.");
	    
	    Properties properties = new Properties();
	    try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
	        properties.load(input);
	    } catch (IOException e) {
	        ODLogger.logError(callData.getSceSession(), "### ERROR Loading I3 Urls: " + e.getMessage());
	        return;  // Exit method if properties file fails to load
	    }

	    // Fetch getDid values
	    String getdidEndpoint = properties.getProperty("i3.getdid.ws.endpoint", "N/A");
	    String getdidclientId = properties.getProperty("i3.getdid.ws.clientId", "N/A");
	    String getdidapiKey = properties.getProperty("i3.getdid.ws.apiKey", "N/A");
	    String getdidCONNECTION_TIMEOUT = properties.getProperty("i3.getdid.ws.CONNECTION_TIMEOUT", "N/A");
	    String getdidREAD_TIMEOUT = properties.getProperty("i3.getdid.ws.READ_TIMEOUT", "N/A");

	    // Fetch getCallData values
	    String getCallDataEndpoint = properties.getProperty("i3.getCallData.ws.endpoint", "N/A");
	    String getCallDataclientId = properties.getProperty("i3.getCallData.ws.clientId", "N/A");
	    String getCallDataapiKey = properties.getProperty("i3.getCallData.ws.apiKey", "N/A");
	    String getCallDataCONNECTION_TIMEOUT = properties.getProperty("i3.getCallData.ws.CONNECTION_TIMEOUT", "N/A");
	    String getCallDataREAD_TIMEOUT = properties.getProperty("i3.getCallData.ws.READ_TIMEOUT", "N/A");

	    // Consolidated Log Statement
	    
	    ODLogger.logDebug(callData.getSceSession(), "### GetDid Config: " +
	    	    "Endpoint: " + getdidEndpoint + 
	    	    ", Connection Timeout: " + getdidCONNECTION_TIMEOUT + 
	    	    ", Read Timeout: " + getdidREAD_TIMEOUT);

	    ODLogger.logDebug(callData.getSceSession(), "### GetCallData Config: " +
	            "Endpoint: " + getCallDataEndpoint + 
	            ", Connection Timeout: " + getCallDataCONNECTION_TIMEOUT + 
	            ", Read Timeout: " + getCallDataREAD_TIMEOUT);

	    // Set values in CallData
	    callData.setField(Field.GDURL, getdidEndpoint);
	    callData.setField(Field.GDCID, getdidclientId);
	    callData.setField(Field.GDAPI, getdidapiKey);
	    callData.setField(Field.GDCT, getdidCONNECTION_TIMEOUT);
	    callData.setField(Field.GDRT, getdidREAD_TIMEOUT);

	    callData.setField(Field.GCDURL, getCallDataEndpoint);
	    callData.setField(Field.GCDCID, getCallDataclientId);
	    callData.setField(Field.GCDAPI, getCallDataapiKey);
	    callData.setField(Field.GCDCT, getCallDataCONNECTION_TIMEOUT);
	    callData.setField(Field.GCDRT, getCallDataREAD_TIMEOUT);

	    ODLogger.logDebug(callData.getSceSession(), "### END Setting I3 Urls.");
	}
	
	@Override
	public void setBannerStopUrl(CallData callData) {
	    ODLogger.logDebug(callData.getSceSession(), "### START Setting banner Stop Url.");
	    
	    Properties properties = new Properties();
	    try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
	        properties.load(input);
	    } catch (IOException e) {
	        ODLogger.logError(callData.getSceSession(), "### ERROR Loading banner Urls: " + e.getMessage());
	        return;  // Exit method if properties file fails to load
	    }
	    String getBannerEndpoint = properties.getProperty("banner.stop.ws.endpoint", "N/A");
	    
	    ODLogger.logDebug(callData.getSceSession(), "### getBannerEndpoint URL: " + getBannerEndpoint );
	    
	    // Set values in CallData
	    callData.setField(Field.STOP_BANNER_URL, getBannerEndpoint);
	    ODLogger.logDebug(callData.getSceSession(), "### END Setting banner Stop Url.");
	}
	
	
	
	
}