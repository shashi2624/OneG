/*
 * CallData.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */

package com.avaya.ept.onegas.bl.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.avaya.ept.onegas.bl.service.ODLogger;
import com.avaya.ept.onegas.ws.billing.model.AccountLookupResult;
import com.avaya.ept.onegas.ws.billing.model.AlertInfo;
import com.avaya.ept.onegas.ws.billing.model.AppointmentAvailability;
import com.avaya.ept.onegas.ws.billing.model.OpenServiceOrderDetail;
import com.avaya.ept.onegas.ws.billing.model.PaymentInfo;
import com.avaya.ept.onegas.ws.billing.model.ServiceInfo;
import com.avaya.ept.onegas.ws.location.model.LocationInfo;
import com.avaya.sce.runtimecommon.SCESession;

/**
 * CallData represents a call session and is a common entity for all DD modules.
 * It is a container for all information required during a call session to
 * enable DD and BL collaboration. Fields are stored in a Map and values can be
 * set using setField(key, value) method and retrieved using getField(key).
 */
public class CallData {

//	private static Logger log = Logger.getLogger(CallData.class);
	private Map<Field, String> fields;
	private Map<CAV, String> cavs;
	private SCESession sceSession;
	private BillingAccount billingAccount;
	private List<AccountLookupResult> accountLookupList;
	private List<PaymentInfo> paymentInfoList;
	private List<AppointmentAvailability> appointmentAvailabilityList;
	private OpenServiceOrderDetail openServiceOrder;
	private AlertInfo alertInfo;
	private List<ServiceInfo> serviceInfo;
	private List<LocationInfo> locationsByZipCodeList;

	/**
	 * 
	 * Returns an instance of CallData. Flags map will be initialized with a new
	 * HashMap instance.
	 */
	public CallData() {
		initFields();
		this.cavs = new HashMap<CAV, String>();
		this.billingAccount = new BillingAccount();
	}

	/**
	 * 
	 * Returns an instance of CallData. Flags map will be initialized with a new
	 * HashMap instance.
	 * 
	 * @param mySession
	 */
	public CallData(SCESession sceSession) {
		initFields();
		this.cavs = new HashMap<CAV, String>();
		this.billingAccount = new BillingAccount();
		this.sceSession = sceSession;

	}

	private void initFields() {
		this.fields = new HashMap<Field, String>();
		this.fields.put(Field.LANGUAGE, Constants.LANGUAGE_ENGLISH);
		this.fields.put(Field.ANIMATCH, Constants.FALSE);
		this.fields.put(Field.SSN_VALIDATED, Constants.FALSE);
		this.fields.put(Field.VALID_ACCT, Constants.FALSE);
		this.fields.put(Field.VALIDATED, Constants.FALSE);
		this.fields.put(Field.ACCT_EXIST, Constants.FALSE);
		this.fields.put(Field.IS_OFFICE_OPEN, Constants.FALSE);
		this.fields.put(Field.IS_OFFICE_OPEN_VENDOR, Constants.FALSE);
		this.fields.put(Field.IS_A_PHONE_NUMBER, Constants.FALSE);
		this.fields.put(Field.TRANSFER_TYPE, Constants.TRANSFER_TYPE_NOT_VALIDATED);
		this.fields.put(Field.ACCOUNT_AUTHORIZED, Constants.FALSE);
		this.fields.put(Field.TEST_ANI, Constants.FALSE);
		this.fields.put(Field.TEST_VDN, Constants.FALSE);
		this.fields.put(Field.TEST_XFR, Constants.FALSE);
	}

	public void setField(Field field, String value) {
		ODLogger.logDebug(this.getSceSession(), "### Setting Field [" + field.name() + "] = " + value);
		this.fields.put(field, value);
	}

	public String getField(Field field) {
		String sValue = this.fields.get(field);
		ODLogger.logDebug(this.getSceSession(),"### Getting Field [" + field.name() + "] = " + sValue);
		return sValue;
	}

	public Boolean isFlagOn(Field flag) {
		String value = this.fields.get(flag);
		ODLogger.logDebug(this.getSceSession(),"### Checking Flag [" + flag.name() + "] =" + value);
		return "true".equalsIgnoreCase(value) || "yes".equalsIgnoreCase(value) || "1".equals(value) || "y".equalsIgnoreCase(value);
	}

	public void setCAVs(Map<CAV, String> cavs) {
		ODLogger.logDebug(this.getSceSession(),"### Setting CAVs.");
		this.cavs = cavs;
	}

	public void setCAV(CAV cav, String value) {
		switch (cav) {
		default:
			this.cavs.put(cav, value);
		}
		ODLogger.logDebug(this.getSceSession(),"### Set CAV=" + cav + " value=" + value);
	}

	public String getCAV(CAV cav) {
		String value;
		switch (cav) {
		default:
			value = this.cavs.get(cav);
			break;
		}
		ODLogger.logDebug(this.getSceSession(),"### Got CAV=" + cav + " value=" + value);
		return value;
	}

	public SCESession getSceSession() {
		return sceSession;
	}

	public void setSceSession(SCESession sceSession) {
		this.sceSession = sceSession;
	}

	public BillingAccount getBillingAccount() {
		return billingAccount;
	}

	public void setBillingAccount(BillingAccount billingAccount) {
		this.billingAccount = billingAccount;
	}

	public List<AccountLookupResult> getAccountLookupList() {
		return accountLookupList;
	}

	public void setAccountLookupList(List<AccountLookupResult> accountLookupList) {
		this.accountLookupList = accountLookupList;
	}

	public void setPaymentInfoList(List<PaymentInfo> paymentInfoList) {
		this.paymentInfoList = paymentInfoList;
	}

	public List<PaymentInfo> getPaymentInfoList() {
		return paymentInfoList;
	}

	public void setAppointmentAvailabilityList(List<AppointmentAvailability> appointmentAvailabilityList) {
		this.appointmentAvailabilityList = appointmentAvailabilityList;
	}

	public List<AppointmentAvailability> getAppointmentAvailabilityList() {
		return appointmentAvailabilityList;
	}

	public void setAlertInfo(AlertInfo alertInfo) {
		this.alertInfo = alertInfo;
	}

	public AlertInfo getAlertInfo() {
		return alertInfo;
	}

	public void setServiceInfo(List<ServiceInfo> serviceInfo) {
		this.serviceInfo = serviceInfo;
	}

	public List<ServiceInfo> getServiceInfo() {
		return serviceInfo;
	}

	/**
	 * @return the locationsByZipCodeList
	 */
	public List<LocationInfo> getLocationsByZipCodeList() {
		return locationsByZipCodeList;
	}

	/**
	 * @param locationsByZipCodeList
	 *            the locationsByZipCodeList to set
	 */
	public void setLocationsByZipCodeList(List<LocationInfo> locationsByZipCodeList) {
		this.locationsByZipCodeList = locationsByZipCodeList;
	}

	/**
	 * @return the openServiceOrder
	 */
	public OpenServiceOrderDetail getOpenServiceOrder() {
		return openServiceOrder;
	}

	/**
	 * @param openServiceOrder
	 *            the openServiceOrder to set
	 */
	public void setOpenServiceOrder(OpenServiceOrderDetail openServiceOrder) {
		this.openServiceOrder = openServiceOrder;
	}

}