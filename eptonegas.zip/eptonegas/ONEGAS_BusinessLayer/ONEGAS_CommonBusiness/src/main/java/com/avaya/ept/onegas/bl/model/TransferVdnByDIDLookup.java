package com.avaya.ept.onegas.bl.model;

import com.avaya.ept.onegas.bl.service.ODLogger;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class TransferVdnByDIDLookup {
    
    private static final HikariDataSource dataSource;
    private static final String query;  // Now final to prevent accidental modifications

    static {
		/*
		 * HikariConfig config = new HikariConfig(); config.setJdbcUrl(
		 * "jdbc:sqlserver://ogssqlaep01ptul:1433;databaseName=IVR_routing_DB");
		 * config.setUsername("IVR_Routing_Admin");
		 * config.setPassword("#%STS?@3#94T!tx"); config.setMinimumIdle(10);
		 * config.setMaximumPoolSize(100); config.setConnectionTimeout(3000);
		 * 
		 * dataSource = new HikariDataSource(config);
		 */
    	Properties properties = new Properties();
        
        try (InputStream input = TransferVdnByDIDLookup.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) {
                throw new RuntimeException("### config.properties file not found in classpath ###");
            }
            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException("### Error loading database properties: " + e.getMessage(), e);
        }

        // Prevent NullPointerException by setting a default query
        query = properties.getProperty("TransferVdnByDidQuery", "SELECT TRANSFER_VDN FROM dbo.I3_TRANSFER_VDN WHERE DID = ?");
        
        // Initialize HikariCP using values from the properties file
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(properties.getProperty("db.url"));
        config.setUsername(properties.getProperty("db.username"));
        config.setPassword(properties.getProperty("db.password"));
        config.setMinimumIdle(Integer.parseInt(properties.getProperty("db.minimumIdle", "10")));
        config.setMaximumPoolSize(Integer.parseInt(properties.getProperty("db.maximumPoolSize", "100")));
        config.setConnectionTimeout(Long.parseLong(properties.getProperty("db.connectionTimeout", "3000")));

        dataSource = new HikariDataSource(config);
    }

    // Singleton instance
    private static final TransferVdnByDIDLookup instance = new TransferVdnByDIDLookup();

    private TransferVdnByDIDLookup() {}

    public static TransferVdnByDIDLookup getInstance() {
        return instance;
    }

    public String getTransferVdnByDid(CallData callData, String didNumber) {
        ODLogger.logDebug(callData.getSceSession(), "### Inside getTransferVdnByDid for DID: " + didNumber);
        
        //String query = "SELECT TRANSFER_VDN FROM dbo.I3_TRANSFER_VDN_TEST WHERE DID = ?";
        ODLogger.logDebug(callData.getSceSession(), "### getTransferVdnByDid Query ### " + query);

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setString(1, didNumber);

            ODLogger.logDebug(callData.getSceSession(), "### DB connection successful for DID lookup ###");

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String transferVdn = rs.getString("TRANSFER_VDN");
                    ODLogger.logDebug(callData.getSceSession(), "### Successfully fetched TRANSFER_VDN: " + transferVdn);
                    return transferVdn;
                }
            }
        } catch (SQLException e) {
            ODLogger.logDebug(callData.getSceSession(), "### Exception in getTransferVdnByDid: " + e);
        }
        return null;
    }
}