/*
* AnnounceValueType.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/

package com.avaya.ept.onegas.bl.model;

/**
 * @author javantario
 *
 */
public enum AnnounceValueTTSMode implements AnnounceValueMode {
	
	TEXT {
		@Override
		public String value() {
			return "text";
		}	
	},
	NUMBER {
		@Override
		public String value() {
			return "number";
		}	
	},
	DIGITS {
		@Override
		public String value() {
			return "digits";
		}	
	},
	DATE {
		@Override
		public String value() {
			return "date";
		}	
	},
	CURRENCY {
		@Override
		public String value() {
			return "currency";
		}	
	},
	ADDRESS {
		@Override
		public String value() {
			return "address";
		}	
	},
	NAME {
		@Override
		public String value() {
			return "name";
		}	
	},
	TELEPHONE {
		@Override
		public String value() {
			return "telephone";
		}	
	};
	
	public abstract String value();

}
