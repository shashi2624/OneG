/*
 * ONEGASCommonService.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */

package com.avaya.ept.onegas.bl.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.ResourceLoaderAware;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import com.avaya.ept.onegas.bl.model.VDNKey;
import com.avaya.ept.onegas.bl.model.VDNValue;

public class VDNTransferService implements ResourceLoaderAware {
	private static Logger log;
	private Map<VDNKey, VDNValue> transferVDN;
	private ResourceLoader resourceLoader;
	private InputStreamReader inputStreamReader;
	private BufferedReader br;
	private InputStream inputStream;
	Date modifiedtime;
	

	static {
		VDNTransferService.log = Logger.getLogger(VDNTransferService.class);
	}
	
	public void init() {
		VDNTransferService.log.info("Initializing VDNTransferService...");
		Resource resource= this.getResource("classpath:transferVDN.properties");
		
		try {
			
			inputStream = resource.getInputStream();
			inputStreamReader = new InputStreamReader(inputStream);
			br = new BufferedReader(this.inputStreamReader);
			String line = this.br.readLine();
			if (line != null) {
				this.transferVDN = new HashMap<VDNKey, VDNValue>();
				while ((line = this.br.readLine()) != null) {
					if (!"".equals(line)) {
						final String[] propertyLine = line.split(",");
						final VDNKey vdnKey = new VDNKey(propertyLine[0], propertyLine[1], propertyLine[2]);
						VDNValue vdnValue = null;

						if (propertyLine.length == 4) {
							vdnValue = new VDNValue(propertyLine[3], " ", " ");
						}
						if (propertyLine.length == 5) {
							vdnValue = new VDNValue(propertyLine[3], propertyLine[4], " ");
						}
						if (propertyLine.length == 6) {
							vdnValue = new VDNValue(propertyLine[3], propertyLine[4], propertyLine[5]);
						}

						transferVDN.put(vdnKey, vdnValue);
					}
				}
				this.br.close();
				this.inputStreamReader.close();
				this.inputStream.close();
			}
		} catch (Exception e) {
			VDNTransferService.log.error("Error initialazing VDNTransferService", (Throwable) e);
			try {
				this.br.close();
				this.inputStreamReader.close();
				this.inputStream.close();
			} catch (IOException e2) {
				VDNTransferService.log.error("Error closing streams", (Throwable) e2);
			}

		} finally {
			try {
				this.br.close();
				this.inputStreamReader.close();
				this.inputStream.close();
			} catch (IOException e2) {
				VDNTransferService.log.error("Error closing streams", (Throwable) e2);
			}
		}
		try {
			this.br.close();
			this.inputStreamReader.close();
			this.inputStream.close();
		} catch (IOException e2) {
			VDNTransferService.log.error("Error closing streams", (Throwable) e2);
		}

		VDNTransferService.log.info("VDNTransferService initialized OK");
	}

	public VDNValue getVDN(String location, String language, String transferType) throws IOException {
		VDNTransferService.log.debug(("Looking VDN for Location: " + location + ", Language: " + language
				+ ", Transfer Type: " + transferType));
		
		return transferVDN.get(new VDNKey(location, language, transferType));
	}

	public void setResourceLoader(ResourceLoader resourceLoader) {
		this.resourceLoader = resourceLoader;
	}

	public Resource getResource(String location) {
		return this.resourceLoader.getResource(location);
	}

}