/*
 * BillingAccount.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */
package com.avaya.ept.onegas.bl.model;

import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

public class BillingAccount {

	
	//########  Change for ONEGas 17OK2019  ########  
	private String latestAllowedDateForPastDuePayment;
	
	private Integer serviceID;
	private String accountStatus;
	private String accountNumber;
	private String firstName;
	private String lastName;
	private String middleName;
	private String address;
	private Double totalAccountBalance;
	private Double totalAmountDue;
	private Double amountPastDue;
	private Double lastPaymentAmount;
	private Date lastPaymentDate;
	private String dueDate;
	private boolean onBankDraft = false;
	private boolean onEbill = false;
	private boolean onBudget = false;
	private boolean onPayArrangement = false;
	private int serviceCount = 0;
	private boolean canReadMeter = false;
	private boolean canPayByElectronicCheck = false;
	private boolean canEnrollInElectronicBilling = false;
	private String bankRoutingNumber;
	private String bankAccountNumber;
	private String bankAccountType;
	private String confirmationNumber;
	private Double amountDue;
	private Double maxPaymentAmount;
	private Integer consToRead;
	private Double consumption;
	private XMLGregorianCalendar nextReadDate;
	private String meterDials;
	private boolean isRoundingUp = false;
	private Double roundUpAmount;
	private boolean enrolledInBudget = false;
	private Double budgetAmount;
	private String appointmentConfirmationNumber;
	private boolean voluntaryFixedPriceEligible = false;
	private Double dollarAmount;
	private boolean canEnrollInBudget = false;
	private boolean canEnrollBankDraft = false;
	private boolean canRequestMoveOut = false;
	private String paymentLocation;
	private Double amount;
	private Double payArrangementDownPaymentAmount;
	private Double downPayment;
	private Double installmentAmount;
	private Integer installCount;
	private boolean canMakePaymentArrangement;
	private boolean canMakeMemoPayment;
	private boolean hasPendingVoluntaryFixedPrice;
	private String paymentDate;
	private boolean hasOpenNonPaymentShutOffOrder;
	private boolean hasPendingNonPaymentShutOffOrder;
	private boolean hasDisconnectLetter;
	private String disconnectOrderDispatchStatus;
	private String serviceOrderNumber;
	private String startDate;
	private String endDate;
	private String window;
	private String billingAccountNumber;
	private String duration;
	private String eventCode;
	private String emailAddress;
	private boolean hasBadDebt;
	private boolean isMasterBill;
	private boolean canUseWebAccess;
	private Double averagePaymentAmount;
	private boolean pendingMoveOutNeedDate;
	private boolean pending502NeedDate;
	private boolean isMeterInside;
	private String sheduleDate;
	private Date firstAppointmentAvailabilityDate;
	private Integer existingRead;
	private boolean highRead;
	private boolean lowRead;

	private Double paymentArrangementsAmountDue;// Phase 2 changes   01-06-2022
	
	// Phase 2 changes   01-06-2022
	public Double getPaymentArrangementAmountDue() {
		return paymentArrangementsAmountDue;
	}

	public void setPaymentArrangementAmountDue(Double paymentArrangementsAmountDue) {
		this.paymentArrangementsAmountDue = paymentArrangementsAmountDue;
	}
	
	// Phase 2 changes   01-06-2022
	
	
	public String getSheduleDate() {
		return sheduleDate;
	}

	public void setSheduleDate(String sheduleDate) {
		this.sheduleDate = sheduleDate;
	}

	public Integer getServiceID() {
		return serviceID;
	}

	public void setServiceID(Integer serviceID) {
		this.serviceID = serviceID;
	}

	public Double getAveragePaymentAmount() {
		return averagePaymentAmount;
	}

	public void setAveragePaymentAmount(Double averagePaymentAmount) {
		this.averagePaymentAmount = averagePaymentAmount;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public boolean isCanUseWebAccess() {
		return canUseWebAccess;
	}

	public void setCanUseWebAccess(boolean canUseWebAccess) {
		this.canUseWebAccess = canUseWebAccess;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getWindow() {
		return window;
	}

	public void setWindow(String window) {
		this.window = window;
	}

	public String getBillingAccountNumber() {
		return billingAccountNumber;
	}

	public void setBillingAccountNumber(String billingAccountNumber) {
		this.billingAccountNumber = billingAccountNumber;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getServiceOrderNumber() {
		return serviceOrderNumber;
	}

	public void setServiceOrderNumber(String serviceOrderNumber) {
		this.serviceOrderNumber = serviceOrderNumber;
	}

	public String getDisconnectOrderDispatchStatus() {
		return disconnectOrderDispatchStatus;
	}

	public void setDisconnectOrderDispatchStatus(String disconnectOrderDispatchStatus) {
		this.disconnectOrderDispatchStatus = disconnectOrderDispatchStatus;
	}

	public boolean isHasOpenNonPaymentShutOffOrder() {
		return hasOpenNonPaymentShutOffOrder;
	}

	public void setHasOpenNonPaymentShutOffOrder(boolean hasOpenNonPaymentShutOffOrder) {
		this.hasOpenNonPaymentShutOffOrder = hasOpenNonPaymentShutOffOrder;
	}

	public boolean isHasPendingNonPaymentShutOffOrder() {
		return hasPendingNonPaymentShutOffOrder;
	}

	public void setHasPendingNonPaymentShutOffOrder(boolean hasPendingNonPaymentShutOffOrder) {
		this.hasPendingNonPaymentShutOffOrder = hasPendingNonPaymentShutOffOrder;
	}

	public boolean isHasDisconnectLetter() {
		return hasDisconnectLetter;
	}

	public void setHasDisconnectLetter(boolean hasDisconnectLetter) {
		this.hasDisconnectLetter = hasDisconnectLetter;
	}

	/**
	 * @return the paymentDate
	 */
	public String getPaymentDate() {
		return paymentDate;
	}

	/**
	 * @param paymentDate
	 *            the paymentDate to set
	 */
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	/**
	 * @return the amount
	 */
	public Double getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(Double amount) {
		this.amount = amount;
	}

	/**
	 * @return the hasPendingVoluntaryFixedPrice
	 */
	public boolean isHasPendingVoluntaryFixedPrice() {
		return hasPendingVoluntaryFixedPrice;
	}

	/**
	 * @param hasPendingVoluntaryFixedPrice
	 *            the hasPendingVoluntaryFixedPrice to set
	 */
	public void setHasPendingVoluntaryFixedPrice(boolean hasPendingVoluntaryFixedPrice) {
		this.hasPendingVoluntaryFixedPrice = hasPendingVoluntaryFixedPrice;
	}

	/**
	 * @return the canEnrollBankDraft
	 */
	public boolean isCanEnrollBankDraft() {
		return canEnrollBankDraft;
	}

	/**
	 * @param canEnrollBankDraft
	 *            the canEnrollBankDraft to set
	 */
	public void setCanEnrollBankDraft(boolean canEnrollBankDraft) {
		this.canEnrollBankDraft = canEnrollBankDraft;
	}

	/**
	 * @return the dollarAmount
	 */
	public Double getDollarAmount() {
		return dollarAmount;
	}

	/**
	 * @param dollarAmount
	 *            the dollarAmount to set
	 */
	public void setDollarAmount(Double dollarAmount) {
		this.dollarAmount = dollarAmount;
	}

	/**
	 * @return the voluntaryFixedPriceEligible
	 */
	public boolean isVoluntaryFixedPriceEligible() {
		return voluntaryFixedPriceEligible;
	}

	/**
	 * @param voluntaryFixedPriceEligible
	 *            the voluntaryFixedPriceEligible to set
	 */
	public void setVoluntaryFixedPriceEligible(boolean voluntaryFixedPriceEligible) {
		this.voluntaryFixedPriceEligible = voluntaryFixedPriceEligible;
	}

	/**
	 * @return the enrolledInBudget
	 */
	public boolean isEnrolledInBudget() {
		return enrolledInBudget;
	}

	/**
	 * @param enrolledInBudget
	 *            the enrolledInBudget to set
	 */
	public void setEnrolledInBudget(boolean enrolledInBudget) {
		this.enrolledInBudget = enrolledInBudget;
	}

	/**
	 * @return the budgetAmount
	 */
	public Double getBudgetAmount() {
		return budgetAmount;
	}

	/**
	 * @param budgetAmount
	 *            the budgetAmount to set
	 */
	public void setBudgetAmount(Double budgetAmount) {
		this.budgetAmount = budgetAmount;
	}

	/**
	 * @return the isRoundingUp
	 */
	public boolean isIsRoundingUp() {
		return isRoundingUp;
	}

	/**
	 * @param isRoundingUp
	 *            the isRoundingUp to set
	 */
	public void setIsRoundingUp(boolean isRoundingUp) {
		this.isRoundingUp = isRoundingUp;
	}

	/**
	 * @return the roundUpAmount
	 */
	public Double getRoundUpAmount() {
		return roundUpAmount;
	}

	/**
	 * @param roundUpAmount
	 *            the roundUpAmount to set
	 */
	public void setRoundUpAmount(Double roundUpAmount) {
		this.roundUpAmount = roundUpAmount;
	}

	/**
	 * @return the maxPaymentAmount
	 */
	public Double getMaxPaymentAmount() {
		return maxPaymentAmount;
	}

	/**
	 * @param maxPaymentAmount
	 *            the maxPaymentAmount to set
	 */
	public void setMaxPaymentAmount(Double maxPaymentAmount) {
		this.maxPaymentAmount = maxPaymentAmount;
	}

	/**
	 * @return the amountDue
	 */
	public Double getAmountDue() {
		return amountDue;
	}

	/**
	 * @param amountDue
	 *            the amountDue to set
	 */
	public void setAmountDue(Double amountDue) {
		this.amountDue = amountDue;
	}

	/**
	 * @return the bankAccountNumber
	 */
	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	/**
	 * @param bankAccountNumber
	 *            the bankAccountNumber to set
	 */
	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	/**
	 * @return the bankRoutingNumber
	 */
	public String getBankRoutingNumber() {
		return bankRoutingNumber;
	}

	/**
	 * @param bankRoutingNumber
	 *            the bankRoutingNumber to set
	 */
	public void setBankRoutingNumber(String bankRoutingNumber) {
		this.bankRoutingNumber = bankRoutingNumber;
	}

	/**
	 * @return the canPayByElectronicCheck
	 */
	public boolean isCanPayByElectronicCheck() {
		return canPayByElectronicCheck;
	}

	/**
	 * @param canPayByElectronicCheck
	 *            the canPayByElectronicCheck to set
	 */
	public void setCanPayByElectronicCheck(boolean canPayByElectronicCheck) {
		this.canPayByElectronicCheck = canPayByElectronicCheck;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the totalAccountBalance
	 */
	public Double getTotalAccountBalance() {
		return totalAccountBalance;
	}

	/**
	 * @param totalAccountBalance
	 *            the totalAccountBalance to set
	 */
	public void setTotalAccountBalance(Double totalAccountBalance) {
		this.totalAccountBalance = totalAccountBalance;
	}

	/**
	 * @return the totalAmountDue
	 */
	public Double getTotalAmountDue() {
		return totalAmountDue;
	}

	/**
	 * @param totalAmountDue
	 *            the totalAmountDue to set
	 */
	public void setTotalAmountDue(Double totalAmountDue) {
		this.totalAmountDue = totalAmountDue;
	}

	/**
	 * @return the amountPastDue
	 */
	public Double getAmountPastDue() {
		return amountPastDue;
	}

	/**
	 * @param amountPastDue
	 *            the amountPastDue to set
	 */
	public void setAmountPastDue(Double amountPastDue) {
		this.amountPastDue = amountPastDue;
	}

	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}

	/**
	 * @param dueDate
	 *            the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	/**
	 * @return the lastPaymentAmount
	 */
	public Double getLastPaymentAmount() {
		return lastPaymentAmount;
	}

	/**
	 * @param lastPaymentAmount
	 *            the lastPaymentAmount to set
	 */
	public void setLastPaymentAmount(Double lastPaymentAmount) {
		this.lastPaymentAmount = lastPaymentAmount;
	}

	/**
	 * @return the lastPaymentDate
	 */
	public Date getLastPaymentDate() {
		return lastPaymentDate;
	}

	/**
	 * @param lastPaymentDate
	 *            the lastPaymentDate to set
	 */
	public void setLastPaymentDate(Date lastPaymentDate) {
		this.lastPaymentDate = lastPaymentDate;
	}

	/**
	 * @return the onBankDraft
	 */
	public boolean isOnBankDraft() {
		return onBankDraft;
	}

	/**
	 * @param onBankDraft
	 *            the onBankDraft to set
	 */
	public void setOnBankDraft(boolean onBankDraft) {
		this.onBankDraft = onBankDraft;
	}

	/**
	 * @return the onEbill
	 */
	public boolean isOnEbill() {
		return onEbill;
	}

	/**
	 * @param onEbill
	 *            the onEbill to set
	 */
	public void setOnEbill(boolean onEbill) {
		this.onEbill = onEbill;
	}

	/**
	 * @return the accountStatus
	 */
	public String getAccountStatus() {
		return accountStatus;
	}

	/**
	 * @param accountStatus
	 *            the accountStatus to set
	 */
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	/**
	 * @return the onBudget
	 */
	public boolean isOnBudget() {
		return onBudget;
	}

	/**
	 * @param onBudget
	 *            the onBudget to set
	 */
	public void setOnBudget(boolean onBudget) {
		this.onBudget = onBudget;
	}

	/**
	 * @return the onPayArrangement
	 */
	public boolean isOnPayArrangement() {
		return onPayArrangement;
	}

	/**
	 * @param onPayArrangement
	 *            the onPayArrangement to set
	 */
	public void setOnPayArrangement(boolean onPayArrangement) {
		this.onPayArrangement = onPayArrangement;
	}

	/**
	 * @return the serviceCount
	 */
	public int getServiceCount() {
		return serviceCount;
	}

	/**
	 * @param serviceCount
	 *            the serviceCount to set
	 */
	public void setServiceCount(int serviceCount) {
		this.serviceCount = serviceCount;
	}

	/**
	 * @return the canReadMeter
	 */
	public boolean isCanReadMeter() {
		return canReadMeter;
	}

	/**
	 * @param canReadMeter
	 *            the canReadMeter to set
	 */
	public void setCanReadMeter(boolean canReadMeter) {
		this.canReadMeter = canReadMeter;
	}

	/**
	 * @return the canEnrollInElectronicBilling
	 */
	public boolean isCanEnrollInElectronicBilling() {
		return canEnrollInElectronicBilling;
	}

	/**
	 * @param canEnrollInElectronicBilling
	 *            the canEnrollInElectronicBilling to set
	 */
	public void setCanEnrollInElectronicBilling(boolean canEnrollInElectronicBilling) {
		this.canEnrollInElectronicBilling = canEnrollInElectronicBilling;
	}


	/**
	 * @return the consumption
	 */
	public Double getConsumption() {
		return consumption;
	}

	/**
	 * @param consumption
	 *            the consumption to set
	 */
	public void setConsumption(Double consumption) {
		this.consumption = consumption;
	}

	/**
	 * @return the nextReadDate
	 */
	public XMLGregorianCalendar getNextReadDate() {
		return nextReadDate;
	}

	/**
	 * @param nextReadDate
	 *            the nextReadDate to set
	 */
	public void setNextReadDate(XMLGregorianCalendar nextReadDate) {
		this.nextReadDate = nextReadDate;
	}

	/**
	 * @return the meterDials
	 */
	public String getMeterDials() {
		return meterDials;
	}

	/**
	 * @param meterDials
	 *            the meterDials to set
	 */
	public void setMeterDials(String meterDials) {
		this.meterDials = meterDials;
	}

	/**
	 * @return the appointmentConfirmationNumber
	 */
	public String getAppointmentConfirmationNumber() {
		return appointmentConfirmationNumber;
	}

	/**
	 * @param appointmentConfirmationNumber
	 *            the appointmentConfirmationNumber to set
	 */
	public void setAppointmentConfirmationNumber(String appointmentConfirmationNumber) {
		this.appointmentConfirmationNumber = appointmentConfirmationNumber;
	}

	/**
	 * @return the canEnrollInBudget
	 */
	public boolean isCanEnrollInBudget() {
		return canEnrollInBudget;
	}

	/**
	 * @param canEnrollInBudget
	 *            the canEnrollInBudget to set
	 */
	public void setCanEnrollInBudget(boolean canEnrollInBudget) {
		this.canEnrollInBudget = canEnrollInBudget;
	}


	/**
	 * @return the paymentLocation
	 */
	public String getPaymentLocation() {
		return paymentLocation;
	}

	/**
	 * @param paymentLocation
	 *            the paymentLocation to set
	 */
	public void setPaymentLocation(String paymentLocation) {
		this.paymentLocation = paymentLocation;
	}

	/**
	 * @return the payArrangementDownPaymentAmount
	 */
	public Double getPayArrangementDownPaymentAmount() {
		return payArrangementDownPaymentAmount;
	}

	/**
	 * @param payArrangementDownPaymentAmount
	 *            the payArrangementDownPaymentAmount to set
	 */
	public void setPayArrangementDownPaymentAmount(Double payArrangementDownPaymentAmount) {
		this.payArrangementDownPaymentAmount = payArrangementDownPaymentAmount;
	}

	/**
	 * @return the downPayment
	 */
	public Double getDownPayment() {
		return downPayment;
	}

	/**
	 * @param downPayment
	 *            the downPayment to set
	 */
	public void setDownPayment(Double downPayment) {
		this.downPayment = downPayment;
	}

	/**
	 * @return the installmentAmount
	 */
	public Double getInstallmentAmount() {
		return installmentAmount;
	}

	/**
	 * @param installmentAmount
	 *            the installmentAmount to set
	 */
	public void setInstallmentAmount(Double installmentAmount) {
		this.installmentAmount = installmentAmount;
	}

	/**
	 * @return the installCount
	 */
	public Integer getInstallCount() {
		return installCount;
	}

	/**
	 * @param installCount
	 *            the installCount to set
	 */
	public void setInstallCount(Integer installCount) {
		this.installCount = installCount;
	}

	/**
	 * @return the canMakePaymentArrangement
	 */
	public boolean isCanMakePaymentArrangement() {
		return canMakePaymentArrangement;
	}

	/**
	 * @param canMakePaymentArrangement
	 *            the canMakePaymentArrangement to set
	 */
	public void setCanMakePaymentArrangement(boolean canMakePaymentArrangement) {
		this.canMakePaymentArrangement = canMakePaymentArrangement;
	}

	/**
	 * @return the canMakeMemoPayment
	 */
	public boolean isCanMakeMemoPayment() {
		return canMakeMemoPayment;
	}

	/**
	 * @param canMakeMemoPayment
	 *            the canMakeMemoPayment to set
	 */
	public void setCanMakeMemoPayment(boolean canMakeMemoPayment) {
		this.canMakeMemoPayment = canMakeMemoPayment;
	}

	public String getBankAccountType() {
		return bankAccountType;
	}

	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}

	public String getConfirmationNumber() {
		return confirmationNumber;
	}

	public void setConfirmationNumber(String confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	/**
	 * @return the hasBadDebt
	 */
	public boolean isHasBadDebt() {
		return hasBadDebt;
	}

	/**
	 * @param hasBadDebt
	 *            the hasBadDebt to set
	 */
	public void setHasBadDebt(boolean hasBadDebt) {
		this.hasBadDebt = hasBadDebt;
	}

	/**
	 * @return the isMasterBill
	 */
	public boolean isMasterBill() {
		return isMasterBill;
	}

	/**
	 * @param isMasterBill
	 *            the isMasterBill to set
	 */
	public void setMasterBill(boolean isMasterBill) {
		this.isMasterBill = isMasterBill;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName
	 *            the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the isMeterInside
	 */
	public boolean isMeterInside() {
		return isMeterInside;
	}

	/**
	 * @param isMeterInside
	 *            the isMeterInside to set
	 */
	public void setMeterInside(boolean isMeterInside) {
		this.isMeterInside = isMeterInside;
	}

	/**
	 * @return the pending502NeedDate
	 */
	public boolean isPending502NeedDate() {
		return pending502NeedDate;
	}

	/**
	 * @param pending502NeedDate
	 *            the pending502NeedDate to set
	 */
	public void setPending502NeedDate(boolean pending502NeedDate) {
		this.pending502NeedDate = pending502NeedDate;
	}

	/**
	 * @return the pendingMoveOutNeedDate
	 */
	public boolean isPendingMoveOutNeedDate() {
		return pendingMoveOutNeedDate;
	}

	/**
	 * @param pendingMoveOutNeedDate
	 *            the pendingMoveOutNeedDate to set
	 */
	public void setPendingMoveOutNeedDate(boolean pendingMoveOutNeedDate) {
		this.pendingMoveOutNeedDate = pendingMoveOutNeedDate;
	}

	/**
	 * @return the firstAppointmentAvailabilityDate
	 */
	public Date getFirstAppointmentAvailabilityDate() {
		return firstAppointmentAvailabilityDate != null ? new Date(firstAppointmentAvailabilityDate.getTime()) : null;
	}

	/**
	 * @param firstAppointmentAvailabilityDate
	 *            the firstAppointmentAvailabilityDate to set
	 */
	public void setFirstAppointmentAvailabilityDate(Date firstAppointmentAvailabilityDate) {
		this.firstAppointmentAvailabilityDate = firstAppointmentAvailabilityDate != null ? new Date(firstAppointmentAvailabilityDate.getTime()) : null;
	}

	/**
	 * @return the existingRead
	 */
	public Integer getExistingRead() {
		return existingRead;
	}

	/**
	 * @param existingRead
	 *            the existingRead to set
	 */
	public void setExistingRead(Integer existingRead) {
		this.existingRead = existingRead;
	}

	/**
	 * @return the highRead
	 */
	public boolean isHighRead() {
		return highRead;
	}

	/**
	 * @param highRead
	 *            the highRead to set
	 */
	public void setHighRead(boolean highRead) {
		this.highRead = highRead;
	}

	/**
	 * @return the lowRead
	 */
	public boolean isLowRead() {
		return lowRead;
	}

	/**
	 * @param lowRead
	 *            the lowRead to set
	 */
	public void setLowRead(boolean lowRead) {
		this.lowRead = lowRead;
	}

	public boolean isCanRequestMoveOut() {
		return canRequestMoveOut;
	}

	public void setCanRequestMoveOut(boolean canRequestMoveOut) {
		this.canRequestMoveOut = canRequestMoveOut;
	}

	public Integer getConsToRead() {
		return consToRead;
	}

	public void setConsToRead(Integer consToRead) {
		this.consToRead = consToRead;
	}
	
	public String getLatestAllowedDateForPastDuePayment() {
		return latestAllowedDateForPastDuePayment;
	}

	public void setLatestAllowedDateForPastDuePayment(
			String latestAllowedDateForPastDuePayment) {
		this.latestAllowedDateForPastDuePayment = latestAllowedDateForPastDuePayment;
	}
}
