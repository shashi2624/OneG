
/*
* IONEGASCommonService.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/

package com.avaya.ept.onegas.bl.service;

import java.util.Date;

import com.avaya.ept.onegas.bl.model.CallData;
import com.avaya.ept.onegas.bl.model.InvalidDayException;
import com.avaya.ept.onegas.bl.model.InvalidMonthException;
import com.avaya.ept.onegas.bl.model.InvalidYearException;
import com.avaya.ept.onegas.bl.model.ServiceException;

public interface IONEGASCommonService {
	
	String getGrammarURL(CallData callData);
	String getCustomAudioURL(CallData callData);
	String getStandardSpeechAudioURL(CallData callData);
	boolean isFieldNotNullOrEmpty(String field);
	String getDateAsString(Date date);
	String getDateAsStringYYYMMDD(Date date);
	void setLdcProvider(CallData callData);
	boolean isANINull(CallData callData) throws ServiceException;
	String getPropertiesFilesPath(CallData callData);
	boolean isOfficeOpen(CallData callData, Date today) throws ServiceException;
	boolean isOfficeOpenNCO(CallData callData, Date today) throws ServiceException;
	boolean isAccountStatusOk(CallData callData) throws ServiceException;
	boolean isMultiAccounts(CallData callData) throws ServiceException;
	int checkHouseNumbAmount(CallData callData) throws ServiceException;
	String getCurrencyFormat(String currency);
	String getDigitsFormat(String digits);
	String getDateFormat(String date);
	String isThisDateValid(String dateToValidate, String dateFromat, CallData callData)throws InvalidYearException, InvalidMonthException, InvalidDayException;
	String getSeason(CallData callData, String today);
	boolean isCheckArrears(CallData callData);
	String checkPayment(CallData callData);
	boolean lookupBillingAccountAni(CallData callData) throws ServiceException;
	boolean lookupBillingAccountPhoneNumber(CallData callData) throws ServiceException;
	boolean getAccountSummary(CallData callData) throws ServiceException;
	boolean getAccountSummaryCallerInput(CallData callData) throws ServiceException;
	boolean getOpenServiceOrders(CallData callData) throws ServiceException;
	boolean removeBankAccountInformation(CallData callData) throws ServiceException;
	boolean existingTimePayment(CallData callData) throws ServiceException;
	boolean newTimePayment(CallData callData) throws ServiceException;
	boolean registerBankAccountInformation(CallData callData) throws ServiceException;
	void submitMemoPayment(CallData callData) throws ServiceException;
	boolean getLocationsByZipCode(CallData callData) throws ServiceException;
	boolean enrollInBankDraft(CallData callData) throws ServiceException;
	boolean cancelBankDraft(CallData callData) throws ServiceException;
	boolean updateBankDraftInfo(CallData callData) throws ServiceException;
	boolean requestDupilcateBill(CallData callData) throws ServiceException;
	boolean requestLetterOfCredit(CallData callData) throws ServiceException;
	boolean setShareTheWarmthStatusEnroll(CallData callData) throws ServiceException;
	boolean setShareTheWarmthStatusUpdate(CallData callData) throws ServiceException;
	boolean setShareTheWarmthStatusCancel(CallData callData) throws ServiceException;
	boolean setElectronicBillingStatus(CallData callData) throws ServiceException;
	boolean reserveAppointment(CallData callData) throws ServiceException;
	boolean callReserveAppointment(CallData callData) throws ServiceException;
	boolean requestMoveOutOrder(CallData callData) throws ServiceException;
	boolean getAppointmentAvailability(CallData callData) throws ServiceException;
	boolean requestServiceOrderChange(CallData callData) throws ServiceException;
	boolean enterMeterRead(CallData callData) throws ServiceException;
	boolean enrollForVoluntaryFixedPrice(CallData callData) throws ServiceException;
	boolean enrollForAveragePaymentPlan(CallData callData) throws ServiceException;
	boolean cancelServiceOrder(CallData callData) throws ServiceException;
	boolean getPaymentHistory(CallData callData) throws ServiceException;
	boolean submitEAP(CallData callData) throws ServiceException;
	String agencyLookup(CallData callData) throws ServiceException;
	String lookupAudioPhrase(CallData callData) throws ServiceException;
	boolean validateAccount(CallData callData) throws ServiceException;
	void requestPaymentArrangementFalse(CallData callData) throws ServiceException;
	void requestPaymentArrangementTrue(CallData callData) throws ServiceException;
	boolean isAHolidayDate(CallData callData, Date aDate) throws ServiceException;
	boolean getAveragePaymentPlanAmount(CallData callData) throws ServiceException;
	boolean isAccountStatusOKAfterGasAppliance(CallData callData)throws ServiceException;
	boolean isFirtDate60DaysGreaterThanSecondDate(Date firstDate, Date secondDate);
	boolean accountsDisambiguation(CallData callData) throws ServiceException;
	boolean isAWeekendDay(CallData callData, Date appDate);
	boolean isDateValid(String dateToValidate, String dateFormat, CallData callData);
	String getVoiceRecordedFilesPath(CallData callData);
	String getCurrencyStringFromInput(CallData callData, String stringToConvert);
	void createContextStoreEntry(CallData callData);
	String getVoiceRecordedFilesCompletePath(CallData callData);
	boolean updatePropertiesForFalse(CallData callData) throws ServiceException;
	boolean updatePropertiesForTrue(CallData callData) throws ServiceException;
	void requestPaymentArrangementFalseWithDownPaymentAmount(CallData callData)	throws ServiceException;
	void requestPaymentArrangementFalseWithDownPaymentAmountAndInstallments(CallData callData) throws ServiceException;
	String checkAmountStatus(CallData callData);
	boolean isFirstDateBetweenSecondAndThirdDate(CallData callData, Date firstDate, Date minDate, Date maxDate);
	//Phase 2D change to check ANI
	boolean isANIOk(CallData callData);
	//Phase 2D change to check Maintainance
	boolean isMaintainaceDay(CallData callData, Date today) throws ServiceException;
	boolean isAHolidayDateVendor(CallData callData, Date aDate) throws ServiceException; 
	//String setI3CallLanguage(CallData callData, String phoneNumber);
	String fetchLanguageForVdn(CallData callData, String vdnNumber);
	String fetchVDNForDID(CallData callData, String did);
	void setI3Urls(CallData callData);
	void setBannerStopUrl(CallData callData);
	

	
}
