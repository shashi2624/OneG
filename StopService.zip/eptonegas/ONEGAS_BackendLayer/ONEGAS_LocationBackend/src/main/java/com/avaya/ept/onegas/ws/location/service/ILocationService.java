package com.avaya.ept.onegas.ws.location.service;

import java.util.List;

import com.avaya.ept.onegas.ws.location.exception.LocationClientServiceException;
import com.avaya.ept.onegas.ws.location.model.LocationInfo;

public interface ILocationService {
	
	List<LocationInfo> getLocationsByZipCode(String zipCode) throws LocationClientServiceException;

}
