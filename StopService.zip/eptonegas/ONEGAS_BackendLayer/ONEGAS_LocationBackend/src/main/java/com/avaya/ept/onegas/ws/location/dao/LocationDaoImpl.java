package com.avaya.ept.onegas.ws.location.dao;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.avaya.ept.onegas.ws.location.exception.LocationDaoException;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCode;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCodeResponse;

public class LocationDaoImpl<T> implements ILocationDao {

	private static final Logger logger = Logger.getLogger(LocationDaoImpl.class);
	private WebServiceTemplate locationServiceTemplate;
	private String soapAction;

	
	public GetLocationsByZipCodeResponse getLocationsByZipCode(GetLocationsByZipCode request) throws LocationDaoException {
		SoapActionCallback soapActionCallback = new SoapActionCallback(soapAction+request.getClass().getSimpleName());
		return new LocationCallBack<GetLocationsByZipCode, GetLocationsByZipCodeResponse>() {

			@Override
			public int getStatusCode(GetLocationsByZipCodeResponse response) {
				return response.getGetLocationsByZipCodeResult().getValue().getStatusCode();
			}

			@Override
			public JAXBElement<String> getStatusMessage(GetLocationsByZipCodeResponse response) {
				return response.getGetLocationsByZipCodeResult().getValue().getStatusMessage();
			}
		}.call(logger, getLocationServiceTemplate(), request, soapActionCallback);
	}


	public WebServiceTemplate getLocationServiceTemplate() {
		return locationServiceTemplate;
	}


	public void setLocationServiceTemplate(WebServiceTemplate locationServiceTemplate) {
		this.locationServiceTemplate = locationServiceTemplate;
	}


	public String getSoapAction() {
		return soapAction;
	}


	public void setSoapAction(String soapAction) {
		this.soapAction = soapAction;
	}
}