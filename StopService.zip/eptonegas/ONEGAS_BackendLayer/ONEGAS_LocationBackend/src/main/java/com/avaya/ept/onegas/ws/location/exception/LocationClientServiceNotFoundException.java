
/*
* LocationClientServiceNotFoundException.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/
package com.avaya.ept.onegas.ws.location.exception;

/**
 * @author schmidt0
 *
 */
public class LocationClientServiceNotFoundException extends
		LocationClientServiceException {

	/**
	 * @param message
	 * @param statusCode
	 */
	public LocationClientServiceNotFoundException(String message, int statusCode) {
		super(message, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * @param message
	 * @param cause
	 * @param statusCode
	 */
	public LocationClientServiceNotFoundException(String message,
			Throwable cause, int statusCode) {
		super(message, cause, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * @param cause
	 * @param statusCode
	 */
	public LocationClientServiceNotFoundException(Throwable cause,
			int statusCode) {
		super(cause, statusCode);
		setStatusCode(statusCode);
	}

	/**
	 * 
	 */
	public LocationClientServiceNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public LocationClientServiceNotFoundException(String message,
			Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public LocationClientServiceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public LocationClientServiceNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -6346065747284357000L;

}
