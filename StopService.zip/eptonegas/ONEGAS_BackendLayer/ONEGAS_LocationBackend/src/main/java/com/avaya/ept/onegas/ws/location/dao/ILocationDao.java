package com.avaya.ept.onegas.ws.location.dao;

import com.avaya.ept.onegas.ws.location.exception.LocationDaoException;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCode;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCodeResponse;


public interface ILocationDao {
	
	public GetLocationsByZipCodeResponse getLocationsByZipCode(GetLocationsByZipCode request) throws LocationDaoException;	
}