
/*
* LocationDaoMock.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/
package com.avaya.ept.onegas.ws.location.dao;

import static org.springframework.ws.test.client.RequestMatchers.anything;
import static org.springframework.ws.test.client.ResponseCreators.withPayload;

import java.io.IOException;

import javax.xml.transform.Source;

import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.test.client.MockWebServiceServer;
import org.springframework.xml.transform.ResourceSource;

import com.avaya.ept.onegas.ws.location.exception.LocationDaoException;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCode;
import com.avaya.ept.onegas.ws.location.model.GetLocationsByZipCodeResponse;

/**
 * @author schmidt0
 *
 */
public class LocationDaoMock implements ILocationDao {
	
	private MockWebServiceServer mockServer;
	private WebServiceTemplate locationServiceTemplate;

	@Override
	public GetLocationsByZipCodeResponse getLocationsByZipCode(
			GetLocationsByZipCode request) throws LocationDaoException {
		setMockServer(MockWebServiceServer.createServer(getLocationServiceTemplate()));
		
		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/GetLocationsByZipCodeResponse.xml"));
			getMockServer().expect(anything()).andRespond(withPayload(expectedResponse));
			GetLocationsByZipCodeResponse response = (GetLocationsByZipCodeResponse) getLocationServiceTemplate().marshalSendAndReceive(request);
			getMockServer().verify();
			return response;
		} catch (IOException e) {
			throw new LocationDaoException(e);
		}
	}

	/**
	 * @return the locationServiceTemplate
	 */
	public WebServiceTemplate getLocationServiceTemplate() {
		return locationServiceTemplate;
	}

	/**
	 * @param locationServiceTemplate the locationServiceTemplate to set
	 */
	public void setLocationServiceTemplate(WebServiceTemplate locationServiceTemplate) {
		this.locationServiceTemplate = locationServiceTemplate;
	}

	/**
	 * @return the mockServer
	 */
	public MockWebServiceServer getMockServer() {
		return mockServer;
	}

	/**
	 * @param mockServer the mockServer to set
	 */
	public void setMockServer(MockWebServiceServer mockServer) {
		this.mockServer = mockServer;
	}	
}