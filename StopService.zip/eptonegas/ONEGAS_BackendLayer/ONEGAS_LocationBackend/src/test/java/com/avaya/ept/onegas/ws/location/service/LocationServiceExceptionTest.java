package com.avaya.ept.onegas.ws.location.service;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.avaya.ept.onegas.ws.location.exception.LocationClientServiceException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:LocationExceptionBackendContextTest.xml")
public class LocationServiceExceptionTest {
	
    /**
	 * 
	 */
	private static final String ZIP_CODE = "74136";
	@Autowired
    @Qualifier(value = "locationService")
    private ILocationService locationService;
    
	@Test(expected=LocationClientServiceException.class)
	public void getLocationsByZipCodeTest() throws LocationClientServiceException{
			locationService.getLocationsByZipCode(ZIP_CODE);
	}

	public ILocationService getLocationService() {
		return locationService;
	}

	public void setLocationService(ILocationService locationService) {
		this.locationService = locationService;
	}
}