package com.avaya.ept.onegas.ws.location.service;


import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.avaya.ept.onegas.ws.location.exception.LocationClientServiceException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:LocationBackendContextTest.xml")
public class LocationServiceTest {
	
    /**
	 * 
	 */
	private static final String ZIP_CODE = "74136";
	@Autowired
    @Qualifier(value = "locationService")
    private ILocationService locationService;
    
	@Test
	public void getLocationsByZipCodeTest(){
		try {
			locationService.getLocationsByZipCode(ZIP_CODE);
		} catch (LocationClientServiceException e) {
			Assert.fail(e.getMessage());
			e.printStackTrace();
		}
	}

	public ILocationService getLocationService() {
		return locationService;
	}

	public void setLocationService(ILocationService locationService) {
		this.locationService = locationService;
	}
}