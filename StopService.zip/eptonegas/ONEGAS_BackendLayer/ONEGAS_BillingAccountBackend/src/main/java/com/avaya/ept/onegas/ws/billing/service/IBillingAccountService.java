package com.avaya.ept.onegas.ws.billing.service;

import java.util.Date;
import java.util.List;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountClientServiceException;
import com.avaya.ept.onegas.ws.billing.model.AccountLookupResult;
import com.avaya.ept.onegas.ws.billing.model.AppointmentAvailabilityInfo;
import com.avaya.ept.onegas.ws.billing.model.AppointmentReservationResponse;
import com.avaya.ept.onegas.ws.billing.model.AppointmentType;
import com.avaya.ept.onegas.ws.billing.model.BillingAccountInfo;
import com.avaya.ept.onegas.ws.billing.model.MeterEntryResponse;
import com.avaya.ept.onegas.ws.billing.model.MoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.OpenServiceOrderDetail;
import com.avaya.ept.onegas.ws.billing.model.PaymentArrangementDetail;
import com.avaya.ept.onegas.ws.billing.model.PaymentHistoryInfo;
import com.avaya.ept.onegas.ws.billing.model.ServiceOrderChangeResponse;


public interface IBillingAccountService {
	
	List<AccountLookupResult> lookupBillingAcount(String ani, String ldcProvider) throws BillingAccountClientServiceException;
	List<OpenServiceOrderDetail> getOpenServiceOrders(String accountNumber) throws BillingAccountClientServiceException;
	BillingAccountInfo getAccountSummary(String accountNumber) throws BillingAccountClientServiceException;
	boolean cancelServiceOrder(String billingAccountNumber, String serviceOrderNumber, String cancelReasonCode, String cancelNotes) throws BillingAccountClientServiceException;
	boolean removeBankAccountInformation (String accountNumber) throws BillingAccountClientServiceException;
	String makeOneTimePayment(String accountNumber, Double paymentAmmount, String bankNumber, String bankAccType, String routingNumber, Date paymentDate) throws BillingAccountClientServiceException;
	String makeOneTimePaymentWithExistingBankAccount(String accountNumber, Double paymentAmmount, Date paymentDate) throws BillingAccountClientServiceException;
	boolean registerBankAccountInformation(String accountNumber, String bankNumber, String bankAccType, String routingNumber) throws BillingAccountClientServiceException;
	String submitMemoPayment(String accountNumber, Double paymentAmt, String receiptNum, Date paymentDate) throws BillingAccountClientServiceException;
	boolean enrollInBankDraft(String accountNumber, String bankNumber, String bankAccType, String routingNumber) throws BillingAccountClientServiceException;
	boolean cancelBankDraft(String accountNumber) throws BillingAccountClientServiceException;
	boolean updateBankDraftInfo(String accountNumber, String bankNumber, String bankAccType, String routingNumber) throws BillingAccountClientServiceException;
	boolean requestDuplicateBill(String accountNumber, Date billDate) throws BillingAccountClientServiceException;
	boolean requestLetterOfCredit(String accountNumber) throws BillingAccountClientServiceException;
	boolean setShareTheWarmthStatus(String accountNumber, Double paymentAmt, String acction, Date startDate, Date endDate) throws BillingAccountClientServiceException;
	boolean setElectronicBillingStatus(String accountNumber, String email, String acction) throws BillingAccountClientServiceException;
	AppointmentReservationResponse callReserveAppointment(String accountNumber,AppointmentType appType, Date apptDate, String duration, String eventCode) throws BillingAccountClientServiceException;
	AppointmentAvailabilityInfo getAppointmentAvailability(String accountNumber,String appointment, Date apptDate, String duration) throws BillingAccountClientServiceException;
	MoveOutOrderResponse requestMoveOutOrder(String accountNumber, Date apptDate, String phoneNum, String confNumb, String apptWindow, String firstName, String midName, String lastName) throws BillingAccountClientServiceException;
	ServiceOrderChangeResponse requestServiceOrderChange(String accountNumber,String svcOrderNum, String changeType, String svcOrderType, Date reqDate,  String duration, String apptWindow, String confNumber) throws BillingAccountClientServiceException;
	MeterEntryResponse enterMeterRead(String accountNumber, Integer serviceID, Integer meterReading, boolean forceEntry) throws BillingAccountClientServiceException;
	boolean enrollForVoluntaryFixedPrice (String accountNumber, Integer serviceNumber) throws BillingAccountClientServiceException;
	boolean enrollForAveragePaymentPlan (String accountNumber, Integer serviceNumber) throws BillingAccountClientServiceException;
	PaymentHistoryInfo getPaymentHistory (String accountNumber) throws BillingAccountClientServiceException;
	boolean submitEnergyAssistancePromise (String accountNumber, String agencyCode, Double paymentAmt) throws BillingAccountClientServiceException;
	boolean validateAccount (String accountNumber, String lastSSN) throws BillingAccountClientServiceException;
	PaymentArrangementDetail requestPaymentArrangement (String accountNumber, boolean createArrangement, Double installmentAmount, Integer numberOfPayments, Double downPaymentAmount) throws BillingAccountClientServiceException;
	Double getAveragePaymentPlanAmount (String accountNumber, Integer serviceNumber) throws BillingAccountClientServiceException;
	
}
