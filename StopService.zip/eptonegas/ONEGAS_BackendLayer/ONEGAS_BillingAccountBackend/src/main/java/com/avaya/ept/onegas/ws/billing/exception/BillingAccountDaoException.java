package com.avaya.ept.onegas.ws.billing.exception;

/**
 * 
 * @author schmidt0
 * 
 */
public class BillingAccountDaoException extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2138733089114510231L;
	
	private int statusCode;
	
	public BillingAccountDaoException() {
	}

	/**
	 * @param message
	 */
	public BillingAccountDaoException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public BillingAccountDaoException(Throwable cause) {
		super(cause);
	}
	/**
	 * @param message
	 */
	public BillingAccountDaoException(String message, int statusCode) {
		super(message);
		setStatusCode(statusCode);
	}
	
	/**
	 * @param cause
	 */
	public BillingAccountDaoException(Throwable cause, int statusCode) {
		super(cause);
		setStatusCode(statusCode);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BillingAccountDaoException(String message, Throwable cause) {
		super(message, cause);
	}
	/**
	 * @param message
	 * @param cause
	 */
	public BillingAccountDaoException(String message, Throwable cause, int statusCode) {
		super(message, cause);
		setStatusCode(statusCode);
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

}
