package com.avaya.ept.onegas.ws.billing.exception;

/**
 * 
 * @author schmidt0
 * 
 */
public class BillingAccountClientServiceException extends Exception{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5341479083419754611L;

	private int statusCode;
	
	public BillingAccountClientServiceException() {
	}

	/**
	 * @param message
	 */
	public BillingAccountClientServiceException(String message) {
		super(message);

	}

	/**
	 * @param cause
	 */
	public BillingAccountClientServiceException(Throwable cause) {
		super(cause);

	}
	/**
	 * @param message
	 */
	public BillingAccountClientServiceException(String message, int statusCode) {
		super(message);
		setStatusCode(statusCode);
	}
	
	/**
	 * @param cause
	 */
	public BillingAccountClientServiceException(Throwable cause, int statusCode) {
		super(cause);
		setStatusCode(statusCode);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public BillingAccountClientServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	public BillingAccountClientServiceException(String message, Throwable cause, int statusCode) {
		super(message, cause);
		setStatusCode(statusCode);
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

}
