/*
 * BillingAccountDaoMock.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */
package com.avaya.ept.onegas.ws.billing.dao;

import static org.springframework.ws.test.client.RequestMatchers.anything;
import static org.springframework.ws.test.client.ResponseCreators.withPayload;

import java.io.IOException;

import javax.xml.transform.Source;

import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.test.client.MockWebServiceServer;
import org.springframework.xml.transform.ResourceSource;

import com.avaya.ept.onegas.ws.billing.exception.BillingAccountDaoException;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraft;
import com.avaya.ept.onegas.ws.billing.model.CancelBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrder;
import com.avaya.ept.onegas.ws.billing.model.CancelServiceOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlan;
import com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlanResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPrice;
import com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPriceResponse;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraft;
import com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraftResponse;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterRead;
import com.avaya.ept.onegas.ws.billing.model.EnterMeterReadResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummary;
import com.avaya.ept.onegas.ws.billing.model.GetAccountSummaryResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailability;
import com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailabilityResponse;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmount;
import com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmountResponse;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrders;
import com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrdersResponse;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistory;
import com.avaya.ept.onegas.ws.billing.model.GetPaymentHistoryResponse;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccount;
import com.avaya.ept.onegas.ws.billing.model.LookupBillingAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePayment;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount;
import com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccountResponse;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformation;
import com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformationResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBill;
import com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBillResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCredit;
import com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCreditResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrder;
import com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrderResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangement;
import com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangementResponse;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChange;
import com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChangeResponse;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointment;
import com.avaya.ept.onegas.ws.billing.model.ReserveAppointmentResponse;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatus;
import com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatus;
import com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatusResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromise;
import com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromiseResponse;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPayment;
import com.avaya.ept.onegas.ws.billing.model.SubmitMemoPaymentResponse;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfo;
import com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfoResponse;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccount;
import com.avaya.ept.onegas.ws.billing.model.ValidateAccountResponse;

/**
 * @author schmidt0
 * 
 */
public class BillingAccountDaoMock implements IBilingAccountDao {

	private MockWebServiceServer mockServer;
	private WebServiceTemplate billingAccountServiceTemplate;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#lookupBillingAccount
	 * (com.avaya.ept.onegas.ws.billing.model.LookupBillingAccount)
	 */
	@Override
	public LookupBillingAccountResponse lookupBillingAccount(LookupBillingAccount request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/LookupBillingAccountResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			LookupBillingAccountResponse response = (LookupBillingAccountResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#getOpenServiceOrders
	 * (com.avaya.ept.onegas.ws.billing.model.GetOpenServiceOrders)
	 */
	@Override
	public GetOpenServiceOrdersResponse getOpenServiceOrders(GetOpenServiceOrders request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/GetOpenServiceOrdersResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			GetOpenServiceOrdersResponse response = (GetOpenServiceOrdersResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#getAccountSummary
	 * (com.avaya.ept.onegas.ws.billing.model.GetAccountSummary)
	 */
	@Override
	public GetAccountSummaryResponse getAccountSummary(GetAccountSummary request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/GetAccountSummaryResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			GetAccountSummaryResponse response = (GetAccountSummaryResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * removeBankAccountInformation
	 * (com.avaya.ept.onegas.ws.billing.model.RemoveBankAccountInformation)
	 */
	@Override
	public RemoveBankAccountInformationResponse removeBankAccountInformation(RemoveBankAccountInformation request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/RemoveBankAccountInformationResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			RemoveBankAccountInformationResponse response = (RemoveBankAccountInformationResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#makeOneTimePayment
	 * (com.avaya.ept.onegas.ws.billing.model.MakeOneTimePayment)
	 */
	@Override
	public MakeOneTimePaymentResponse makeOneTimePayment(MakeOneTimePayment request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/MakeOneTimePaymentResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			MakeOneTimePaymentResponse response = (MakeOneTimePaymentResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#makeOneTimePaymentWithExistingBankAccount(com.avaya.ept.onegas.ws.billing.model.MakeOneTimePaymentWithExistingBankAccount)
	 */
	@Override
	public MakeOneTimePaymentWithExistingBankAccountResponse makeOneTimePaymentWithExistingBankAccount(
			MakeOneTimePaymentWithExistingBankAccount request)
			throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/MakeOneTimePaymentWithExistingBankAccountResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			MakeOneTimePaymentWithExistingBankAccountResponse response = (MakeOneTimePaymentWithExistingBankAccountResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * registerBankAccountInformation
	 * (com.avaya.ept.onegas.ws.billing.model.RegisterBankAccountInformation)
	 */
	@Override
	public RegisterBankAccountInformationResponse registerBankAccountInformation(RegisterBankAccountInformation request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/RegisterBankAccountInformationResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			RegisterBankAccountInformationResponse response = (RegisterBankAccountInformationResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#submitMemoPayment
	 * (com.avaya.ept.onegas.ws.billing.model.SubmitMemoPayment)
	 */
	@Override
	public SubmitMemoPaymentResponse submitMemoPayment(SubmitMemoPayment request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/SubmitMemoPaymentResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			SubmitMemoPaymentResponse response = (SubmitMemoPaymentResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#enrollInBankDraft
	 * (com.avaya.ept.onegas.ws.billing.model.EnrollInBankDraft)
	 */
	@Override
	public EnrollInBankDraftResponse enrollInBankDraft(EnrollInBankDraft request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/EnrollInBankDraftResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			EnrollInBankDraftResponse response = (EnrollInBankDraftResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#cancelBankDraft
	 * (com.avaya.ept.onegas.ws.billing.model.CancelBankDraft)
	 */
	@Override
	public CancelBankDraftResponse cancelBankDraft(CancelBankDraft request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/cancelbankaccresponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			CancelBankDraftResponse response = (CancelBankDraftResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#updateBankDraftInfo
	 * (com.avaya.ept.onegas.ws.billing.model.UpdateBankDraftInfo)
	 */
	@Override
	public UpdateBankDraftInfoResponse updateBankDraftInfo(UpdateBankDraftInfo request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/UpdateBankDraftInfoResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			UpdateBankDraftInfoResponse response = (UpdateBankDraftInfoResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#requestDuplicateBill
	 * (com.avaya.ept.onegas.ws.billing.model.RequestDuplicateBill)
	 */
	@Override
	public RequestDuplicateBillResponse requestDuplicateBill(RequestDuplicateBill request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/RequestDuplicateBillResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			RequestDuplicateBillResponse response = (RequestDuplicateBillResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#requestLetterOfCredit
	 * (com.avaya.ept.onegas.ws.billing.model.RequestLetterOfCredit)
	 */
	@Override
	public RequestLetterOfCreditResponse requestLetterOfCredit(RequestLetterOfCredit request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/RequestLetterOfCreditResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			RequestLetterOfCreditResponse response = (RequestLetterOfCreditResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#setShareTheWarmthStatus
	 * (com.avaya.ept.onegas.ws.billing.model.SetShareTheWarmthStatus)
	 */
	@Override
	public SetShareTheWarmthStatusResponse setShareTheWarmthStatus(SetShareTheWarmthStatus request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/SetShareTheWarmthStatusResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			SetShareTheWarmthStatusResponse response = (SetShareTheWarmthStatusResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * setElectronicBillingStatus
	 * (com.avaya.ept.onegas.ws.billing.model.SetElectronicBillingStatus)
	 */
	@Override
	public SetElectronicBillingStatusResponse setElectronicBillingStatus(SetElectronicBillingStatus request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/SetElectronicBillingStatusResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			SetElectronicBillingStatusResponse response = (SetElectronicBillingStatusResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#reserveAppointment
	 * (com.avaya.ept.onegas.ws.billing.model.ReserveAppointment)
	 */
	@Override
	public ReserveAppointmentResponse reserveAppointment(ReserveAppointment request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/ReserveAppointmentResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			ReserveAppointmentResponse response = (ReserveAppointmentResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * getAppointmentAvailability
	 * (com.avaya.ept.onegas.ws.billing.model.GetAppointmentAvailability)
	 */
	@Override
	public GetAppointmentAvailabilityResponse getAppointmentAvailability(GetAppointmentAvailability request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/GetAppointmentAvailabilityResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			GetAppointmentAvailabilityResponse response = (GetAppointmentAvailabilityResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#requestMoveOutOrder
	 * (com.avaya.ept.onegas.ws.billing.model.RequestMoveOutOrder)
	 */
	@Override
	public RequestMoveOutOrderResponse requestMoveOutOrder(RequestMoveOutOrder request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/RequestMoveOutOrderResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			RequestMoveOutOrderResponse response = (RequestMoveOutOrderResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * requestServiceOrderChange
	 * (com.avaya.ept.onegas.ws.billing.model.RequestServiceOrderChange)
	 */
	@Override
	public RequestServiceOrderChangeResponse requestServiceOrderChange(RequestServiceOrderChange request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/RequestServiceOrderChangeResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			RequestServiceOrderChangeResponse response = (RequestServiceOrderChangeResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#enterMeterRead(
	 * com.avaya.ept.onegas.ws.billing.model.EnterMeterRead)
	 */
	@Override
	public EnterMeterReadResponse enterMeterRead(EnterMeterRead request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/EnterMeterReadResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			EnterMeterReadResponse response = (EnterMeterReadResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * enrollForVoluntaryFixedPrice
	 * (com.avaya.ept.onegas.ws.billing.model.EnrollForVoluntaryFixedPrice)
	 */
	@Override
	public EnrollForVoluntaryFixedPriceResponse enrollForVoluntaryFixedPrice(EnrollForVoluntaryFixedPrice request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/EnrollForVoluntaryFixedPriceResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			EnrollForVoluntaryFixedPriceResponse response = (EnrollForVoluntaryFixedPriceResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#getPaymentHistory
	 * (com.avaya.ept.onegas.ws.billing.model.GetPaymentHistory)
	 */
	@Override
	public GetPaymentHistoryResponse getPaymentHistory(GetPaymentHistory request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/GetPaymentHistoryResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			GetPaymentHistoryResponse response = (GetPaymentHistoryResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#validateAccount
	 * (com.avaya.ept.onegas.ws.billing.model.ValidateAccount)
	 */
	@Override
	public ValidateAccountResponse validateAccount(ValidateAccount request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/ValidateAccountResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			ValidateAccountResponse response = (ValidateAccountResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * requestPaymentArrangement
	 * (com.avaya.ept.onegas.ws.billing.model.RequestPaymentArrangement)
	 */
	@Override
	public RequestPaymentArrangementResponse requestPaymentArrangement(RequestPaymentArrangement request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/RequestPaymentArrangementResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			RequestPaymentArrangementResponse response = (RequestPaymentArrangementResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * getAveragePaymentPlanAmount
	 * (com.avaya.ept.onegas.ws.billing.model.GetAveragePaymentPlanAmount)
	 */
	@Override
	public GetAveragePaymentPlanAmountResponse getAveragePaymentPlanAmount(GetAveragePaymentPlanAmount request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/GetAveragePaymentPlanAmountResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			GetAveragePaymentPlanAmountResponse response = (GetAveragePaymentPlanAmountResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * enrollForAveragePaymentPlan
	 * (com.avaya.ept.onegas.ws.billing.model.EnrollForAveragePaymentPlan)
	 */
	@Override
	public EnrollForAveragePaymentPlanResponse enrollForAveragePaymentPlan(EnrollForAveragePaymentPlan request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/EnrollForAveragePaymentPlanResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			EnrollForAveragePaymentPlanResponse response = (EnrollForAveragePaymentPlanResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.avaya.ept.onegas.ws.billing.dao.IBilingAccountDao#
	 * submitEnergyAssistancePromise
	 * (com.avaya.ept.onegas.ws.billing.model.SubmitEnergyAssistancePromise)
	 */
	@Override
	public SubmitEnergyAssistancePromiseResponse submitEnergyAssistancePromise(SubmitEnergyAssistancePromise request) throws BillingAccountDaoException {

		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/SubmitEnergyAssistancePromiseResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			SubmitEnergyAssistancePromiseResponse response = (SubmitEnergyAssistancePromiseResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	@Override
	public CancelServiceOrderResponse cancelServiceOrder(CancelServiceOrder request) throws BillingAccountDaoException {
		mockServer = MockWebServiceServer.createServer(getBillingAccountServiceTemplate());

		try {
			Source expectedResponse = new ResourceSource(new ClassPathResource("mock/CancelServiceOrderResponse.xml"));
			mockServer.expect(anything()).andRespond(withPayload(expectedResponse));
			CancelServiceOrderResponse response = (CancelServiceOrderResponse) getBillingAccountServiceTemplate().marshalSendAndReceive(request);
			mockServer.verify();
			return response;
		} catch (IOException e) {
			throw new BillingAccountDaoException(e);
		}
	}

	public MockWebServiceServer getMockServer() {
		return mockServer;
	}

	public void setMockServer(MockWebServiceServer mockServer) {
		this.mockServer = mockServer;
	}

	public WebServiceTemplate getBillingAccountServiceTemplate() {
		return billingAccountServiceTemplate;
	}

	public void setBillingAccountServiceTemplate(WebServiceTemplate billingAccountServiceTemplate) {
		this.billingAccountServiceTemplate = billingAccountServiceTemplate;
	}




}
