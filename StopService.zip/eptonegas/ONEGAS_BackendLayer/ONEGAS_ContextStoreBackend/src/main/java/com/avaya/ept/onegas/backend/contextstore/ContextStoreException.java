package com.avaya.ept.onegas.backend.contextstore;

public class ContextStoreException extends RuntimeException {

	private static final long serialVersionUID = -221359699146279236L;

	public ContextStoreException(String message) {
		super(message);
	}

	public ContextStoreException(String message, Throwable cause) {
		super(message, cause);
	}

}
