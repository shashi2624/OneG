/*
 * ONEGASCommonServiceTest.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 
package com.avaya.ept.onegas.bl.service;

import org.junit.BeforeClass;
import org.junit.Test;

import com.avaya.ept.onegas.bl.model.CallData;
import com.avaya.ept.onegas.bl.model.Field;
import com.avaya.ept.onegas.bl.model.ServiceException;
import com.avaya.ept.onegas.ws.billing.model.BankAccountType;

public class ONEGASCommonServiceExceptionTest {

	private static IONEGASCommonService onegasCommonService;

	@BeforeClass
	public static void onlyOnce() {
		setOnegasCommonService(ONEGASClientServiceExceptionContext.getONEGASCommonService());
	}

	@Test(expected = ServiceException.class)
	public void lookupBillingAccountAniTest() throws ServiceException {
		CallData callData = new CallData();
		onegasCommonService.lookupBillingAccountAni(callData);
	}

	@Test(expected = ServiceException.class)
	public void getAccountSummaryTest() throws ServiceException {
		CallData callData = new CallData();
		onegasCommonService.getAccountSummary(callData);
	}

	@Test(expected = ServiceException.class)
	public void getOpenServiceOrdersTest() throws ServiceException {
		CallData callData = new CallData();
		onegasCommonService.getOpenServiceOrders(callData);
	}
	
	@Test(expected = ServiceException.class)
	public void removeBankAccountInformationTest() throws ServiceException {
		CallData callData = new CallData();
		onegasCommonService.removeBankAccountInformation(callData);
	}
	
	@Test(expected = ServiceException.class)
	public void existingTimePaymentTest() throws ServiceException {
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Checking");
		callData.getBillingAccount().setBankRoutingNumber("301179892");
		callData.getBillingAccount().setBankAccountNumber("12345678");
		callData.setField(Field.PAYMENT_AMOUNT, "123.4");
		callData.setField(Field.PAYMENT_DATE, "20101125");
		onegasCommonService.existingTimePayment(callData);
	}

	@Test(expected = ServiceException.class)
	public void newTimePaymentTest() throws ServiceException {
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType(BankAccountType.CHECKING.value());
		callData.getBillingAccount().setBankRoutingNumber("301179892");
		callData.getBillingAccount().setBillingAccountNumber("301179892");
		callData.getBillingAccount().setBankAccountNumber("301179892");
//		callData.setField(Field.ACCOUNT_TYPE, "Checking");
//		callData.setField(Field.ROUTING_NUMBER, "301179892");
//		callData.setField(Field.CHECKING_NUMBER, "12345678");
		callData.setField(Field.PAYMENT_AMOUNT, "5.01");
		callData.setField(Field.PAYMENT_DATE, "20101125");
		onegasCommonService.newTimePayment(callData);
	}

	@Test(expected = ServiceException.class)
	public void registerBankAccountInformationTest() throws ServiceException {
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Savings");
		callData.getBillingAccount().setBankRoutingNumber("301179892");
		callData.getBillingAccount().setBankAccountNumber("12345678");
		onegasCommonService.registerBankAccountInformation(callData);
	}
	
	@Test(expected = ServiceException.class)
	public void submitMemoPaymentTest() throws ServiceException {
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.setField(Field.PAYMENT_AMOUNT, "2.05");
		callData.setField(Field.RECEIPT_NUM, "546585");
		callData.setField(Field.PAYMENT_DATE, "07012016");
		onegasCommonService.submitMemoPayment(callData);
	}
	
	@Test(expected = ServiceException.class)
	public void enrollInBankDraftTest() throws ServiceException {
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Checking");
		callData.getBillingAccount().setBankRoutingNumber("301179892");
		callData.getBillingAccount().setBankAccountNumber("12345678");
		onegasCommonService.enrollInBankDraft(callData);
	}
	
	@Test(expected = ServiceException.class)
	public void cancelBankDraftTest() throws ServiceException {
		CallData callData = new CallData();
		onegasCommonService.cancelBankDraft(callData);
	}
	
	@Test(expected = ServiceException.class)
	public void updateBankDraftInfoTest() throws ServiceException {
		CallData callData = new CallData();
		callData.getBillingAccount().setAccountNumber("1111111111111111");
		callData.getBillingAccount().setBankAccountType("Checking");
		callData.getBillingAccount().setBankRoutingNumber("301179892");
		callData.getBillingAccount().setBankAccountNumber("12345678");
		onegasCommonService.updateBankDraftInfo(callData);
	}
	
	@Test(expected = ServiceException.class)
	public void requestDupilcateBillTest() throws ServiceException {
		CallData callData = new CallData();
		onegasCommonService.requestDupilcateBill(callData);
	}
	
	public static IONEGASCommonService getOnegasCommonService() {
		return onegasCommonService;
	}

	public static void setOnegasCommonService(IONEGASCommonService onegasCommonService) {
		ONEGASCommonServiceExceptionTest.onegasCommonService = onegasCommonService;
	}
}*/