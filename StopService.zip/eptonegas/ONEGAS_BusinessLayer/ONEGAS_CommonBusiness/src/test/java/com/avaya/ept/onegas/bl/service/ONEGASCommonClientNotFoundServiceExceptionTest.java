/*
 * ONEGASCommonServiceTest.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */
package com.avaya.ept.onegas.bl.service;

import static org.junit.Assert.assertFalse;

import org.junit.BeforeClass;
import org.junit.Test;

import com.avaya.ept.onegas.bl.model.CallData;
import com.avaya.ept.onegas.bl.model.ServiceException;

public class ONEGASCommonClientNotFoundServiceExceptionTest {

	private static IONEGASCommonService onegasCommonService;

	@BeforeClass
	public static void onlyOnce() {
		setOnegasCommonService(ONEGASClientNotFoundServiceExceptionContext.getONEGASCommonService());
	}

	@Test
	public void lookupBillingAccountAniTest() throws ServiceException {
		CallData callData = new CallData();
		assertFalse(onegasCommonService.lookupBillingAccountAni(callData));
	}

	@Test
	public void getAccountSummaryTest() throws ServiceException {
		CallData callData = new CallData();
		assertFalse(onegasCommonService.getAccountSummary(callData));
	}

	public static IONEGASCommonService getOnegasCommonService() {
		return onegasCommonService;
	}

	public static void setOnegasCommonService(IONEGASCommonService onegasCommonService) {
		ONEGASCommonClientNotFoundServiceExceptionTest.onegasCommonService = onegasCommonService;
	}
} 