package com.avaya.ept.onegas.bl.model;

public class VDNKey {
	
	String location = null;
	String language = null;
	String transferType = null;
	
	public VDNKey(String location, String language, String transferType) {
		super();
		this.location = location;
		this.language = language;
		this.transferType = transferType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((language == null) ? 0 : language.hashCode());
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((transferType == null) ? 0 : transferType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VDNKey other = (VDNKey) obj;
		if (language == null) {
			if (other.language != null)
				return false;
		} else if (!language.equals(other.language))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (transferType == null) {
			if (other.transferType != null)
				return false;
		} else if (!transferType.equals(other.transferType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VDNKey [location=" + location + ", language=" + language + ", transferType=" + transferType + "]";
	}
}