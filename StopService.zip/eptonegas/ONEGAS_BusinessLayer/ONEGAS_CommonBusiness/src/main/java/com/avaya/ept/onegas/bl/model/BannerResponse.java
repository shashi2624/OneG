package com.avaya.ept.onegas.bl.model;

public class BannerResponse {
    public boolean isSuccessful;
    public boolean isBannerOnline;
    public boolean isBannerRestricted;
    public String responseMessage;
    public String trackingId;
    public String responseData; // raw XML string when present
}
