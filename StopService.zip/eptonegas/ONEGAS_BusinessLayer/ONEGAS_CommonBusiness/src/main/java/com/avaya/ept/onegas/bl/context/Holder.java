
/*
* Holder.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/
package com.avaya.ept.onegas.bl.context;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.avaya.ept.onegas.backend.contextstore.types.ContextStoreService;
import com.avaya.ept.onegas.bl.service.IONEGASCommonService;
import com.avaya.ept.onegas.bl.service.VDNTransferService;

@Component(value="onegasCommonHolder")
public class Holder {
	@Autowired
	private IONEGASCommonService onegasCommonService;
	
	@Autowired
	private ContextStoreService contextStoreService;

	@Autowired
	private VDNTransferService vdnTransferService;
	
	/**
	 * 
	 */
	public Holder() {
	}

	public void setONEGASCommonService(IONEGASCommonService onegasCommonService) {
		this.onegasCommonService = onegasCommonService;
	}

	public IONEGASCommonService getONEGASCommonService() {
		return onegasCommonService;
	}

	public ContextStoreService getContextStoreService() {
		return contextStoreService;
	}

	public void setContextStoreService(ContextStoreService contextStoreService) {
		this.contextStoreService = contextStoreService;
	}

	public VDNTransferService getVdnTransferService() {
		return vdnTransferService;
	}

	public void setVdnTransferService(VDNTransferService vdnTransferService) {
		this.vdnTransferService = vdnTransferService;
	}
	
}