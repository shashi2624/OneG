package com.avaya.ept.onegas.bl.service;

import com.avaya.ept.onegas.bl.context.ONEGASContext;
import com.avaya.ept.onegas.bl.model.BannerResponse;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class BannerApiClient {
    private final ONEGASContext ctx;

    public BannerApiClient(ONEGASContext ctx) {
        this.ctx = ctx;
    }

    private void ensureToken() throws Exception {
        if (!ctx.tokenExpired()) return;
        String url = ctx.getBaseUrl() + "Accounts/GetAuthorizationToken";
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setDoOutput(true);
        int status = conn.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        String body = sb.toString();
        String token = body.replaceAll(".*\\\"token\\\"\\s*:\\s*\\\"([^\\\"]+)\\\".*", "$1");
        ctx.setToken(token);
    }

    private String doPost(String pathWithDist, String bodyJson) throws Exception {
        ensureToken();
        String fullUrl = ctx.getBaseUrl() + pathWithDist + "?distributionCompany=" + ctx.getDistributionCompany();
        HttpURLConnection conn = (HttpURLConnection) new URL(fullUrl).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Authorization", "Bearer " + ctx.getToken());
        conn.setRequestProperty("Content-Type", "application/json");
        if (bodyJson != null) {
            try (OutputStream os = conn.getOutputStream()) {
                os.write(bodyJson.getBytes("UTF-8"));
            }
        }
        int status = conn.getResponseCode();
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        reader.close();
        return sb.toString();
    }

    private static BannerResponse toResponse(String json) {
        BannerResponse br = new BannerResponse();
        br.isSuccessful = json.contains("\"isSuccessful\": true");
        br.isBannerOnline = json.contains("\"isBannerOnline\": true");
        br.isBannerRestricted = json.contains("\"isBannerRestricted\": true");
        br.responseMessage = json.replaceAll(".*\\\"responseMessage\\\"\\s*:\\s*\\\"([^\\\"]*)\\\".*", "$1");
        br.trackingId = json.replaceAll(".*\\\"trackingId\\\"\\s*:\\s*\\\"([^\\\"]*)\\\".*", "$1");
        br.responseData = json.contains("\"responseData\"")
                ? json.replaceAll(".*\\\"responseData\\\"\\s*:\\s*\\\"([\\s\\S]*?)\\\".*", "$1").replace("\\\"", "\"")
                : null;
        return br;
    }

    public BannerResponse precheck(String bodyJson) throws Exception {
        return toResponse(doPost("IVRServices/MoveInOutPrecheck", bodyJson));
    }
    public BannerResponse getApptAvailability(String bodyJson) throws Exception {
        return toResponse(doPost("IVRServices/GetApptAvailability", bodyJson));
    }
    public BannerResponse reserveAppointment(String bodyJson) throws Exception {
        return toResponse(doPost("IVRServices/ReserveAppointment", bodyJson));
    }
    public BannerResponse createMvotOrder(String bodyJson) throws Exception {
        return toResponse(doPost("IVRServices/CreateMVOTOrder", bodyJson));
    }
    public BannerResponse updateStopService(String bodyJson) throws Exception {
        return toResponse(doPost("Payment/UpdateStopService", bodyJson));
    }
}
