
package com.avaya.ept.onegas.bl.model;

public class VDNValue {
	String vdn = null;
	String transferDestination = null;
	String transferAdditional = null;

	public VDNValue(String vdn, String transferDestination, String transferAdditional) {
		super();
		this.vdn = vdn;
		this.transferDestination = transferDestination;
		this.transferAdditional = transferAdditional;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((vdn == null) ? 0 : vdn.hashCode());
		result = prime * result + ((transferDestination == null) ? 0 : transferDestination.hashCode());
		result = prime * result + ((transferAdditional == null) ? 0 : transferAdditional.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VDNKey other = (VDNKey) obj;
		if (vdn == null) {
			if (other.language != null)
				return false;
		} else if (!vdn.equals(other.language))
			return false;
		if (transferDestination == null) {
			if (other.location != null)
				return false;
		} else if (!transferDestination.equals(other.location))
			return false;
		if (transferAdditional == null) {
			if (other.transferType != null)
				return false;
		} else if (!transferAdditional.equals(other.transferType))
			return false;
		return true;
	}

	public String getVdn() {
		return vdn;
	}

	public String getTransferDestination() {
		return transferDestination;
	}

	public String getTransferAdditional() {
		return transferAdditional;
	}

	@Override
	public String toString() {
		return "VDNValue [vdn=" + vdn + ", transferDestination=" + transferDestination + ", transferAdditional="
				+ transferAdditional + "]";
	}

}
