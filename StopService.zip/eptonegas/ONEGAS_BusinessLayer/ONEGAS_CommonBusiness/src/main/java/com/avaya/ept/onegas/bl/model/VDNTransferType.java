package com.avaya.ept.onegas.bl.model;

public enum VDNTransferType {
	ACCT_INFO,
	EMERGENCY,
	NEW_SERVICE,
	IVR_DEFAULT,
	LETTER,
	PAYMENTS,
	SERV_ORDER,
	
	// Below Properties were added by CAS team in-regards to fix SR#1-12687541331 reported by Customer. 	
	START_SERV,
	STOP_SERV,
	
	// 2019-02-11 | TS-WTI | New transfers "TRANS_SERV", "APP_REJECT", "NOT_VALIDATED" per SOW
	TRANS_SERV,
	APP_REJECT,
	NOT_VALIDATED,
	BILL_OPTIONS,
	BILL_STATEMENT,
	CREDIT_REF,
	OTHER,
	PAPERLESS,
	MTRREAD,
	STW, PAY_CHK, PAY_BY_CCDC, PAY_LOCS, MEMO, HDN_DISP, PUBL_AUTH, INFO_CNTR, BUDGET, BNK_DFT, VFP, PAY_ARRANGE, CC_PAYMENT, PAY_ARR_OPT, PAY_ARR_INEL,
	
	// 2021-10-13 | New "SERVICE_APPT", "TX_HOS_Market", "OK_HOS_Market", "Reconnect", "START_Res", "START_HOS" and "START_COM" 
	// variables added as per ONEGas Phase 2 changes
	SERVICE_APPT, TX_HOS_Market, OK_HOS_Market, Reconnect, START_Res, START_HOS, START_COM,
	
	//2024-01-30 AMHS_Changes | New "AMHS_START" , "AMHS_PAID"
	AMHS_START, AMHS_PAID
	
}