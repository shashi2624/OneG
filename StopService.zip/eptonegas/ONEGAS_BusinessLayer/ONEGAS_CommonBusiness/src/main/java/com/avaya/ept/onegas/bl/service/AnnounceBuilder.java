/*
 * AnnounceBuilder.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */

package com.avaya.ept.onegas.bl.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.avaya.ept.onegas.bl.model.AnnounceValueMode;
import com.avaya.ept.onegas.bl.model.AnnounceValueSSMode;

/**
 * @author javantario
 * 
 */
public class AnnounceBuilder {

	private static final String SS = "SS";
	private static final String TTS = "TTS";
	private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	private List<AnnounceParameter> announces = new ArrayList<AnnounceParameter>();

	/**
	 * Adds an announce
	 * 
	 * @param announce
	 */
	public void add(String announce) {
		announces.add(new AnnounceParameter(announce, null, null));
	}

	/**
	 * Adds a value to reproduce in a certain mode (TTS or SS)
	 * 
	 * @param value
	 * @param mode
	 */
	public void addValue(String value, AnnounceValueMode mode) {
		announces.add(new AnnounceParameter(null, value, mode));
	}

	/**
	 * Adds an announce and a value to reproduce in a certain mode (TTS or SS)
	 * 
	 * @param announce
	 * @param value
	 * @param mode
	 */
	public void add(String announce, String value, AnnounceValueMode mode) {
		announces.add(new AnnounceParameter(announce, value, mode));
	}

	/**
	 * @return
	 */
	public String getAnnouncement() {

		StringBuffer announcement = new StringBuffer();

		for (AnnounceParameter announceParameter : announces) {

			if (announceParameter.getAnnounce() != null) {
				announcement.append(announceParameter.getAnnounce()).append("*");
			}
			if (announceParameter.getValue() != null) {
				if (announceParameter.getMode() instanceof AnnounceValueSSMode) {
					announcement.append(SS).append(":");
					announcement.append(announceParameter.getValue()).append(":");
					announcement.append(announceParameter.getMode().value()).append("*");
				} else {
					announcement.append(TTS).append(":");
					announcement.append(announceParameter.getValue()).append(":");
					announcement.append(announceParameter.getMode().value()).append("*");
				}
			}
		}

		return announcement.length() == 0 ? announcement.toString() : announcement.substring(0, announcement.length() - 1);

	}

	public void add(String announce, Date date, AnnounceValueMode value) {
		announces.add(new AnnounceParameter(announce, dateFormat.format(date), value));
	}

	public void addValue(Date date, AnnounceValueMode value) {
		announces.add(new AnnounceParameter(null, dateFormat.format(date), value));
	}
}

class AnnounceParameter {

	private String announce = null;
	private String value = null;
	private AnnounceValueMode mode = null;

	AnnounceParameter(String announce, String value, AnnounceValueMode mode) {
		super();
		this.announce = announce;
		this.value = value;
		this.mode = mode;
	}

	/**
	 * @return the announce
	 */
	public String getAnnounce() {
		return announce;
	}


	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}


	/**
	 * @return the mode
	 */
	public AnnounceValueMode getMode() {
		return mode;
	}

}