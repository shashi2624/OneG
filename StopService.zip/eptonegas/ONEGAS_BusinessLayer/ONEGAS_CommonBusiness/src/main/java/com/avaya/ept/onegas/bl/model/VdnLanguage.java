package com.avaya.ept.onegas.bl.model;

import com.avaya.ept.onegas.bl.service.ODLogger;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class VdnLanguage {
    
    private static final HikariDataSource dataSource;
    private static final String query;  // Now final to prevent accidental modifications

    static {
        Properties properties = new Properties();
        
        try (InputStream input = VdnLanguage.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (input == null) {
                throw new RuntimeException("### config.properties file not found in classpath ###");
            }
            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException("### Error loading database properties: " + e.getMessage(), e);
        }

        // Prevent NullPointerException by setting a default query
        query = properties.getProperty("VdnLanguageQuery", "SELECT LANGUAGE FROM dbo.I3_VDN_Language WHERE VDN_Number = ?");

        // Initialize HikariCP using values from properties
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(properties.getProperty("db.url"));
        config.setUsername(properties.getProperty("db.username"));
        config.setPassword(properties.getProperty("db.password"));
        config.setMinimumIdle(Integer.parseInt(properties.getProperty("db.minimumIdle", "10")));
        config.setMaximumPoolSize(Integer.parseInt(properties.getProperty("db.maximumPoolSize", "100")));
        config.setConnectionTimeout(Long.parseLong(properties.getProperty("db.connectionTimeout", "3000")));

        dataSource = new HikariDataSource(config);

        // Register shutdown hook for proper cleanup
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (dataSource != null) {
                dataSource.close();
                ODLogger.logDebug(null, "### HikariDataSource shutdown successful ###");
            }
        }));
    }

    // Singleton instance to avoid unnecessary object creation
    private static final VdnLanguage instance = new VdnLanguage();

    private VdnLanguage() {}  // Private constructor to prevent instantiation

    public static VdnLanguage getInstance() {
        return instance;
    }

    public String getLanguageForVdn(CallData callData, String vdnNumber) {
    	
    	ODLogger.logDebug(callData.getSceSession(), "### Inside VdnLanguage : " + vdnNumber);
        
        ODLogger.logDebug(callData.getSceSession(), "### VdnLanguage Query ### " + query);
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setString(1, vdnNumber);

            ODLogger.logDebug(callData.getSceSession(), "### DB connection successful ### ");
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String language = rs.getString("Language");
                    ODLogger.logDebug(callData.getSceSession(), "### Successfully got Language: " + language);
                    return language;
                }
            }
        } catch (SQLException e) {
            ODLogger.logError(callData.getSceSession(), "### Exception at VdnLanguage ###", e);
        }
        return null;
    }
    
}
