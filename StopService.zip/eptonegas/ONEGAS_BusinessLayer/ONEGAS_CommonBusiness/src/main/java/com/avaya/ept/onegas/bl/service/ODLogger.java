/*
 * ODLogger.java
 *
 * Avaya Inc. - Proprietary (Restricted)
 * Solely for authorized persons having a need to know
 * pursuant to Company instructions.
 *
 * Copyright © 2008-2016 Avaya Inc. All rights reserved.
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
 * The copyright notice above does not evidence any actual
 * or intended publication of such source code.
 */
package com.avaya.ept.onegas.bl.service;

import com.avaya.ept.onegas.bl.model.CallData;
import com.avaya.ept.onegas.bl.model.Constants;
import com.avaya.ept.onegas.bl.model.Field;
import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.SCESession;

/**
 * @author dalbani
 * 
 */
public final class ODLogger {

	public static final String ONEGAS_CALLFLOW = "OneGas CallFlow";

	/** Constructor **/
	private ODLogger() {
	}

	/**
	 * Logs the given message in Debug level
	 * 
	 * @param mySession
	 *            The session this log should be attached to
	 * @param strToLog
	 *            The string to log
	 */
	public static void logDebug(SCESession mySession, String strToLog) {
		if (mySession != null) {
			log(mySession, ITraceInfo.TRACE_LEVEL_DEBUG, strToLog);
		}
	}

	/**
	 * Logs the given message in Error level
	 * 
	 * @param mySession
	 *            The session this log should be attached to
	 * @param strToLog
	 *            The string to log
	 */
	public static void logError(SCESession mySession, String strToLog) {
		if (mySession != null) {

			log(mySession, ITraceInfo.TRACE_LEVEL_ERROR, strToLog);
		}
	}

	/**
	 * Logs the given message in Error level including detailed information
	 * related to a thrown exception
	 * 
	 * @param mySession
	 *            The session this log should be attached to
	 * @param strToLog
	 *            The string to log
	 * @param e
	 *            The exception that was thrown
	 */
	public static void logError(SCESession mySession, String strToLog, Throwable e) {
		if (mySession != null) {
			log(mySession, ITraceInfo.TRACE_LEVEL_ERROR, strToLog);
			log(mySession, ITraceInfo.TRACE_LEVEL_ERROR, getDetailedTrace(e));
		}
	}

	/**
	 * Logs the given message in Warning level
	 * 
	 * @param mySession
	 *            The session this log should be attached to
	 * @param strToLog
	 *            The string to log
	 */
	public static void logWarning(SCESession mySession, String strToLog) {
		if (mySession != null) {
			log(mySession, ITraceInfo.TRACE_LEVEL_WARN, strToLog);
		}
	}

	/**
	 * Logs the given message in Info level
	 * 
	 * @param mySession
	 *            The session this log should be attached to
	 * @param strToLog
	 *            The string to log
	 */
	public static void logInfo(SCESession mySession, String strToLog) {
		if (mySession != null) {
			log(mySession, ITraceInfo.TRACE_LEVEL_INFO, strToLog);
		}
	}

	/**
	 * 
	 * @param mySession
	 *            The session this log should be attached to
	 * @param traceLevel
	 *            The trace level to be used
	 * @param strToLog
	 *            The string to log
	 */
	private static void log(SCESession mySession, int traceLevel, String strToLog) {
		if (mySession != null && mySession.isAppTraceEnabled()) {
			try {
				mySession.getTraceOutput().writeln(traceLevel, strToLog);
			} catch (RuntimeException e) {
				logError(mySession, "### ERROR while attempting to log for OD.", e);
			}
		}
	}

	/**
	 * Reports the given message in Info level with the Start key
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 */
	public static void reportStart(SCESession mySession, String activityName, String strToReport) {
		if (mySession != null) {
			report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_START_TRANS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_INFO, activityName, strToReport);
		}
	}

	/**
	 * Reports the given message in Info level with the Start key, including a
	 * variable's content
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 * @param variableName
	 *            The variable's name to include in the report
	 * @param variableValue
	 *            The variable's value to include in the report
	 */
	public static void reportStart(SCESession mySession, String activityName, String strToReport, String variableName, String variableValue) {
		if (mySession != null) {
			report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_START_TRANS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_INFO, activityName, strToReport, variableName, variableValue);
		}
	}

	/**
	 * Reports the given message in Info level with the Progress key
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 */
	public static void reportProgressError(SCESession mySession, String activityName, String strToReport) {
		if (mySession != null) {
			report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_PROGRESS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_MAJOR, activityName, strToReport);
		}
	}

	/**
	 * Reports the given message in Info level with the Progress key, including
	 * a variable's content
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 * @param variableName
	 *            The variable's name to include in the report
	 * @param variableValue
	 *            The variable's value to include in the report
	 */
	public static void reportProgressError(SCESession mySession, String activityName, String strToReport, String variableName, String variableValue) {
		if (mySession != null) {
			report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_PROGRESS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_MAJOR, activityName, strToReport, variableName, variableValue);
		}
	}

	/**
	 * Reports the given message in Info level with the Progress key
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 */
	public static void reportProgress(SCESession mySession, String activityName, String strToReport) {
		if (mySession != null) {
			report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_PROGRESS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_INFO, activityName, strToReport);
		}
	}

	/**
	 * Reports the given message in Info level with the Progress key, including
	 * a variable's content
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 * @param variableName
	 *            The variable's name to include in the report
	 * @param variableValue
	 *            The variable's value to include in the report
	 */
	public static void reportProgress(SCESession mySession, String activityName, String strToReport, String variableName, String variableValue) {
		if (mySession != null) {
			report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_PROGRESS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_INFO, activityName, strToReport, variableName, variableValue);
			CallData callData = (CallData) mySession.getProperty(Constants.CALL_DATA);
			callData.setField(Field.LAST_STATE, activityName);
//			String contextId = callData.getField(Field.CONTEXT_ID);
//			if (!"".equalsIgnoreCase(contextId)) {
//				String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
//				Map<String, String> contextBodyMap = new HashMap<String, String>();
//				contextBodyMap.put("calltime", timeStamp);
//				Map<String, String> params = new HashMap<String, String>();
//				params.put("lease", callData.getCAV(CAV.CS_LeaseTime));
//				params.put("touchpoint", activityName);
//				params.put("rid", callData.getCAV(CAV.CS_RID));
//				ONEGASContext.getContextStoreService().updateContextStoreWithParams(contextId, contextBodyMap, params, true);
				// String customerJourney =
				// callData.getField(Field.CUSTOMER_JOURNEY);
				// callData.setField(Field.CUSTOMER_JOURNEY,
				// customerJourney+","+activityName);
//			}

		}
	}

	/**
	 * Reports the given message in Info level with the End key
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 */
	public static void reportEnd(SCESession mySession, String activityName, String strToReport) {
		report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_END_TRANS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_INFO, activityName, strToReport);
	}

	/**
	 * Reports the given message in Info level with the End key, including a
	 * variable's content
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 * @param variableName
	 *            The variable's name to include in the report
	 * @param variableValue
	 *            The variable's value to include in the report
	 */
	public static void reportEnd(SCESession mySession, String activityName, String strToReport, String variableName, String variableValue) {
		report(mySession, com.avaya.sce.runtimecommon.IReportInfo.REPORT_TYPE_END_TRANS, com.avaya.sce.runtimecommon.IReportInfo.ALARM_LEVEL_INFO, activityName, strToReport, variableName, variableValue);
	}

	/**
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 */
	private static void report(SCESession mySession, String reportType, String alarmLevel, String activityName, String strToReport) {
		report(mySession, reportType, alarmLevel, activityName, strToReport, "", "");
	}

	/**
	 * 
	 * @param mySession
	 *            The session this report should be attached to
	 * @param activityName
	 *            The activity name associated with this report
	 * @param strToReport
	 *            The string to report
	 * @param variableName
	 *            The variable's name to include in the report
	 * @param variableValue
	 *            The variable's value to include in the report
	 */
	private static void report(SCESession mySession, String reportType, String alarmLevel, String activityName, String strToReport, String variableName, String variableValue) {
		if (mySession != null) {

			try {
				logInfo(mySession,"Report: |Type:" + reportType + " |Alarm:" + alarmLevel + " |Activity:" + activityName + " |Message:" + strToReport + " |Variable:" + variableName + " |Value:" + variableValue);
				mySession.getReportOutput().report(alarmLevel, reportType, activityName, strToReport, variableName, variableValue);
			} catch (RuntimeException e) {
				logError(mySession,"### ERROR while attempting to report for OD.", e);
			}
		}
	}

	/**
	 * Obtains detailed information of the exception, including the message, the
	 * cause and the full stack trace
	 * 
	 * @param e
	 *            The exception being thrown
	 * @return String containing details of the exception
	 */
	/**
	 * Obtains detailed information of the exception, including the message, the
	 * cause and the full stack trace
	 * 
	 * @param e
	 *            The exception being thrown
	 * @return String containing details of the exception
	 */
	private static String getDetailedTrace(Throwable e) {
		String lineSep = System.getProperty("line.separator");
		String msg = lineSep;

		msg += " :: Message :: " + e.getMessage() + lineSep;
		msg += " :: Cause :: " + e.getCause() + lineSep;
		return msg;
	}

}
