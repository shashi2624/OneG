
/*
* Constants.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/
package com.avaya.ept.onegas.bl.model;

public final class Constants {

	/** Private Constructor **/
	private Constants() {
	}

	public static final String APPNAME_MAIN = "MAIN";

	public static final String CALL_DATA = "CallData";
	public static final String UPS_CONFIG_FILE = "onegas.config.properties";
	public static final String RAM_GLOBAL_PROPERTIES = "onegas.global.properties";
	public static final String RDM_GLOBAL_PROPERTIES = "onegas.global.properties";

	/** language {English, Spanish} **/
	public static final String LANGUAGE_ENGLISH = "ENGLISH";
	public static final String LANGUAGE_SPANISH = "SPANISH";
	public static final String URL_SEPARATOR = "/";

	/** transfer Types */
	public static final String TRANSFER_AGENT 		= "agent";
	public static final String TRANSFER_MAINMENU 	= "mainmenu";
	public static final String TRANSFER_HANGUP 		= "hangup";
	
	
	public static final String TRUE = "true";
	public static final String FALSE = "false";

	
	public static final String DATE_FORMAT 			= "MMddyyyy";
	public static final String DATE_FORMAT_YYYYMMDD 	= "yyyyMMdd";
	

	/**
	 * RDM Latest Dialog Result count
	 */
	public static final String AGENT 		= "AGENT";
	public static final String NOINPUT 		= "NOINPUT";
	public static final String NOMATCH 		= "NOMATCH";
	public static final String NEGATIVECONF = "NEGATIVECONF";
	public static final String RDM_LATEST_DIALOG = "RDM.latestDialog";
	public static final String RDM_LATEST_DIALOG_RESULT = "RDM.latestDialogResult";

	public static final String TIME_FORMAT = "HHmm";

	public static final String OK = "ok";
	public static final String TX = "tx";
	public static final String KS = "ks";
	
	public static final String ONG = "ong";
	public static final String TGS = "tgs";
	public static final String KGS = "kgs";

	
	public static final String SUCCESS = "SUCCESS";

	public static final String STOP = "stop";
	public static final String ENROUTE = "ENROUTE";
	public static final String ON_SITE = "ON-SITE";
	public static final String ACCOUNT_SUMMARY = "AccountSummary";

	public static final String ACTIVE = "Active";

	public static final String ALTERNATIVE_DATE = "alt_date";

	public static final String METER_ERROR = "meter_error";
	public static final String METER_AGENT = "meter_agent";
	public static final String METER_CONFIRM = "meter_confirm";

	public static final String MAIN_MENU = "main_menu";
	
	public static final String TRANSFER_TYPE_NCO="nco";
	public static final String TRANSFER_TYPE_DEFAULT="default";
	public static final String TRANSFER_TYPE_OFFICE_OPEN="office_open";
	public static final String TRANSFER_TYPE_NO_TNR="no_tnr";
	public static final String TRANSFER_TYPE_TNR="tnr";
	public static final String TRANSFER_TYPE_SERVICE_EXCEPTION="service_exception";
	public static final String TRANSFER_TYPE_HANGUP = "hangup";
	public static final String TRANSFER_TYPE_NOT_VALIDATED = "NOT_VALIDATED";

	public static final String MORE_LOCS = "more_locs";

	public static final String SPANISH = "spanish";


}
