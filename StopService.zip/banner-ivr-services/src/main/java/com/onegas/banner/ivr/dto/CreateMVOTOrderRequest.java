package com.onegas.banner.ivr.dto;

public class CreateMVOTOrderRequest {

    private String extSystem = "IVR";
    private String accountNum;
    private String serviceOrderType = "MVOT";
    private String requestedDate;
    private String appointmentWindow;
    private String appointmentConfirmNum;
    private boolean createOrder = true;
    private String notes;
    private boolean applianceMoveInd;

    public String getExtSystem() {
        return extSystem;
    }

    public CreateMVOTOrderRequest setExtSystem(String v) {
        this.extSystem = v;
        return this;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public CreateMVOTOrderRequest setAccountNum(String v) {
        this.accountNum = v;
        return this;
    }

    public String getServiceOrderType() {
        return serviceOrderType;
    }

    public CreateMVOTOrderRequest setServiceOrderType(String v) {
        this.serviceOrderType = v;
        return this;
    }

    public String getRequestedDate() {
        return requestedDate;
    }

    public CreateMVOTOrderRequest setRequestedDate(String v) {
        this.requestedDate = v;
        return this;
    }

    public String getAppointmentWindow() {
        return appointmentWindow;
    }

    public CreateMVOTOrderRequest setAppointmentWindow(String v) {
        this.appointmentWindow = v;
        return this;
    }

    public String getAppointmentConfirmNum() {
        return appointmentConfirmNum;
    }

    public CreateMVOTOrderRequest setAppointmentConfirmNum(String v) {
        this.appointmentConfirmNum = v;
        return this;
    }

    public boolean isCreateOrder() {
        return createOrder;
    }

    public CreateMVOTOrderRequest setCreateOrder(boolean v) {
        this.createOrder = v;
        return this;
    }

    public String getNotes() {
        return notes;
    }

    public CreateMVOTOrderRequest setNotes(String v) {
        this.notes = v;
        return this;
    }

    public boolean getApplianceMoveInd() {
        return applianceMoveInd;
    }

    public CreateMVOTOrderRequest setApplianceMoveInd(boolean v) {
        this.applianceMoveInd = v;
        return this;
    }
}
