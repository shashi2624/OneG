package com.onegas.banner.ivr.service;

import com.onegas.banner.ivr.config.BannerApiConfig;
import com.onegas.banner.ivr.dto.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Java 1.8 Banner API client that returns raw JSON strings for IVR. */
public class BannerService {
    private final BannerApiConfig cfg;
    private volatile String token;
    private volatile long tokenExpiryMs;

    public BannerService(BannerApiConfig cfg) {
        if (cfg == null) throw new IllegalArgumentException("cfg required");
        if (cfg.getBaseUrl() == null) throw new IllegalArgumentException("cfg.baseUrl required");
        if (cfg.getDistributionCompany() == null) throw new IllegalArgumentException("cfg.distributionCompany required");
        this.cfg = cfg;
    }

    // ========== Public API: returns full JSON (as String) ==========
 // ========= Public API: returns full JSON (as String) =========

    public String moveInOutPrecheck(PrecheckRequest req) throws Exception {
        String json = String.format(
            "{\"extSystem\":\"%s\",\"origin\":\"%s\",\"accountNum\":\"%s\",\"serviceOrderType\":\"%s\",\"requestedDate\":\"%s\"}",
            req.getExtSystem(), req.getOrigin(), req.getAccountNum(), req.getServiceOrderType(), req.getRequestedDate()
        );
        return postWithDist("IVRServices/MoveInOutPrecheck", json);
    }

    public String getApptAvailability(ApptAvailabilityRequest req) throws Exception {
        String json = String.format(
            "{\"extSystem\":\"%s\",\"origin\":\"%s\",\"accountNum\":\"%s\",\"serviceOrderType\":\"%s\",\"requestedDate\":\"%s\",\"appointmentType\":\"%s\"}",
            req.getExtSystem(), req.getOrigin(), req.getAccountNum(), req.getServiceOrderType(), req.getRequestedDate(), req.getAppointmentType()
        );
        System.out.println("getApptAvailability POST JSON: " + json);
        return postWithDist("IVRServices/GetApptAvailability", json);
    }

    public String reserveAppointment(ReserveAppointmentRequest req) throws Exception {
        String json = String.format(
            "{\"extSystem\":\"%s\",\"accountNum\":\"%s\",\"serviceOrderType\":\"%s\",\"requestedDate\":\"%s\",\"appointmentWindow\":\"%s\",\"eventCode\":\"%s\"}",
            req.getExtSystem(), req.getAccountNum(), req.getServiceOrderType(), req.getRequestedDate(), req.getAppointmentWindow(), req.getEventCode()
        );
        return postWithDist("IVRServices/ReserveAppointment", json);
    }

	/*
	 * public String createMVOTOrder(CreateMVOTOrderRequest req) throws Exception {
	 * String json = String.format(
	 * "{\"extSystem\":\"%s\",\"accountNum\":\"%s\",\"serviceOrderType\":\"%s\",\"requestedDate\":\"%s\",\"appointmentWindow\":\"%s\",\"appointmentConfirmNum\":\"%s\",\"createOrder\":%s}",
	 * req.getExtSystem(), req.getAccountNum(), req.getServiceOrderType(),
	 * req.getRequestedDate(), req.getAppointmentWindow(),
	 * req.getAppointmentConfirmNum(), String.valueOf(req.isCreateOrder()) ); return
	 * postWithDist("IVRServices/CreateMVOTOrder", json); }
	 */
    
    
    
    public String createMVOTOrder(CreateMVOTOrderRequest req) throws Exception {
    	
    	String expectedJson = String.format(
        	    "{\"extSystem\":\"%s\",\"accountNum\":\"%s\",\"serviceOrderType\":\"%s\"," +
        	    "\"requestedDate\":\"%s\",\"appointmentWindow\":\"%s\"," +
        	    "\"appointmentConfirmNum\":\"%s\",\"createOrder\":\"%s\"}",
        	    "IVR","5102636831235396","MVOT","03-SEP-2025","AM","AVAIL-0011941321","Y"
        	);
        	System.out.println("CreateMVOTOrder EXPECTED JSON: " + expectedJson);
    	
    	
        // Convert boolean to the exact string the API expects: "Y" or "N"
        String createOrderStr = req.isCreateOrder() ? "Y" : "N";
        String applianceMoveInd = req.getApplianceMoveInd() ? "Y" : "N";

        String json = String.format(
            "{\"extSystem\":\"%s\",\"accountNum\":\"%s\",\"serviceOrderType\":\"%s\"," +
            "\"requestedDate\":\"%s\",\"appointmentWindow\":\"%s\"," +
            "\"appointmentConfirmNum\":\"%s\",\"createOrder\":\"%s\"}",   // <-- quoted and Y/N
            req.getExtSystem(), req.getAccountNum(), req.getServiceOrderType(),
            req.getRequestedDate(), req.getAppointmentWindow(),
            req.getAppointmentConfirmNum(), createOrderStr,req.getNotes(),applianceMoveInd
        );
        System.out.println("CreateMVOTOrder POST JSON: " + json);
        return postWithDist("IVRServices/CreateMVOTOrder", json);
    }
    

    public String updateStopService(UpdateStopServiceRequest req) throws Exception {
        String json = String.format(
            "{\"serviceOrderNumber\": %s, \"tempDiscFeeConsentInd\": %s, \"externalSystem\": \"%s\"}",
            String.valueOf(req.getServiceOrderNumber()), String.valueOf(req.isTempDiscFeeConsentInd()), req.getExternalSystem()
        );
        return postWithDist("Payment/UpdateStopService", json);
    }


    // ========== Low-level HTTP helpers (Java 1.8) ==========
    private void ensureToken() throws Exception {
        long now = System.currentTimeMillis();
        if (token != null && now < tokenExpiryMs) return;

        String url = cfg.getBaseUrl() + "Accounts/GetAuthorizationToken";
        String body = httpPost(url, null, "{}");

        // regex:  "token" : "...."
        String t = extract(body, "\\\"token\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
        if (t == null) {
            throw new RuntimeException("Token not found in response: " + body);
        }
        token = t;
        tokenExpiryMs = now + 55 * 60 * 1000L; // ~55 minutes
    }


    private String postWithDist(String path, String json) throws Exception {
        ensureToken();
        String url = cfg.getBaseUrl() + path + "?distributionCompany=" + cfg.getDistributionCompany();
        return httpPost(url, "Bearer " + token, json);
    }

    private String httpPost(String url, String bearer, String json) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(cfg.getConnectTimeoutMs());
        conn.setReadTimeout(cfg.getReadTimeoutMs());
        conn.setRequestProperty("Content-Type", "application/json");
        if (bearer != null) conn.setRequestProperty("Authorization", bearer);

        // Always be explicit about output; write zero-length body when json is null/empty
        conn.setDoOutput(true);

        if (json != null && !json.isEmpty()) {
            byte[] data = json.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(data.length);  // sets Content-Length
            try (java.io.OutputStream os = conn.getOutputStream()) {
                os.write(data);
            }
        } else {
            conn.setFixedLengthStreamingMode(0);            // Content-Length: 0
            try (java.io.OutputStream os = conn.getOutputStream()) {
                // write nothing; just close to finalize the request
            }
        }

        int status = conn.getResponseCode();
        java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(
            status >= 200 && status < 300 ? conn.getInputStream() : conn.getErrorStream(),
            java.nio.charset.StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        return sb.toString();
    }


    private static String extract(String src, String regex) {
        Matcher m = Pattern.compile(regex).matcher(src);
        return m.find() ? m.group(1) : null;
    }
}