package com.onegas.banner.ivr.dto;

public class PrecheckRequest {

    private String extSystem = "IVR";
    private String origin = "";
    private String accountNum;
    private String serviceOrderType = "MVOT";
    private String requestedDate;

    public String getExtSystem() {
        return extSystem;
    }

    public PrecheckRequest setExtSystem(String v) {
        this.extSystem = v;
        return this;
    }

    public String getOrigin() {
        return origin;
    }

    public PrecheckRequest setOrigin(String v) {
        this.origin = v;
        return this;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public PrecheckRequest setAccountNum(String v) {
        this.accountNum = v;
        return this;
    }

    public String getServiceOrderType() {
        return serviceOrderType;
    }

    public PrecheckRequest setServiceOrderType(String v) {
        this.serviceOrderType = v;
        return this;
    }

    public String getRequestedDate() {
        return requestedDate;
    }

    public PrecheckRequest setRequestedDate(String v) {
        this.requestedDate = v;
        return this;
    }
}
