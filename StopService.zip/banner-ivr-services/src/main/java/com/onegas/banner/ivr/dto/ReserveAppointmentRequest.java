package com.onegas.banner.ivr.dto;
public class ReserveAppointmentRequest {
    private String extSystem = "IVR";
    private String accountNum;
    private String serviceOrderType = "MVOT";
    private String requestedDate;
    private String appointmentWindow;
    private String eventCode;

    public String getExtSystem(){return extSystem;}
    public ReserveAppointmentRequest setExtSystem(String v){this.extSystem=v;return this;}
    public String getAccountNum(){return accountNum;}
    public ReserveAppointmentRequest setAccountNum(String v){this.accountNum=v;return this;}
    public String getServiceOrderType(){return serviceOrderType;}
    public ReserveAppointmentRequest setServiceOrderType(String v){this.serviceOrderType=v;return this;}
    public String getRequestedDate(){return requestedDate;}
    public ReserveAppointmentRequest setRequestedDate(String v){this.requestedDate=v;return this;}
    public String getAppointmentWindow(){return appointmentWindow;}
    public ReserveAppointmentRequest setAppointmentWindow(String v){this.appointmentWindow=v;return this;}
    public String getEventCode(){return eventCode;}
    public ReserveAppointmentRequest setEventCode(String v){this.eventCode=v;return this;}
}