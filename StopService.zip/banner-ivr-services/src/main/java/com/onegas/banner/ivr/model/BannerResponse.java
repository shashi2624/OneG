package com.onegas.banner.ivr.model;

public class BannerResponse {
    private boolean successful;
    private String responseMessage;
    private String responseData;

    public boolean isSuccessful() { return successful; }
    public BannerResponse setSuccessful(boolean successful) { this.successful = successful; return this; }

    public String getResponseMessage() { return responseMessage; }
    public BannerResponse setResponseMessage(String responseMessage) { this.responseMessage = responseMessage; return this; }

    public String getResponseData() { return responseData; }
    public BannerResponse setResponseData(String responseData) { this.responseData = responseData; return this; }
}