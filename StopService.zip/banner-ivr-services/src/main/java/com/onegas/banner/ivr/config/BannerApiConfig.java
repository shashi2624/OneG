package com.onegas.banner.ivr.config;

public class BannerApiConfig {
    private String baseUrl;
    private String distributionCompany;
    private int connectTimeoutMs = 10000;
    private int readTimeoutMs = 20000;

    public String getBaseUrl() { return baseUrl; }
    public BannerApiConfig setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl : baseUrl + "/";
        return this;
    }

    public String getDistributionCompany() { return distributionCompany; }
    public BannerApiConfig setDistributionCompany(String distributionCompany) {
        this.distributionCompany = distributionCompany;
        return this;
    }

    public int getConnectTimeoutMs() { return connectTimeoutMs; }
    public BannerApiConfig setConnectTimeoutMs(int connectTimeoutMs) {
        this.connectTimeoutMs = connectTimeoutMs;
        return this;
    }

    public int getReadTimeoutMs() { return readTimeoutMs; }
    public BannerApiConfig setReadTimeoutMs(int readTimeoutMs) {
        this.readTimeoutMs = readTimeoutMs;
        return this;
    }
}