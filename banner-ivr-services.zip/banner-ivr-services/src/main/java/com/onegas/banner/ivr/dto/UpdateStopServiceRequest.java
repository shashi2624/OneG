package com.onegas.banner.ivr.dto;
public class UpdateStopServiceRequest {
    private long serviceOrderNumber;
    private boolean tempDiscFeeConsentInd;
    private String externalSystem = "IVR";

    public long getServiceOrderNumber(){return serviceOrderNumber;}
    public UpdateStopServiceRequest setServiceOrderNumber(long v){this.serviceOrderNumber=v;return this;}
    public boolean isTempDiscFeeConsentInd(){return tempDiscFeeConsentInd;}
    public UpdateStopServiceRequest setTempDiscFeeConsentInd(boolean v){this.tempDiscFeeConsentInd=v;return this;}
    public String getExternalSystem(){return externalSystem;}
    public UpdateStopServiceRequest setExternalSystem(String v){this.externalSystem=v;return this;}
}