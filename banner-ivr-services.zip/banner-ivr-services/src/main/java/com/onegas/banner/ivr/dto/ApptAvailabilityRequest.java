package com.onegas.banner.ivr.dto;
public class ApptAvailabilityRequest {
    private String extSystem = "IVR";
    private String origin = "";
    private String accountNum;
    private String serviceOrderType = "MVOT";
    private String requestedDate;
    private String appointmentType;

    public String getExtSystem(){return extSystem;}
    public ApptAvailabilityRequest setExtSystem(String v){this.extSystem=v;return this;}
    public String getOrigin(){return origin;}
    public ApptAvailabilityRequest setOrigin(String v){this.origin=v;return this;}
    public String getAccountNum(){return accountNum;}
    public ApptAvailabilityRequest setAccountNum(String v){this.accountNum=v;return this;}
    public String getServiceOrderType(){return serviceOrderType;}
    public ApptAvailabilityRequest setServiceOrderType(String v){this.serviceOrderType=v;return this;}
    public String getRequestedDate(){return requestedDate;}
    public ApptAvailabilityRequest setRequestedDate(String v){this.requestedDate=v;return this;}
    public String getAppointmentType(){return appointmentType;}
    public ApptAvailabilityRequest setAppointmentType(String v){this.appointmentType=v;return this;}
}