/*
 * package com.onegas.banner.ivr;
 * 
 * import com.onegas.banner.ivr.config.BannerApiConfig; import
 * com.onegas.banner.ivr.dto.PrecheckRequest; import
 * com.onegas.banner.ivr.service.BannerService; import org.junit.Test;
 * 
 * public class SmokeTest {
 * 
 * @Test public void test() throws Exception { BannerApiConfig cfg = new
 * BannerApiConfig() .setBaseUrl("http://test") .setDistributionCompany("OK");
 * 
 * BannerService svc = new BannerService(cfg);
 * 
 * // Since the service returns raw JSON, we'll get a String String json =
 * svc.moveInOutPrecheck( new PrecheckRequest().setAccountNum("123") );
 * 
 * // Example assertion: just check JSON contains a certain key // (replace with
 * expected field from your test environment) assert json != null &&
 * json.contains("isSuccessful"); } }
 */