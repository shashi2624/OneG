package com.avaya.ept.onegas.ws.location.exception;

/**
 * 
 * @author schmidt0
 * 
 */
public class LocationClientServiceException extends Exception{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5341479083419754611L;
	private int statusCode;
	public LocationClientServiceException() {
	}

	/**
	 * @param message
	 */
	public LocationClientServiceException(String message) {
		super(message);

	}

	/**
	 * @param cause
	 */
	public LocationClientServiceException(Throwable cause) {
		super(cause);

	}

	/**
	 * @param message
	 * @param cause
	 */
	public LocationClientServiceException(String message, Throwable cause) {
		super(message, cause);
	}
	/**
	 * @param message
	 */
	public LocationClientServiceException(String message, int statusCode) {
		super(message);
		setStatusCode(statusCode);
	}
	
	/**
	 * @param cause
	 */
	public LocationClientServiceException(Throwable cause, int statusCode) {
		super(cause);
		setStatusCode(statusCode);
		
	}
	
	/**
	 * @param message
	 * @param cause
	 */
	public LocationClientServiceException(String message, Throwable cause, int statusCode) {
		super(message, cause);
		setStatusCode(statusCode);
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

}
