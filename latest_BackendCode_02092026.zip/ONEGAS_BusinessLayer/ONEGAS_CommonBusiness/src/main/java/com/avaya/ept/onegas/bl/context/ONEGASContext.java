
/*
* ONEGASContext.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/
package com.avaya.ept.onegas.bl.context;



import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.avaya.ept.onegas.backend.contextstore.types.ContextStoreService;
import com.avaya.ept.onegas.bl.service.IONEGASCommonService;
import com.avaya.ept.onegas.bl.service.VDNTransferService;


/**
 * @author schmidt0
 *	This class is a singleton class to provide an stand-alone access to
 *	Spring ApplicationContainer in a hidden way.
 */
public final class ONEGASContext {

	  /** ContextBase's Logger */
    private static Logger log = Logger.getLogger(ONEGASContext.class);

    /** Spring ContextBase Configuration File */
    private static final String CONTEXTCONFIG = "classpath:onegasCommonBusinessContext.xml";
    /** Singleton instance field */
    private static ONEGASContext instance = new ONEGASContext();
    /** holder of the business layer beans that we let access to */
    private Holder holder;
    /** Spring Application ctx */
    private ApplicationContext ctx;
    
    /**
	 * 
	 */
    private ONEGASContext() {
		log.info("Initializing Spring ContextBase");
		log.info(System.getProperty("java.class.path"));
		this.ctx = new ClassPathXmlApplicationContext(CONTEXTCONFIG);
		log.info("Spring context initializing ok");
		this.holder = (Holder) this.ctx.getBean("onegasCommonHolder");
    }


    /**
     * @param holder
     *            the holder to set
     */
    public void setHolder(Holder holder) {
    	this.holder = holder;
    }

    /**
     * @return the holder
     */
    public Holder getHolder() {
    	return holder;
    }

    /**
     * @param ctx
     *            the ctx to set
     */
    public void setCtx(ApplicationContext ctx) {
    	this.ctx = ctx;
    }

    /**
     * @return the ctx
     */
    public ApplicationContext getCtx() {
    	return ctx;
    }

    public static IONEGASCommonService getONEGASCommonService() {
    	return instance.getHolder().getONEGASCommonService();
    }
    
    public static ContextStoreService getContextStoreService() {
    	return instance.getHolder().getContextStoreService();
    }
    
    public static VDNTransferService getVDNTransferService() {
		return instance.getHolder().getVdnTransferService();
	}

    
}