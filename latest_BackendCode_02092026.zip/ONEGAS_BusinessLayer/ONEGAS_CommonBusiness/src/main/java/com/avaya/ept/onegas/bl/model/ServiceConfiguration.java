
/*
* ServiceConfiguration.java
*
* Avaya Inc. - Proprietary (Restricted)
* Solely for authorized persons having a need to know
* pursuant to Company instructions.
*
* Copyright © 2008-2016 Avaya Inc. All rights reserved.
*
* THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Avaya Inc.
* The copyright notice above does not evidence any actual
* or intended publication of such source code.
*/

package com.avaya.ept.onegas.bl.model;



public class ServiceConfiguration {

	private String rdmDataUrl;
	private String rdmPropsPath;
	private String voiceRecPath;

	public String getVoiceRecPath() {
		return voiceRecPath;
	}

	public void setVoiceRecPath(String voiceRecPath) {
		this.voiceRecPath = voiceRecPath;
	}

	public String getRdmDataUrl() {
		return rdmDataUrl;
	}

	public void setRdmDataUrl(String rdmDataUrl) {
		this.rdmDataUrl = rdmDataUrl;
	}

	public String getRdmPropsPath() {
		return rdmPropsPath;
	}

	public void setRdmPropsPath(String rdmPropsPath) {
		this.rdmPropsPath = rdmPropsPath;
	}

}
